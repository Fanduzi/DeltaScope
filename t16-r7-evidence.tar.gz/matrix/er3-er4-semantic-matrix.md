# T16/#95 ER3–ER4 — Lifecycle Semantic Matrix + Temp/Conditional/Batch State

Source: `golden/matrix-t16.json` (60 cases, all `status=pass`, 844 assertions).

## Case-kind distribution (contract bound)

| kind | count | binding |
|---|---|---|
| cli_metadata | 43 | ordered setup/execute/post_verify/teardown steps |
| cli_audit | 9 | top-level `parsed.unsupported`/`diagnostics` + findings + gaps |
| db_ddl | 4 | per-step rc + verify arrays on live anchors |
| db_syntax_negative | 4 | error_class + nonzero rc + forbidden markers |
| **total** | **60** | required == executed == 60 (validator-enforced set equality) |

## Anchor distribution

mysql57: 5 · mysql80: 32 · mysql84: 3 · tidb85: 11 · offline cli_audit: 9

## ER3 — lifecycle semantic coverage by family

- **DROP multi-target atomicity** — `mysql80-drop-multi-atomic`,
  `mysql84-drop-multi-atomic` (veto on missing/dup, execute nothing);
  `mysql57-drop-multi-partial` (sequential/partial, 1051 on missing);
  `tidb85-drop-multi-partial`, `tidb85-drop-dup-partial` (sequential persistent
  catalog, first-dup lands / second reports 1051)
- **duplicate-name DROP** — `mysql80-drop-duplicate` → parse-time 1066, nothing
  executes (MySQL anchors); TiDB differs as above
- **IF EXISTS / conditional** — `drop-ifexists-mixed`, `ifexists-absent-noop`,
  `cli-seed-offline`, `cli-drop-temp-chain`, `cli-drop-multi-refused`,
  `cli-drop-multi-temp-unvouched`, `cli-rename-dest-unknown`,
  `cli-like-source-unknown` — unknown initial state produces **evidence gaps**,
  never invented known-absent/known-present
- **denylist under multi-target** — `mysql80-denylist-multidrop`,
  `cli-drop-multi-refused`: every member of the target list is checked
- **RENAME ordering** — `rename-multi-atomic` (any refused pair rolls back whole
  statement), `rename-dest-exists`, `rename-swap`, `rename-lastwrite-free`
  (destination vacated by earlier pair IS available to later pair),
  `rename-lastwrite-rollback`, `rename-cross-schema`,
  `alter-rename-self-noop`, `cli-rename-dest-unknown`
- **CREATE LIKE** — `like-members` (columns+PK+indexes+checks copied, no FK,
  no auto_increment counter — probed), `like-missing-source`,
  `like-dest-exists`, `like-temp-source` (temp-first source bind)
- **CTAS** — `ctas-forms`, `ctas-missing-source`, `ctas-defs` (declared-prefix +
  ColumnsTailUnknown); **TiDB CTAS → unsupported `create_table_select`**
  (`tidb85-ctas-vendor`, `cli-ctas-tidb-vendor`) — never a positive result
- **TRUNCATE** — `truncate-suite`, `truncate-inbound-fk` (inbound-FK truth),
  row-risk + post-op statistic invalidation
- **vendor boundaries** — `cli-global-temp-mysql-vendor` (MySQL rejects GLOBAL
  TEMPORARY), `mysql80-global-temp-vendor`; unsupported never hidden behind
  ordinary DROP blockers

## ER4 — temp/conditional/batch-state semantics

Two disjoint identity namespaces in `batchState` (`batch_state_namespace.go`):

| case | semantic proved |
|---|---|
| `mysql80-temp-shadow-drop` | temp shadows same-named persistent in session namespace; DROP resolves temp-first |
| `mysql57-temp-shadow` | same shadowing on 5.7 |
| `mysql80-temp-create-dup` | temp create while temp exists → error; temp + persistent same name coexist |
| `mysql80-alter-on-temp`, `tidb85-alter-localtemp` | ALTER targets temp object explicitly |
| `mysql80-rename-temp-invisible`, `tidb85-rename-localtemp` | rename of temp objects; temp invisible to cross-session catalog |
| `mysql80-drop-temp-keyword-miss` | `DROP TEMPORARY TABLE` on absent temp → 1051 (keyword scopes lookup) |
| `mysql80-drop-multi-temp-resolvable` | mixed lists resolve temp namespace per member |
| `tidb85-global-temp`, `tidb85-drop-global-vs-temp` | TiDB GLOBAL temp lifecycle — `ON COMMIT DELETE ROWS` supported end-to-end |
| `tidb85-global-preserve` | **vendor refusal**: TiDB rejects `ON COMMIT PRESERVE ROWS` (error 8200, rc=1, nothing lands); product records unsupported `create_table.temporary.global.preserve` — never a supported claim |
| `t16-cli-drop-temp-chain` | ordered create/drop/recreate chains across namespaces (offline state evolution) |

Conditions (`IF EXISTS`/`IF NOT EXISTS`) produce **evidence gaps** whenever
initial existence is unknown — asserted in matrix as structured
`evidence_gap_entries`, never as guessed terminal state. Unknown initial state
is never reported as a known terminal state (Golden oracle case
`t16-cli-seed-offline` + db_ddl `unknown-initial` assertions).

## Batch state ordering

Ordered state transitions, not per-statement-vs-initial-snapshot:
`RENAME` pairs evaluate left-to-right over an evolving working set;
`DROP … ; CREATE …` chains land final-state observations confirmed by the
oracle (`DROP IF EXISTS t; CREATE TABLE t` → final `t exists` verified in DB).
