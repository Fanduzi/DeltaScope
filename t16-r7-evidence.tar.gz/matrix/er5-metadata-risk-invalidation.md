# T16/#95 ER5 — Metadata / Row-Risk / State-Invalidation Matrix

## Metadata three-state contract

`batch_state.go` keeps existence as **known-exists / known-absent / missing**
(never a boolean guess). Golden coverage:

| metadata state | golden binding | result class |
|---|---|---|
| known-exists | `t16-mysql80-seed-golden`, db_ddl seeds (information_schema verify) | findings/evidence concrete |
| known-absent | snapshot explicitly establishes `t` does not exist (oracle + `ifexists-absent-noop`) | `IF EXISTS`→noop, `IF NOT EXISTS`→lands |
| missing/unknown | all `cli-*` offline cases (no MetadataProvider) | **evidence_gap** — `ddl.table.exists.create.forbid`, `ddl.table.drop.exists.require`, `ddl.table.like.source.exists.require`, `ddl.table.create_as.source.exists.require` |

`cli_metadata` cases (43) execute real ordered `setup→execute→post_verify→
teardown` steps against live anchors — version resolved through
`version_evidence.resolved`; TiDB cases connect via credential-safe option
files (empty `password` fields purged at `b5e1b346`/`c889fb0c`).

## Row-risk & post-operation statistic invalidation

- `TRUNCATE` — row-risk finding + post-op statistic invalidation
  (`mysql80-truncate-suite`, `tidb85` truncate slice); inbound-FK truth
  (`truncate-inbound-fk`): TRUNCATE under inbound FK is refused/denied per
  dialect, never silently allowed.
- `DROP` — object + statistics leave catalog together; multi-target sequences
  invalidate per-landed-member (5.7/TiDB partial) vs nothing-on-veto (8.x atomic).
- `RENAME` — identity migrates with stats per dialect (`rename-swap`,
  `rename-multi-atomic`); refused pairs publish no post-state.
- `CREATE LIKE` — copies member set but **no** auto_increment counter and
  **no** FK constraints (probed `like-members`) — stat facts are fresh/empty.
- No assumption that execution affects data when no data is present:
  `ifexists-absent-noop` and gap-producing offline cases assert zero data
  claims alongside the gap.

## Row-risk semantics proven on anchors

- db_ddl cases assert post-state via `information_schema` verify steps
  (see matrix-t16.json step.verify arrays — actual SQL + rc + output).
- `db_syntax_negative` cases pin dialect error classes (MySQL 1066 dup-name
  parse refusal, 1051 unknown-table, TiDB partial 1051) rather than generic
  "failed".

## State-invalidation ordering

Ordered transitions mean later statements observe earlier effects:
`CREATE → DROP → CREATE` chains (`t16-cli-drop-temp-chain`), `RENAME`
vacated-destination availability (`rename-lastwrite-free`), and refused-pair
atomic rollback (`rename-lastwrite-rollback`, `rename-multi-atomic`) — all
asserted at both artifact level and live-DB level.
