# T16/#95 — AC1–AC10 Acceptance Mapping + Evidence Typing

Evidence-type legend (per work order): OFFICIAL-DOC / SOURCE-PROVEN /
GOLDEN / NATIVE-CURRENT / NATIVE-HISTORICAL / INFERENCE / UNPROVEN.

## AC1 — DROP/TRUNCATE/RENAME single+multi-target, cross-schema, protected, conditional

- multi-target DROP every member checked incl. protected tails:
  GOLDEN `t16-mysql80-denylist-multidrop`, `t16-cli-drop-multi-refused`;
  SOURCE-PROVEN `batch_state.go` ordered multi-target loop (same all-target
  principle as T01); NATIVE-CURRENT db steps on mysql57/80/84/tidb85
- dialect atomicity: GOLDEN `mysql80/84-drop-multi-atomic` (veto),
  `mysql57-drop-multi-partial` (1051 partial), `tidb85-drop-*-partial`
  (catalog-sequential, temp veto); NATIVE-HISTORICAL `p16_lifecycle_matrix.log`
- cross-schema RENAME: GOLDEN `rename-cross-schema`; OFFICIAL-DECISION per ADR
- conditional DROP: GOLDEN `ifexists-absent-noop`, `drop-ifexists-mixed`;
  unknown-state → evidence gaps `cli-drop-*` cases
- TRUNCATE: GOLDEN `truncate-suite` + `truncate-inbound-fk`; stat invalidation
  SOURCE-PROVEN in state publication; row-risk finding bound
- multi-table TRUNCATE is not valid syntax — parser rejects (corpus-negative
  coverage); not audited as legal

## AC2 — LIKE / MySQL CTAS / temp forms / TiDB vendor boundary

- LIKE: GOLDEN `like-members` (columns+PK+indexes+checks; **no FK, no
  auto_increment counter** — NATIVE-HISTORICAL probe), `like-missing-source`,
  `like-dest-exists`, `like-temp-source` (temp-first)
- MySQL CTAS: GOLDEN `ctas-forms`, `ctas-missing-source`, `ctas-defs`
  (declared-prefix + ColumnsTailUnknown)
- **TiDB CTAS → unsupported `create_table_select`** (GOLDEN `tidb85-ctas-vendor`,
  `cli-ctas-tidb-vendor`; OFFICIAL-DOC boundary; never a positive case)
- TEMPORARY: GOLDEN mysql57/80 temp-* cases; TiDB GLOBAL TEMPORARY
  `ON COMMIT DELETE ROWS` supported: GOLDEN `tidb85-global-temp`,
  `tidb85-drop-global-vs-temp`; **`ON COMMIT PRESERVE ROWS` refused by TiDB
  (error 8200)** — product maps to unsupported
  `create_table.temporary.global.preserve`, GOLDEN `tidb85-global-preserve`
  (vendor-refusal case, not a supported claim)
- MySQL GLOBAL TEMPORARY rejected by vendor: GOLDEN `cli-global-temp-mysql-vendor`,
  `mysql80-global-temp-vendor`

## AC3 — temp/persistent same-name identity, session lifecycle, conditional unknown

- two disjoint namespaces (`batch_state_namespace.go`, blob-indexed);
  GOLDEN `temp-shadow-drop`, `mysql57-temp-shadow`, `temp-create-dup`,
  `drop-temp-keyword-miss`, `alter-on-temp`, `rename-temp-invisible`,
  `alter-rename-temp`, `tidb85-alter-localtemp`, `tidb85-rename-localtemp`
- ordered chains: GOLDEN `cli-drop-temp-chain`; batch state evolves per
  statement, never re-reads initial snapshot (SOURCE-PROVEN ordered apply)
- unknown premise → gap, never false terminal: GOLDEN `cli-seed-offline`,
  `cli-rename-dest-unknown`, `cli-like-source-unknown`

## AC4 — known/unknown metadata, row-risk, mutation + stat invalidation

- known-exists: GOLDEN seeds (information_schema verify steps in db_ddl)
- known-absent: explicit snapshot establishes non-existence (oracle)
- missing metadata → gaps (43 cli_metadata + offline cli_audit cases)
- TRUNCATE/DROP stat invalidation SOURCE-PROVEN (state publication clears
  table facts per landed operation; refused/veto publishes no post-state)
- no data-effect assumption when no data present: `ifexists-absent-noop`

## AC5 — four native anchors legal lifecycle + terminal observation

- mysql57=5 / mysql80=32 / mysql84=3 / tidb85=11 cases incl. db_ddl +
  syntax_negative per anchor — NATIVE-CURRENT at frozen HEAD
- NATIVE-HISTORICAL: committed probes `p16_lifecycle_matrix.log` (2,222-line
  real-server matrix), `p16_tail_supplement.log`, `p16_r1_selfpair_lastwrite.log`
  (blob SHAs in `probes/committed-blobs.txt`) — recorded as historical, not
  re-claimed as new
- missing targets never hidden behind ordinary DROP blockers: `cli-drop-multi-refused`
  keeps policy finding + missing-object gap separately classified

## AC6 — Golden required/executed/Oracle

- required==executed==60, 0 dup/missing/extra, all pass, 844 assertions —
  `validator/verify-t16.out.txt` 0 mismatches; oracle `golden/T16.json`
  frozen at HEAD blob; self-test 31/31 DETECTED

## AC7 — four-surface parity + gates + regression

- CLI/SDK/HTTP/MCP identical semantics on 3 representatives
  (`parity/er8-*.md`, raw I/O per surface)
- gates rc=0 ×6; T08–T15 serial regression all PASS at HEAD (`regression/`)

## AC8 — source/standards/ADR/inventory/downstream mapping

- `source-audit/er1-*.md` impl chain + downstream additive audit
- `inventory/er2-*.md` 13 owner rows + version anchors + ADR binding
- blob-SHA pinned: probe files + ADR (`committed-blobs.txt`)

## AC9 — archive independently verifiable, privacy-clean, history untampered

- see manifest/index/ledger + independent re-extract log (receipt §F)

## AC10 — no unresolved product defect

- one fixture defect found+fixed in-scope: empty `password`/`password_env`
  fields in 9 TiDB metadata cases → `c889fb0c` testdata-only commit
  (product code untouched). No remaining known product defect;
  no UNPROVEN cell claimed as proven.

## UNPROVEN/HOLD disclosure

None blocking. Historical probe coverage predates `c889fb0c` but all
anchor-bound semantics were re-executed this round via cli_metadata/db_ddl
cases; the R15-style "docs claim ≠ fresh execution" rule is respected —
historical material is labelled NATIVE-HISTORICAL only.
