# T16/#95 R7 Evidence Bundle — final archive metadata closeout

Work order: T16-R7-FINAL-ARCHIVE-METADATA-CLOSEOUT-01.
Frozen: HEAD c889fb0c82be2f67e9a3cf5c35064264ba91fe78 /
tree 6e6fea5eda634c4d8d991f8e23eee189b7412af3 /
parent db17cf6d53418f776008848d94962c91f5471cdc —
milestone branch, local only. Evidence/documentation-only round.

## R7 scope (metadata closeout — no retesting)
The reviewer VERIFIED the R6 HTTP response-body provenance correction and
found no remaining technical defect in product semantics, the finding
validator, four-surface parity, native probes, Golden, regression
evidence, archive index or manifest. The single remaining defect was
archive metadata:

- privacy-scan.txt carried a stale "denominator: 140" from R4 through
  R5 and R6 while the R6 member set had grown to 161 regular files
  (correct denominator 160).
- README.md still carried the R5 title and the R3 work-order identity.

R7 corrects both. No product, database, performance or parity rerun was
requested or performed.

## R7 changes
- privacy-scan.txt: rewritten as an explicit PRE-SEAL staged scan whose
  denominator is derived from the actual staged member set, bound to the
  authoritative POST-SEAL scan transcript kept OUTSIDE this archive
  (post-seal scan covers every regular member except the scan file
  itself, manifest/index/ledger/README included).
- README.md (this file): retitled to R7 with the R7 work-order identity.
- reuse-ledger.txt: R7 section appended (2 NEW doc files, everything
  else REUSED unchanged from R6).

## R6 content (VERIFIED by reviewer, carried unchanged)
- parity/http/response-r5-body-AUTHORITATIVE.json — pure HTTP body,
  3,449 B, sha f505a09980fd59d7a53615833abf927f9becdbee3415dd267a09073a136fc821
- response-r5-combined-transcript-HISTORICAL.txt — combined client
  transcript preserved (sha ca0d8877… claim SUPERSEDED)

## Historical (carried unchanged, still accurate)
- validator: per-statement MULTISET finding comparison; identical-finding
  multiplicity proof (2 rows in one statement) + move/delete negatives;
  19/19 nonzero + family + 1/1 positive; full stdout/stderr archived.
- parity/: per-surface raw provenance (cli/sdk/http/mcp), identical
  denylist blocker tuple on all four surfaces.
- probes/: TiDB same-name collision A/B/C complete provenance.
- perf/: corrected percentiles (median 49.3; nearest-rank p95 92.6;
  type-7 ~75.4). Obsolete R2 "p95=61.3" labelled historical/superseded.
- golden artifact+matrix+oracle, six-gate logs, T08-T15 regression logs,
  R1 committed probes + gap/unsupported parity raws, source-audit +
  inventory + matrix docs — all REUSED, not re-run.

## Archive identity
Authoritative R7 archive: t16-r7-evidence.tar.gz — sha256 and size are
recorded in the delivery receipt (computed only after sealing).
Prior archives R1-R6 are preserved unmodified; see reuse-ledger.txt.
