# T16-R3 ER6 — Performance accounting (corrected)

12 warm CLI samples (fixture: denylist 4-statement SQL, same as ER4),
binary SHA `13f95361ed95db56401fafb4ac7a6a33f496b5bd4c628da6b4245c7dc774635c`
(bin/deltascope @ c889fb0c), per-sample stdout SHA `363c98d4c3d50c98`
(identical across all 12). Samples: `perf-samples.tsv` + `perf-sample-N.json`.

Sorted ms: 42.6, 44.3, 44.9, 45.1, 48.2, 49.2, 49.4, 51.0, 53.2, 56.2, 61.3, 92.6

Corrected statistics (declared algorithms):
- median (n=12, average of 6th/7th): **49.3 ms**
- **nearest-rank p95** = ceil(0.95×12)=12th sample = **92.6 ms**
- **type-7 linear interpolation p95** (numpy/default) ≈ **75.4 ms**
- R2's "p95=61.3ms" was WRONG: it took index floor(0.95×12)-1=10 →
  11th sample. That value is ~p83, not p95. Corrected here; the R2 file
  is superseded by this document, not edited in place.
- The 92.6 ms sample is retained (no outlier dropping).
