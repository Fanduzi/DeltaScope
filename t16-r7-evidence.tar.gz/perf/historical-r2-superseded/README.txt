HISTORICAL — SUPERSEDED. perf-samples-r2.tsv is the byte-identical R2
measurement file whose footer wrongly labeled the 11th sample as "p95".
Authoritative corrected statistics: ../perf-current-summary.txt and
../README.md. Preserved for audit history only — do not cite its p95.
