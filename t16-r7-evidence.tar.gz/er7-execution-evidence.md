# T16-R3 ER7 — Frozen execution & proof reuse

Evidence-only round. No product/oracle change; HEAD still c889fb0c.

FRESH (R3):
- validator multiset fix (findings_grouped/expected_grouped → Counter)
- process_selftest_r3.py: 19 neg nonzero-rc + 19 field-family + 1 positive
  permutation rc=0; full stdout/stderr per test in selftest-r3/
- four-surface denylist probe re-run with per-surface raw files
- TiDB collision probe re-run (probe-tidb-collision.sh + r3 log)
- perf p95 corrected (nearest-rank 92.6 / type-7 ≈75.4; R2 claim wrong)
- repackaged archive (COPYFILE_DISABLE=1; manifest covers all-but-itself)

REUSED (unre-run, byte-identical from R2 — labeled):
- golden/artifact.json + matrix-t16.json + T16.json (make ddl-golden
  PASS 60/60/844 @ c889fb0c — log gates/ddl-golden-make.log)
- gates/gates-full.log (six gates rc=0), gates/gates-c889fb0c.log
- regression/ T08–T15 logs @ c889fb0c
- R1 committed probe files (probes/p16_*), R1 parity raw for
  gap/unsupported representatives (parity/*multi-drop*, like-unknown, ctas)
- source-audit/ docs + raw diff; inventory/ docs; matrix/ docs;
  identity/er8-model-deviation.md (R1/R2 disclosure preserved verbatim)

REMOVED vs R2 (superseded, not edited in place):
- validator/process_selftest.py + process_selftest.tsv + selftest out
  → superseded by *_r3 files (kept in bundle as history under validator/r2-history/)
- perf/summary claim p95=61.3 → corrected (perf/README.md)
- tidb-global-vs-persistent.txt (partial provenance) → superseded by
  tidb-global-vs-persistent-r3.txt with full SQL/rc/verify/teardown
