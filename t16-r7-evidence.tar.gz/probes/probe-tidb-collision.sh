#!/bin/bash
# T16-R4 ER5 — TiDB v8.5.0 GLOBAL TEMP vs persistent same-name collision.
# Image: pingcap/tidb@sha256:490861bd4a2fa643dbe76b77ffecafcad66e6a42774e580b82f4ec2429a80e57
# Start: docker run -d --name t16-r3-tidb85 -p 127.0.0.1:24001:4000 \
#   pingcap/tidb@sha256:490861bd... --store=unistore --path=
# Connect: mysql -h127.0.0.1 -P24001 -uroot --password= (empty pw, local container)
# NOTE: TEMPORARY tables are session-scoped — each scenario's statements MUST
# run inside ONE mysql -e invocation (one session). C uses that single-session
# form throughout.
M="mysql -h127.0.0.1 -P24001 -uroot --password= --batch --raw"
run() {
  echo "=== $1"
  echo "SQL> $2"
  out=$($M -e "$2" 2>&1); rc=$?
  echo "rc=$rc"
  echo "--- stdout/stderr ---"
  echo "$out"
  echo
}
run "setup" "DROP DATABASE IF EXISTS t16r3; CREATE DATABASE t16r3; USE t16r3; CREATE TABLE persist_t (id INT PRIMARY KEY, v VARCHAR(20)); INSERT INTO persist_t VALUES (1,'persist-row');"

run "A-persistent-then-global-temp" "USE t16r3; CREATE GLOBAL TEMPORARY TABLE persist_t (id INT PRIMARY KEY) ON COMMIT DELETE ROWS;"

run "A-verify-catalog-single" "USE t16r3; SHOW TABLES; SELECT COUNT(*) AS cnt FROM information_schema.tables WHERE table_schema='t16r3' AND table_name='persist_t';"

run "B-global-temp-then-persistent" "USE t16r3; CREATE GLOBAL TEMPORARY TABLE g_t (id INT PRIMARY KEY) ON COMMIT DELETE ROWS; CREATE TABLE g_t (id INT PRIMARY KEY);"

run "B-verify" "USE t16r3; SHOW CREATE TABLE g_t\G"

run "C-local-temp-shadows-persistent-single-session" "USE t16r3; CREATE TEMPORARY TABLE persist_t (id INT PRIMARY KEY, v VARCHAR(20)); INSERT INTO persist_t VALUES (9,'temp-row'); SELECT id, v, 'temp-src' AS src FROM persist_t; DROP TEMPORARY TABLE persist_t; SELECT id, v, 'persist-src' AS src FROM persist_t;"

run "teardown" "DROP DATABASE IF EXISTS t16r3; SHOW DATABASES;"
