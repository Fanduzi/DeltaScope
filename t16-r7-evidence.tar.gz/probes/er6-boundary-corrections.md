# T16-R2 ER6 — Documentation & Version-Boundary Corrections

## 1. TiDB `ON COMMIT PRESERVE ROWS` — refused, not supported
Raw case `t16-tidb85-global-preserve`: rc=1, ERROR 8200, lands nothing;
product records unsupported `create_table.temporary.global.preserve`.
All suggestive wording corrected — it is a refused negative.
Supported form: `ON COMMIT DELETE ROWS` only (`t16-tidb85-global-temp`).

## 2. `t16-tidb85-like-tempsrc` is a REFUSAL — not a MySQL positive
Oracle expect: exit=1, verdict=reject, finding
`ddl.tidb.local_temporary.like` blocker @stmt index 1 — TiDB forbids
`CREATE TABLE … LIKE <local temporary source>` (vendor restriction).
Contrast: MySQL `t16-mysql80-like-temp-source` is the positive (temp-first
source bind, pass). The two are never pooled as one "like-temp-source" claim.

## 3. GLOBAL TEMPORARY vs persistent same-name — NOT local shadowing
Fresh native probe `probes/tidb-global-vs-persistent.txt`
(anchor pingcap/tidb:v8.5.0):

| probe | result |
|---|---|
| persistent `p16n` exists → `CREATE GLOBAL TEMPORARY p16n` | **ERROR 1050 (42S01) already exists** |
| GLOBAL TEMP `g16n` exists → `CREATE TABLE g16n` | **ERROR 1050 (42S01) already exists** |
| persistent `p16s` exists → `CREATE TEMPORARY p16s` (LOCAL) | allowed — shadows (SELECT sees temp row 9; after DROP TEMPORARY persistent row 7 returns) |

Conclusion: TiDB GLOBAL TEMPORARY occupies the catalog namespace (1050
conflict both directions) — fundamentally different from LOCAL temporary
shadowing. Product's two-namespace model treats the session-local temp slot
as the shadowing namespace, consistent with this boundary; no product defect
exposed by the probe.

## 4. Parity wording correction
R1 `multi-drop` produced **3 evidence gaps, 0 findings** — it proved gap
parity only. The denylist finding parity (ER5) is a separate representative.
parity doc + summary updated.
