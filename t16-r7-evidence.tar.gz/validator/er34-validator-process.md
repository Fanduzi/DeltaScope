# T16-R2 ER3/ER4 — Validator v2 + Process-Exit Proofs + Oracle Binding

## validate_t16_r2.py
CLI: `--artifact --matrix --oracle` (all independently specifiable).
Three bindings, separately reported:
- **A** oracle (T16.json) → artifact expected + actual: required_case_ids set,
  case_id/kind/dialect/anchor, input SQL, expected scalars + entries,
  metadata phase names/order/sql/expect_rc/verify(sql+expect), db_ddl
  template steps (expect_rc vs expected rc + actual rc; verify.expect vs
  actual output), syntax_negative raw input + error_class.
- **B** artifact → matrix lossless projection (deep_cmp).
- **C** expected → actual semantic judgment incl. ER1 findings:
  grouped {stmt_index: [(rule_id,level)]} — immune to intra-statement
  reorder, detects cross-statement moves; per-statement counts implicit in
  grouping; finding.statement_index cross-checked vs enclosing index;
  location preserved into matrix (provenance, compared artifact↔matrix).

## process_selftest.py — 17/17 real subprocess exits
Each tamper: isolated temp copies of the three inputs → real validator CLI
→ rc/stdout/stderr/argv recorded in `process_selftest.tsv`.
Finding set (5): rule_id, level, statement_index field, cross-statement move,
location.column — all DETECTED at findings-family paths.
Process set (11): meta rc, verify output, step delete, unsup add/del,
db verify, neg error_class, required ids, case dup, status, assert.
Oracle set (1): T16.json verify.expect only → expected.steps verify mismatch.
Denominator is fresh (17), not an extension of R1's 29.
