#!/usr/bin/env python3
"""T16-R2 process-level self-test: for each directed tamper, copy the three
inputs into an isolated temp dir, mutate via JSON path, invoke the REAL
validator CLI as a subprocess, and record argv/stdout/stderr/exit code.

ER2 field reports: case_id, target field, old value, new value, first
detected mismatch line. A tamper whose detection lands on an unrelated field
family is marked FAIL even though rc!=0.
"""
import json, os, sys, copy, subprocess, tempfile, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
VAL = os.path.join(HERE, 'validate_t16_r2.py')
GOLD = os.path.join(HERE, '..', 'golden')
OUT = os.path.join(HERE, 'process_selftest.tsv')


def load(p):
    with open(p) as f:
        return json.load(f)


def save(p, d):
    with open(p, 'w') as f:
        json.dump(d, f)


def run_one(name, mutate, expect_field=None):
    """mutate(td) -> (target_desc, old, new). Returns report dict."""
    td = tempfile.mkdtemp(prefix='t16r2-')
    ap = os.path.join(td, 'artifact.json')
    mp = os.path.join(td, 'matrix.json')
    op = os.path.join(td, 'oracle.json')
    art, mat, ora = (load(f'{GOLD}/artifact.json'), load(f'{GOLD}/matrix-t16.json'),
                     load(f'{GOLD}/T16.json'))
    desc = mutate(art, mat, ora)
    save(ap, art); save(mp, mat); save(op, ora)
    argv = [sys.executable, VAL, '--artifact', ap, '--matrix', mp, '--oracle', op]
    r = subprocess.run(argv, capture_output=True, text=True)
    first = r.stdout.strip().split('\n')[0] if r.stdout.strip() else ''
    ok = r.returncode != 0
    # field-family check: first mismatch line should mention the tampered family
    family_ok = (expect_field is None) or (expect_field in first)
    shutil.rmtree(td)
    return {'test': name, 'target': desc, 'rc': r.returncode, 'ok': ok,
            'family_ok': family_ok, 'first': first, 'argv': ' '.join(argv),
            'stderr': r.stderr.strip()[:200]}


def case(art, cid_suffix):
    return next(c for c in art['cases'] if c['case_id'].endswith(cid_suffix))


def main():
    rows = []

    # --- ER2: real finding tampers (finding-bearing cli_metadata cases) ---
    def t_rule(a, m, o):
        c = case(a, 'denylist-multidrop')
        st = c['actual']['parsed']['statements'][1]
        old = st['findings'][0]['rule_id']; st['findings'][0]['rule_id'] = 'x.tampered'
        return (f"{c['case_id']}.stmts[1].findings[0].rule_id", old, 'x.tampered')
    rows.append(('R2-finding-rule_id', t_rule, 'findings'))

    def t_level(a, m, o):
        c = case(a, 'denylist-multidrop')
        st = c['actual']['parsed']['statements'][1]
        old = st['findings'][0]['level']; st['findings'][0]['level'] = 'notice'
        return (f"{c['case_id']}.stmts[1].findings[0].level", old, 'notice')
    rows.append(('R2-finding-level', t_level, 'findings'))

    def t_ownidx(a, m, o):
        c = case(a, 'drop-multi-temp-resolvable')
        f = c['actual']['parsed']['statements'][2]['findings'][0]
        old = f['statement_index']; f['statement_index'] = 0
        return (f"{c['case_id']}.stmts[2].findings[0].statement_index", old, 0)
    rows.append(('R2-finding-stmt_index', t_ownidx, 'findings'))

    def t_move(a, m, o):
        c = case(a, 'drop-multi-temp-resolvable')
        sts = c['actual']['parsed']['statements']
        f = sts[2]['findings'].pop()
        sts[1].setdefault('findings', []).append(f)
        return (f"{c['case_id']} move finding stmt2->stmt1", 'index=2', 'index=1')
    rows.append(('R2-finding-move-stmt', t_move, 'findings'))

    def t_loc(a, m, o):
        c = case(a, 'denylist-multidrop')
        f = c['actual']['parsed']['statements'][1]['findings'][0]
        old = dict(f['location']); f['location']['column'] = 999
        return (f"{c['case_id']}.stmts[1].findings[0].location.column", old['column'], 999)
    rows.append(('R2-finding-location', t_loc, 'finding_locations_a'))

    # --- ER3 process-exit categories ---
    def t_meta_rc(a, m, o):
        c = case(a, 'denylist-multidrop')
        s = c['actual']['execute'][0]
        old = s['rc']; s['rc'] = 99
        return (f"{c['case_id']}.execute[0].rc", old, 99)
    rows.append(('R2-meta-execute-rc', t_meta_rc, 'expect_rc'))

    def t_meta_vo(a, m, o):
        c = next(x for x in a['cases'] if x['kind'] == 'cli_metadata'
                 and x['actual'].get('execute') and x['actual']['execute'][0].get('verify'))
        v = c['actual']['execute'][0]['verify'][0]
        old = v.get('output'); v['output'] = 'ZZZ'
        return (f"{c['case_id']}.execute[0].verify[0].output", old, 'ZZZ')
    rows.append(('R2-meta-verify-output', t_meta_vo, 'verify'))

    def t_meta_del(a, m, o):
        c = case(a, 'denylist-multidrop')
        old = len(c['actual']['execute']); c['actual']['execute'].pop()
        return (f"{c['case_id']}.execute len", old, old - 1)
    rows.append(('R2-meta-step-delete', t_meta_del, None))

    def t_unsup_del(a, m, o):
        c = next(x for x in a['cases'] if (x['actual'].get('parsed') or {}).get('unsupported'))
        old = len(c['actual']['parsed']['unsupported']); c['actual']['parsed']['unsupported'] = None
        return (f"{c['case_id']}.parsed.unsupported", old, None)
    rows.append(('R2-unsup-delete', t_unsup_del, None))

    def t_unsup_add(a, m, o):
        c = next(x for x in a['cases'] if x['kind'] == 'cli_audit')
        c['actual']['parsed'].setdefault('unsupported', []).append(
            {'feature': 'x', 'sql': 'y', 'reason': 'z', 'metadata': {}})
        return (f"{c['case_id']}.parsed.unsupported", 'len', '+1')
    rows.append(('R2-unsup-add', t_unsup_add, None))

    def t_db_verify(a, m, o):
        c = next(x for x in a['cases'] if x['kind'] == 'db_ddl'
                 and x['actual']['steps'][1].get('verify'))
        v = c['actual']['steps'][1]['verify'][0]
        old = v.get('output'); v['output'] = '999'
        return (f"{c['case_id']}.steps[1].verify[0].output", old, '999')
    rows.append(('R2-db-verify', t_db_verify, 'verify'))

    def t_neg(a, m, o):
        c = next(x for x in a['cases'] if x['kind'] == 'db_syntax_negative')
        old = c['actual']['error_class']; c['actual']['error_class'] = '9999'
        return (f"{c['case_id']}.error_class", old, '9999')
    rows.append(('R2-neg-class', t_neg, 'error_class'))

    def t_req(a, m, o):
        old = list(o.get('required_case_ids') or [])
        o['required_case_ids'] = old[:-1] + ['T16.db.mysql57.nonexistent']
        return ('oracle.required_case_ids', old[-1], 'T16.db.mysql57.nonexistent')
    rows.append(('R2-required-ids', t_req, 'required'))

    def t_dup(a, m, o):
        a['cases'].append(copy.deepcopy(a['cases'][0]))
        return ('artifact.cases dup', 60, 61)
    rows.append(('R2-case-duplicate', t_dup, None))

    def t_status(a, m, o):
        c = a['cases'][0]
        old = c['status']; c['status'] = 'fail'
        return (f"{c['case_id']}.status", old, 'fail')
    rows.append(('R2-status-fail', t_status, 'status'))

    def t_assert(a, m, o):
        c = a['cases'][0]
        old = c['assertions'][0]['ok']; c['assertions'][0]['ok'] = False
        return (f"{c['case_id']}.assertions[0].ok", old, False)
    rows.append(('R2-assert-break', t_assert, 'assert'))

    # --- ER4 oracle tamper: single oracle field changed, artifact+matrix same ---
    def t_ora_expect(a, m, o):
        st = o['ddl_steps'][1]['verify'][0]
        old = st['expect']; st['expect'] = '777'
        return ('oracle.ddl_steps[1].verify[0].expect', old, '777')
    rows.append(('R2-oracle-verify-expect', t_ora_expect, 'verify'))

    reports = []
    for name, fn, fam in rows:
        rep = run_one(name, fn, fam)
        reports.append(rep)
        print(f"{rep['test']}\trc={rep['rc']}\tfamily_ok={rep['family_ok']}\t{rep['first'][:110]}")

    with open(OUT, 'w') as f:
        f.write('test\ttarget(old->new)\trc\tfamily_ok\tfirst_mismatch\targv\n')
        for r in reports:
            f.write(f"{r['test']}\t{r['target']}\t{r['rc']}\t{r['family_ok']}\t{r['first']}\t{r['argv']}\n")
    det = sum(1 for r in reports if r['ok'])
    famok = sum(1 for r in reports if r['family_ok'])
    print(f"process selftest: {det}/{len(reports)} nonzero-rc, {famok}/{len(reports)} field-family correct")
    return 0 if det == len(reports) and famok == len(reports) else 1


if __name__ == '__main__':
    sys.exit(main())
