#!/usr/bin/env python3
"""T16-R5 ER2 — identical-finding multiplicity proof (real subprocess).

Positive: TWO findings with IDENTICAL rule_id+level in ONE statement,
artifact expected/actual and oracle mutually consistent; matrix
regenerated via the validator's derive; validator must exit 0 AND
findings_a must contain TWO rows for that statement (multiplicity
preserved, not Counter-key collapsed).

Negatives: (A) delete one of the two actual findings -> nonzero rc +
findings-family mismatch; (B) move one into another statement ->
nonzero rc + statement-attribution (findings grouped) mismatch.

Historical 19 negative + 1 permutation tests are preserved in
process_selftest_r3.* — this file only adds R5 proofs.
"""
import json, os, sys, copy, subprocess, tempfile, shutil, importlib.util

HERE = os.path.dirname(os.path.abspath(__file__))
VAL = os.path.join(HERE, 'validate_t16_r2.py')
GOLD = os.path.join(HERE, '..', 'golden')
OUTDIR = os.path.join(HERE, 'selftest-r5')
OUT = os.path.join(HERE, 'process_selftest_r5.tsv')
JSONL = os.path.join(HERE, 'process_selftest_r5.jsonl')

spec = importlib.util.spec_from_file_location('v', VAL)
v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)


def load(p):
    with open(p) as f:
        return json.load(f)


def save(p, d):
    with open(p, 'w') as f:
        json.dump(d, f)


def case(art, cid_suffix):
    return next(c for c in art['cases'] if c['case_id'].endswith(cid_suffix))


def add_identical_finding(art, ora, cid_suffix):
    """Append a SECOND finding identical (rule_id,level,location) to the
    first finding of stmt index 1, consistently in artifact actual,
    artifact expected and oracle expected."""
    c = case(art, cid_suffix)
    st = c['actual']['parsed']['statements'][1]
    f0 = st['findings'][0]
    f1 = copy.deepcopy(f0)  # identical rule_id+level+location+statement_index
    st['findings'].append(f1)
    ent = {'index': 1, 'rule_id': f0['rule_id'], 'level': f0['level']}
    c['expected'].setdefault('finding_entries', []).append(dict(ent))
    if 'findings' in c['expected']:
        c['expected']['findings'] += 1
    oc = next(x for x in ora['metadata_cases'] if x['id'].endswith('denylist-multidrop'))
    oc['expect'].setdefault('finding_entries', []).append(dict(ent))
    if 'findings' in oc['expect']:
        oc['expect']['findings'] += 1
    return c, st, f0


def run_one(name, mutate, expect_field, expect_rc, postcheck=None):
    td = tempfile.mkdtemp(prefix='t16r5-')
    ap, mp, op = (os.path.join(td, x) for x in ('a.json', 'm.json', 'o.json'))
    art, mat, ora = (load(f'{GOLD}/artifact.json'), load(f'{GOLD}/matrix-t16.json'),
                     load(f'{GOLD}/T16.json'))
    desc = mutate(art, mat, ora)
    save(ap, art); save(mp, mat); save(op, ora)
    if expect_rc == 0:  # positive: regenerate matrix from mutated artifact
        mat[:] = [v.derive_row(c) for c in art['cases']]
        save(mp, mat)
    argv = [sys.executable, VAL, '--artifact', ap, '--matrix', mp, '--oracle', op]
    r = subprocess.run(argv, capture_output=True, text=True)
    os.makedirs(OUTDIR, exist_ok=True)
    with open(os.path.join(OUTDIR, f'stdout-{name}.txt'), 'w') as f:
        f.write(r.stdout)
    with open(os.path.join(OUTDIR, f'stderr-{name}.txt'), 'w') as f:
        f.write(r.stderr)
    # regenerated matrix evidence for positive tests
    matrix_evidence = ''
    if expect_rc == 0:
        mm = load(mp)
        row = next(x for x in mm if x['case_id'].endswith('denylist-multidrop'))
        fa = [x for x in row.get('findings_a', []) if x['index'] == 1]
        matrix_evidence = f"findings_a@index1={len(fa)} rows: {fa}"
        with open(os.path.join(OUTDIR, f'matrix-{name}.json'), 'w') as f:
            json.dump(row, f, indent=1)
    extra_ok = postcheck(mp if expect_rc == 0 else None) if postcheck else True
    lines = [l for l in r.stdout.splitlines() if l.strip() and not l.startswith('verify:')]
    family_ok = any(expect_field in l for l in lines) if expect_rc != 0 else True
    rc_ok = (r.returncode != 0) if expect_rc != 0 else (r.returncode == 0)
    first = lines[0] if lines else ''
    shutil.rmtree(td)
    return {'test': name, 'target': desc, 'expect_field': expect_field,
            'expect_rc': expect_rc, 'rc': r.returncode, 'rc_ok': rc_ok,
            'family_ok': family_ok, 'extra_ok': extra_ok,
            'matrix_evidence': matrix_evidence,
            'first': first, 'argv': ' '.join(argv),
            'stdout_file': f'stdout-{name}.txt', 'stderr_file': f'stderr-{name}.txt'}


def two_index1_rows(mp):
    row = next(x for x in load(mp) if x['case_id'].endswith('denylist-multidrop'))
    return len([x for x in row['findings_a'] if x['index'] == 1]) == 2


def main():
    rows = []

    # --- positive: two IDENTICAL findings in one statement ---
    def t_pos(a, m, o):
        c, st, f0 = add_identical_finding(a, o, 'denylist-multidrop')
        return (f"{c['case_id']} stmt1 +identical finding (rule={f0['rule_id']}, level={f0['level']})",
                '1 finding', '2 identical findings')
    rows.append(('R5-pos-identical-mult', t_pos, None, 0))

    # --- negative A: delete one of the two actual findings ---
    def t_negA(a, m, o):
        c, st, f0 = add_identical_finding(a, o, 'denylist-multidrop')
        st['findings'].pop()  # actual back to 1 while expected/oracle want 2
        return (f"{c['case_id']} stmt1 delete 1 of 2 identical actual findings", '2', '1')
    rows.append(('R5-neg-identical-delete', t_negA, 'findings', 1))

    # --- negative B: move one identical finding to another statement ---
    def t_negB(a, m, o):
        c, st, f0 = add_identical_finding(a, o, 'denylist-multidrop')
        mv = st['findings'].pop()
        mv['statement_index'] = 2
        c['actual']['parsed']['statements'][2].setdefault('findings', []).append(mv)
        return (f"{c['case_id']} stmt1->stmt2 move 1 of 2 identical findings", 'index1 x2', 'index1 x1 + index2 x1')
    rows.append(('R5-neg-identical-move', t_negB, 'findings', 1))

    reports = []
    for name, fn, fam, erc in rows:
        rep = run_one(name, fn, fam, erc, two_index1_rows if erc == 0 else None)
        reports.append(rep)
        print(f"{rep['test']}\trc={rep['rc']}\trc_ok={rep['rc_ok']}\tfamily_ok={rep['family_ok']}\textra_ok={rep['extra_ok']}\t{rep['matrix_evidence'][:90]}")

    with open(JSONL, 'w') as f:
        for r in reports:
            f.write(json.dumps(r) + '\n')
    with open(OUT, 'w') as f:
        f.write('test\ttarget(old->new)\texpect_field\texpect_rc\trc\trc_ok\tfamily_ok\textra_ok\tmatrix_evidence\tfirst\targv\tstdout_file\tstderr_file\n')
        for r in reports:
            f.write('\t'.join(str(r[k]) for k in ('test','target','expect_field','expect_rc','rc','rc_ok','family_ok','extra_ok','matrix_evidence','first','argv','stdout_file','stderr_file')) + '\n')

    neg = [r for r in reports if r['expect_rc'] != 0]
    pos = [r for r in reports if r['expect_rc'] == 0]
    nz = sum(1 for r in neg if r['rc_ok'] and r['family_ok'])
    poz = sum(1 for r in pos if r['rc_ok'] and r['extra_ok'])
    print(f"denominators: negatives rc!=0+family {nz}/{len(neg)}; "
          f"positive rc==0+two-rows {poz}/{len(pos)}")
    return 0 if (nz == len(neg) and poz == len(pos)) else 1


if __name__ == '__main__':
    sys.exit(main())
