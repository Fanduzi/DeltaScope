# T16/#95 ER2 — Standards / Version / Inventory Alignment

## Inventory ownership

`testdata/ddl-inventory/inventory.yaml` — **13 rows owned by T16**
(`owner: T16`, issue #95 title row at line 85):

| row | dialects | T16 binding |
|---|---|---|
| create-table-temporary | mysql | session-local temp namespace, `TemporaryScope=local` |
| create-table-like | mysql + tidb | temp-first source bind, `ddl.table.like.source.exists.require` |
| create-table-select | mysql + tidb | MySQL CTAS audited; **TiDB CTAS = unsupported `create_table_select`** |
| drop-table | mysql + tidb | ordered multi-target semantics, IF EXISTS, dialect atomicity |
| truncate-table | mysql + tidb | lifecycle + stat invalidation |
| alter-table.rename-table | mysql | ordered pair evaluation, atomic rollback |
| create-global-temporary-table | tidb | global temp namespace |
| flashback-recover | tidb | vendor boundary |

`make ddl-inventory-gate` → `TestDDLInventoryContract` **ok** at `c889fb0c`
(gates-c889fb0c.log). Every T16 row carries `status_evidence` citing the T16
ordered-state closeout and `evidence`/`refs` file bindings to
`batch_state_namespace.go`, `lifecycle_t16_rules.go`, `T16.json` and corpus dirs.

## Version applicability (four anchors)

| anchor | image | T16 semantics bound |
|---|---|---|
| MySQL 5.7.44 | golden stack | DROP multi-target: sequential/partial; dup name → parse 1066; no temp-vs-persist catalog split differences |
| MySQL 8.0.46 | golden stack | DROP multi-target atomic veto on missing/dup; CTAS supported |
| MySQL 8.4.10 | golden stack | same as 8.0 family |
| TiDB 8.5.0 | golden stack | persistent catalog sequential + temp slot veto-shaped; **CTAS unsupported**; global temp tables |

Target-version input (T04 contract) resolves through `version_evidence.resolved`;
validator compares expected version against that field (see validator README).

## Standards gates at frozen HEAD `c889fb0c`

all rc=0 — see `gates/gates-c889fb0c.log`:
`make test`, `make ddl-golden-validator-test` (68), `make ddl-inventory-gate`,
`make pg-unit-test-gates` (cli/http/mcp/sdk), `make sql-corpus-gates`, `go vet`.

## ADR

`docs/decisions/2026-11-09-ddl-lifecycle-temporary-conditional.md`
(blob `d6a5a8c228f55e47ee49cc7674f286eddd77412b`) — records two-namespace model,
ordered transitions, conditional-clause gap semantics, rename ordering +
atomicity, TiDB CTAS unsupported boundary.

## Official-standard ↔ implementation mapping (ER2 required)

| form | official ref | impl/evidence type |
|---|---|---|
| DROP TABLE [IF EXISTS] t [,t…] [RESTRICT\|CASCADE] | MySQL 5.7/8.0/8.4 refman 13.1.32; TiDB DROP TABLE doc | GOLDEN + SOURCE-PROVEN + NATIVE-CURRENT |
| DROP TEMPORARY TABLE | refman — TEMPORARY scopes lookup to session temp | GOLDEN `drop-temp-keyword-miss`, `temp-shadow-*`; NATIVE-HISTORICAL probe |
| multi-DROP atomicity (8.x veto vs 5.7/TiDB sequential) | refman "DROP TABLE … errors" + observed server behavior | NATIVE-CURRENT golden anchors; OFFICIAL-DOC only for error classes 1051/1066 |
| dup name → 1066 parse refusal | refman + observed | GOLDEN `mysql80-drop-duplicate` |
| TRUNCATE [TABLE] t | refman 13.1.37; TiDB TRUNCATE doc | GOLDEN `truncate-suite`; stat invalidation SOURCE-PROVEN |
| RENAME TABLE a→b [,…] | refman 13.1.36 — atomic multi-pair, all-or-none | GOLDEN `rename-multi-atomic`, `rename-lastwrite-*`; OFFICIAL-DOC for atomicity claim |
| CREATE TABLE … LIKE | refman 13.1.20.4 — copies def, not FK/auto_inc | GOLDEN `like-members` + NATIVE-HISTORICAL member probe |
| CREATE TABLE … [AS] SELECT (CTAS) | refman 13.1.20.5 (MySQL); **TiDB doc: not supported** | MySQL GOLDEN; TiDB = unsupported `create_table_select` (OFFICIAL-DOC + GOLDEN vendor case) |
| CREATE TEMPORARY TABLE | refman; TiDB local+GLOBAL temp doc (DELETE ROWS only — PRESERVE refused 8200) | GOLDEN temp-*; TiDB `global-temp` supported / `global-preserve` vendor-refusal→unsupported |
| GLOBAL TEMPORARY (MySQL) | not a MySQL form — vendor reject | GOLDEN `*-global-temp-mysql-vendor` |
| TiDB FLASHBACK/RECOVER boundary | TiDB docs | inventory row bound; not a T16 positive claim |

Evidence-typing discipline: OFFICIAL-DOC entries bound only where cited;
native success claims limited to GOLDEN/NATIVE-CURRENT runs at frozen HEAD;
historical probes marked NATIVE-HISTORICAL, never re-labelled as fresh.
