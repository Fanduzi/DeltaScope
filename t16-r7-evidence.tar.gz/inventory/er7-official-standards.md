# T16-R2 ER7.5 — Official Standards (product version, doc ref, clause, case_id)

| form | product/version | official reference | clause | golden case_id |
|---|---|---|---|---|
| DROP TABLE multi + IF EXISTS + TEMPORARY | MySQL 5.7.44 / 8.0.46 / 8.4.10 | dev.mysql.com/doc/refman/{5.7,8.0,8.4}/en/drop-table.html | "DROP TABLE [IF EXISTS] tbl_name [, tbl_name] ..."; TEMPORARY keyword drops only session temp tables | `drop-multi-atomic/partial`, `drop-temp-keyword-miss`, `ifexists-*` |
| DROP TABLE errors 1051/1066 | MySQL all anchors | same + dev.mysql.com error refs | 1051 unknown table; 1066 not-unique table/alias in list | `drop-duplicate`, `*-partial` |
| TRUNCATE TABLE | MySQL / TiDB v8.5 | dev.mysql.com .../truncate-table.html; docs.pingcap.com/tidb/v8.5/sql-statement-truncate | single-table form only; resets stats/AI | `truncate-suite`, `truncate-inbound-fk` |
| RENAME TABLE multi-pair atomic | MySQL 8.0/8.4 | dev.mysql.com .../rename-table.html | "RENAME TABLE … operations are done atomically… all-or-none" | `rename-multi-atomic`, `rename-lastwrite-*` |
| CREATE TABLE … LIKE | MySQL / TiDB | dev.mysql.com .../create-table-like.html; docs.pingcap.com .../sql-statement-create-table-like | copies definition (cols/PK/idx/checks), NOT FK/AI counter | `like-members` + probes |
| CREATE TABLE … [AS] SELECT | MySQL 8.x vs TiDB v8.5 | dev.mysql.com .../create-table-select.html; **docs.pingcap.com: CTAS unsupported** | TiDB parses but does not support | `ctas-*` (mysql); `*-ctas-vendor` (tidb unsupported) |
| TEMPORARY TABLE | MySQL / TiDB local | dev.mysql.com .../create-temporary-table.html; docs.pingcap.com temporary-tables | session-scoped shadowing | `temp-shadow-*`, `temp-create-dup` |
| GLOBAL TEMPORARY (TiDB) | TiDB v8.5 only | docs.pingcap.com/tidb/v8.5/temporary-tables | GLOBAL temp: ON COMMIT DELETE ROWS only; **PRESERVE refused**; occupies catalog namespace (1050 name conflict — probed R2) | `tidb85-global-temp`, `global-preserve` (refusal), `drop-global-vs-temp`, `tidb-global-vs-persistent.txt` |
| GLOBAL TEMPORARY (MySQL) | MySQL all | not a MySQL form — parse→unsupported | vendor boundary | `*-global-temp-mysql-vendor` |
| LIKE from local-temp source (TiDB) | TiDB v8.5 | TiDB restriction — refuses local-temp LIKE source | `ddl.tidb.local_temporary.like` blocker | `t16-tidb85-like-tempsrc` (refusal) vs `mysql80-like-temp-source` (positive) |
