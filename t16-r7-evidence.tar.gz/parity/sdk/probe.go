//go:build ignore
package main

import (
	"context"
	"encoding/json"
	"fmt"
	"os"

	"github.com/Fanduzi/DeltaScope/pkg/deltascope"
)

func main() {
	sql, _ := os.ReadFile("/tmp/t16-r2/parity/sql-input.txt")
	res, err := deltascope.Audit(context.Background(), deltascope.Request{
		SQL:        string(sql),
		Dialect:    "mysql",
		ConfigPath: "/tmp/t16-golden2/T16/golden-policy-t16-denylist.yaml",
	})
	if err != nil {
		fmt.Fprintln(os.Stderr, "ERR", err)
		os.Exit(2)
	}
	b, _ := json.Marshal(res)
	fmt.Println(string(b))
}
