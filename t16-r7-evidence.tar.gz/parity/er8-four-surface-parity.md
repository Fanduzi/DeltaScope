# T16/#95 ER8 — Four-Surface Parity

Three representative T16 cases driven through CLI, SDK (`pkg/deltascope`),
HTTP (`deltascope-server`), MCP (`deltascope-mcp`, go-sdk stdio NDJSON) —
identical config `golden-policy-t16-lifecycle.yaml`, identical offline
(no-metadata) context.

## Cases

1. `multi-drop` — `CREATE t16_a; CREATE t16_b; DROP t16_a, t16_missing` (mysql)
   → **unknown-state evidence gap** representative (0 findings — gap parity, not finding parity)
2. `like-unknown` — `CREATE TABLE t16_l LIKE t16_src` (mysql)
   → **evidence-gap** representative
3. `ctas-tidb` — `CREATE TABLE t16_c AS SELECT * FROM t16_src` (tidb)
   → **vendor-unsupported** representative

## Result matrix (see `parity-summary.tsv` + per-surface raw I/O)

| case | CLI | SDK | HTTP | MCP |
|---|---|---|---|---|
| multi-drop | review/unverified +3 gaps | identical | HTTP 200, identical | isError absent, identical |
| like-unknown | review/unverified +2 gaps | identical | HTTP 200, identical | isError absent, identical |
| ctas-tidb | review/incomplete +`create_table_select` | identical | **HTTP 400**, identical body | **isError=true**, identical |

Gap rule IDs byte-identical across surfaces:
- multi-drop: `ddl.table.exists.create.forbid`×2 + `ddl.table.drop.exists.require`
- like-unknown: `ddl.table.like.source.exists.require` + `ddl.table.exists.create.forbid`

## Transport-level differences (expected, recorded — not semantic)

- HTTP maps the unsupported result to status **400** (body still carries
  full verdict `review`/`incomplete`/`create_table_select`).
- MCP maps it to `result.isError=true` with content text
  "audit includes unsupported statements" + structuredContent identical.
- CLI exit codes follow each verdict's documented exit mapping.

## Evidence files

- `cli/` — 3 raw JSON outputs
- `sdk/` — 3 raw JSON outputs (public `deltascope.Audit` API)
- `http/` — 3 request/response pairs + `server.log` (`-listen` flag; server
  built with postgres tags)
- `mcp/` — NDJSON frames (`tools/list` → `audit_sql` tool confirmed;
  `tools/call` responses)

No HTTP/transport error was mistaken for a semantic result; every comparison
read the structured semantic fields (verdict/coverage.status/gap rule_ids/
unsupported feature).

## Real policy finding parity (added after reviewer note)

The earlier `multi-drop` case produced evidence gaps only (0 findings), which
does not itself prove finding parity. Added a fourth representative —
`t16-denylist` policy, denylist-protected `t16_prot`:

SQL: `CREATE t16_a; CREATE t16_prot; DROP t16_a, t16_prot; CREATE t16_a(...)`

| surface | transport | verdict | coverage | findings |
|---|---|---|---|---|
| CLI | exit 1 | reject | unverified | `ddl.table.denylist.forbid` blocker @stmt1,@stmt2 |
| SDK | rc 0 | reject | unverified | identical |
| HTTP | 200 | reject | unverified | identical |
| MCP | isError absent | reject | unverified | identical |

Raw I/O: `cli/finding-denylist.json`, `sdk/finding-denylist.json`,
`http/finding-denylist.{req,resp}`, `mcp/finding-denylist.frames`.

Note: `config_path` is NOT an HTTP request field — the server binds policy at
startup (`--config`); per-request config would be a strict-decode 400. CLI/MCP
accept per-call config paths. Statement indices of findings are identical
across surfaces (stmt 1 + stmt 2), consistent with the fixed statement-index
binding.
