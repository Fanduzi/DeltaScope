#!/usr/bin/env python3
"""MCP audit over stdio NDJSON. Sends initialize/initialized/tools-call,
reads frames concurrently, attributes request+response to one invocation."""
import json, subprocess, sys, threading, time

BIN = "/Users/fan/GolangProjects/DeltaScope/bin/deltascope-mcp"
SQL = open("/tmp/t16-r2/parity/sql-input.txt").read().strip()
CFG = "/tmp/t16-golden2/T16/golden-policy-t16-denylist.yaml"

frames = [
    {"jsonrpc": "2.0", "id": 1, "method": "initialize",
     "params": {"protocolVersion": "2025-03-26", "capabilities": {},
                "clientInfo": {"name": "t16-r3-probe", "version": "0"}}},
    {"jsonrpc": "2.0", "method": "notifications/initialized"},
    {"jsonrpc": "2.0", "id": 2, "method": "tools/call",
     "params": {"name": "audit_sql",
                "arguments": {"sql": SQL, "dialect": "mysql",
                              "config_path": CFG}}},
]

p = subprocess.Popen([BIN], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE, text=True)
out, err = [], []
def rd(pipe, acc):
    for line in pipe:
        if line.strip():
            acc.append(line.rstrip())
t1 = threading.Thread(target=rd, args=(p.stdout, out))
t2 = threading.Thread(target=rd, args=(p.stderr, err))
t1.start(); t2.start()
reqlog = open("/tmp/t16-r2/parity/mcp/request-frames.ndjson", "w")
for f in frames:
    line = json.dumps(f)
    reqlog.write(line + "\n"); reqlog.flush()
    p.stdin.write(line + "\n"); p.stdin.flush()
    time.sleep(0.3)
time.sleep(2.0)
p.stdin.close(); p.wait(timeout=10)
t1.join(); t2.join()
with open("/tmp/t16-r2/parity/mcp/response-frames.ndjson", "w") as f:
    f.write("\n".join(out) + "\n")
with open("/tmp/t16-r2/parity/mcp/stderr.txt", "w") as f:
    f.write("\n".join(err) + "\n")
print(f"rc={p.returncode} response_frames={len(out)}")
for line in out:
    try:
        d = json.loads(line)
    except Exception:
        continue
    if d.get("id") == 2:
        r = d.get("result", {})
        print("isError:", r.get("isError"))
        body = r.get("structuredContent") or {}
        if not body:
            for c in r.get("content", []):
                if c.get("type") == "text" and c["text"].lstrip().startswith("{"):
                    body = json.loads(c["text"])
        print("verdict", body.get("verdict"),
              "cov", (body.get("coverage") or {}).get("status"))
        for s in body.get("statements", []):
            for fd in s.get("findings") or []:
                print("stmt", s.get("index"), fd.get("rule_id"),
                      fd.get("level"), fd.get("statement_index"),
                      fd.get("location"))
