# T16-R3 ER4 — Four-Surface Policy-Finding Provenance (fresh R3 execution)

Identical inputs across all surfaces:
- SQL: `sql-input.txt` — `CREATE TABLE t16_a (id INT); CREATE TABLE t16_prot
  (id INT); DROP TABLE t16_a, t16_prot; CREATE TABLE t16_a (id INT, c INT);`
- dialect: mysql; premise: offline (no metadata connection) on every surface
- policy: `/tmp/t16-golden2/T16/golden-policy-t16-denylist.yaml`
  SHA-256 `66d851f882ae744a1e4b5d23326eafdedf95ea26cda0baee4e1d51e7fb840fad`
- binaries built at frozen HEAD c889fb0c (SHA in `binary-sha.txt`):
  CLI 13f95361…, server 89d4c8e9…, mcp e6f63576…

| surface | transport | files | verdict | coverage | findings (stmt_index, rule_id, level, field stmt_index, line, col) |
|---|---|---|---|---|---|
| CLI | exit=1 | cli/invocation.txt, stdout.json, stderr.txt | reject | unverified | (1, ddl.table.denylist.forbid, blocker, 1, 1, 30); (2, …, 2, 1, 62) |
| SDK | rc=0 | sdk/probe.go, invocation.txt, stdout.json, stderr.txt | reject | unverified | identical |
| HTTP | 200 POST /v1/audit | http/invocation.txt, request.json, response.txt, server.log | reject | unverified | identical |
| MCP | stdio NDJSON, no isError | mcp/probe.py, request-frames.ndjson, response-frames.ndjson, stderr.txt, invocation.txt | reject | unverified | identical (structuredContent; location key order differs only) |

Notes:
- HTTP policy bound at server startup via `-config` (recorded in
  invocation.txt + server.log); request body carries sql+dialect only.
- MCP request frames (ids 1,2) and response frames are in the paired ndjson
  files — same invocation, same session.
- No surface output was synthesized from another surface; each directory
  holds that surface's own raw I/O.
- diagnostics=0, unsupported=0 on all four; evidence-gap context:
  offline existence checks → coverage unverified (expected premise gap).
