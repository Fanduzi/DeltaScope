# T16-R2 ER5 — Real Policy Finding Four-Surface Parity

Representative: `t16-denylist` policy, denylist-protected `t16_prot`.
SQL (identical all surfaces): `CREATE TABLE t16_a (id INT); CREATE TABLE
t16_prot (id INT); DROP TABLE t16_a, t16_prot; CREATE TABLE t16_a (id INT, c INT);`
Premise (identical): offline (no metadata), policy file
`golden-policy-t16-denylist.yaml` — bound per transport's own mechanism
(CLI `--config`, SDK `Request.ConfigPath`, HTTP server `--config` at startup,
MCP `config_path` tool argument). HTTP does not accept per-request config
(strict-decode 400 — transport fact, not semantics).

| surface | transport | verdict | coverage | findings (index, rule_id, level, statement_index, location) |
|---|---|---|---|---|
| CLI | exit 1 | reject | unverified | (1, denylist.forbid, blocker, stmt_index 1, {1,30}) ; (2, …, 2, {1,62}) |
| SDK | rc 0 | reject | unverified | identical |
| HTTP | 200 | reject | unverified | identical |
| MCP | isError absent | reject | unverified | identical |

Raw I/O: `finding-denylist.*` per surface. Statement indices AND
location.line/column identical everywhere — attribution parity proven.
R1 `multi-drop` retained as the evidence-gap representative (0 findings).
