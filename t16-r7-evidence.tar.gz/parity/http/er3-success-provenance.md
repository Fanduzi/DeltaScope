# T16-R6 — HTTP response-body provenance (CORRECTED)

## Defect corrected
R5's response-r5.txt was a COMBINED client transcript: the HTTP body plus a
client-generated `CURL_EXIT_MARKER HTTP_STATUS=200` trailer from `curl -w`.
Its SHA ca0d8877… covered body+marker, not the pure body. That claim is
SUPERSEDED by this document. The historical file is preserved unchanged as
`response-r5-combined-transcript-HISTORICAL.txt` (identified as combined).

## AUTHORITATIVE pure body
- file: `response-r5-body-AUTHORITATIVE.json` — ONLY the HTTP response-body
  bytes (marker trailer removed; boundary = the exact `CURL_EXIT_MARKER`
  split point recorded in the transcript)
- byte count: 3,449
- SHA-256: f505a09980fd59d7a53615833abf927f9becdbee3415dd267a09073a136fc821
- parses as exactly one JSON document (json.loads succeeds, verdict=reject)

## Request provenance
- curl argv: `curl -sv -w '\nCURL_EXIT_MARKER HTTP_STATUS=%{http_code}\n'
  -X POST -H 'Content-Type: application/json' -d @request.json
  http://127.0.0.1:18296/v1/audit`
- request body: request.json — sha256
  33fc6f1e1d2ee6268a561dfb391e76e5f61be852e7e3b0422f845bda15fdd4fb
- client exit code: 0
- HTTP status: 200 OK (response-r5-headers.txt: HTTP/1.1 200 OK,
  Content-Type: application/json)
- X-Request-Id: req-d790af1c0d85d22069c90ce5 — MATCHES server log entry
  (server-r5.log: "request_id":"req-d790af1c0d85d22069c90ce5", status 200,
  POST /v1/audit, duration 30ms)
- binary: bin/deltascope-server sha 89d4c8e998a6d55cc34d48a6997e4a2b3c3951299e27cfd3a546ec8274c4e4e2
- policy (startup-bound): golden-policy-t16-denylist.yaml sha
  66d851f882ae744a1e4b5d23326eafdedf95ea26cda0baee4e1d51e7fb840fad
- curl transport log: curl-verbose.txt; server log: server-r5.log

## Semantic tuple (verified on the pure body)
verdict=reject; coverage=unverified; findings=2 blockers
ddl.table.denylist.forbid — @statement_index 1 (line1,col30),
@statement_index 2 (line1,col62); diagnostics=0; unsupported=0.
Identical to CLI (exit1) / SDK / MCP tuples — transport status differs,
audit semantics identical.

## Historical failures preserved
- ATTEMPT 1: `-addr` flag error → curl_rc=7; then POST /audit → 404.
  Kept in invocation.txt — never presented as success.
