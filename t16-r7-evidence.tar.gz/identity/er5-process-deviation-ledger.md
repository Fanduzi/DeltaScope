# T16-R5 ER5 — Process deviation ledger

- Actual Worker: **Devin CLI / SWE-2 Max** (Cognition).
- Original work-order specified model: **GPT-6 + Extra High**.
- Disclosure history: reported verbatim in R1, R2, R3 and R4 receipts;
  no historical record was rewritten.
- Status: **PROCESS EXCEPTION — AWAITING AUTHORIZING-PARTY DECISION.**
  Evidence-only R5 work does not correct or retroactively authorize the
  model-selection deviation. Technical correctness is evaluated
  independently of this entry.
