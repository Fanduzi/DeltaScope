# T16-R2 ER8 — Worker Model Deviation (process record, pending adjudication)

- Work order specified: Worker = "Devin, GPT-6 + Extra High".
- Actual worker model: Devin CLI agent powered by **SWE-2 Max** (Cognition).
- R1 receipt disclosed this accurately (section A); the record is preserved
  unmodified here — disclosure ≠ retroactive authorization.
- Classification: PROCESS-DEVIATION awaiting reviewer adjudication.
  No semantic evidence depends on model identity; all artifacts are
  independently re-executable (scripts, validator, golden runner, probes
  included in-bundle).
