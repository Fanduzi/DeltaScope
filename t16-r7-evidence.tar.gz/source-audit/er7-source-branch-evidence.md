# T16-R2 ER7.2 — Source Branch Evidence @ HEAD c889fb0c

Blob SHAs (git rev-parse HEAD:<path>):
- `internal/application/audit/batch_state.go` — `5b70e662719bd630d0af1b31c2c8dc78c87336cc`
- `internal/application/audit/batch_state_namespace.go` — `6521cab34018565338d29154c2694eb7d2ad916c`
- `internal/application/audit/batch_state_fk.go` — `6bbf645f02150e77b59d6f7bdcee20493ee54338`
- `internal/domain/rule/ddl/lifecycle_t16_rules.go` — `196cc4ea88a2234fc9d2b0df1f52b1753f58e337`
- `internal/domain/spec/rename.go` — `26c3889924efd8d67253130992af7359cc4d6413`

## Key branches (file:line — condition → state effect → golden case)

### temp vs persistent namespace
- `batch_state_namespace.go:17-32` `boundNamespace` — two disjoint identities
  (persistent / temporary), `temporaryNamespaceKnown` decides when a temp slot
  settles existence.
- `bindTarget` (`:67`) — resolves each target into its namespace; temp slot
  wins in session scope (shadowing). GOLDEN `temp-shadow-drop`,
  `drop-temp-keyword-miss`.
- `bindSource` (`:218`) — LIKE/CTAS source resolution temp-first.
  GOLDEN `like-temp-source` (+TiDB refusal `ddl.tidb.local_temporary.like`).
- `invalidateTempKey` (`:262`) — temp slot invalidation on lifecycle events.

### multi-target DROP + dialect atomicity
- `applyDropTable` (`batch_state.go:3087`) — iterates EVERY target; per-member
  refusal vs landing. GOLDEN `denylist-multidrop` (protected tail still
  blocked), `drop-multi-temp-resolvable`.
- `multiDropVetoes` (`:3254`) — version/dialect bound: MySQL≥8.0 atomic veto
  on missing/dup; 5.7+TiDB sequential/partial. GOLDEN `drop-multi-atomic` vs
  `mysql57-drop-multi-partial`, `tidb85-drop-*`.
- `invalidateDropIdentities` (`:3068`) — landed members invalidate identities;
  vetoed statement publishes nothing (atomicity).

### RENAME left-to-right
- `RenamePairClasses` (`spec/rename.go:50`) — declared pairs evaluated
  left-to-right over an evolving disposition map; `RenamePairVerdict` =
  Src/Dst endpoint classes per pair. Destination vacated by an earlier pair
  becomes free for a later pair. GOLDEN `rename-lastwrite-free`,
  `rename-swap`, `rename-multi-atomic`.
- `applyRenameTable` (`batch_state.go:2511`), `bindRenameEndpoint` (`:2802`),
  `applyRenamePair` (`:2832`), `renamePairTransition` (`:2930`) —
  per-pair ordered transitions; refused pair rolls back the whole statement
  (originals map restored). GOLDEN `rename-lastwrite-rollback`.

### IF-conditional unknowns
- existence knowledge is three-state via `preState`/`resolve`
  (`batch_state.go:316,333`): known-exists / proven-absent / unknown →
  evidence gap, never guessed. GOLDEN `cli-*` offline gaps,
  `ifexists-absent-noop`.

### TRUNCATE + statistic invalidation
- `applyTruncateTable` (`:3492`) — row-risk finding + post-op statistic
  invalidation on the landed object; inbound-FK truth via
  `batch_state_fk.go` (`inbound` checks). GOLDEN `truncate-suite`,
  `truncate-inbound-fk`.
- `invalidateKey`/`invalidateBoundKey`/`invalidateAll`/`invalidateSchema`
  (`:898,3003,823,836`) — publication channels for landed vs refused vs
  partial outcomes (refusal publishes no post-state).

## Downstream shared-path audit (034e9859..HEAD, raw diffs)

Later commits touching these files: T15 stats fix `db17cf6d`
(alter_table_options paths only — does not enter lifecycle branches),
T22–T26 slices (RU/tablespace/SRS/SERVER/physical-layout — new statement
families + new invalidate channels for non-table objects). Reachability:
`batch_state_*_test.go` + `lifecycle_t16_rules_test.go` exercise the T16
branches directly and pass at HEAD; the 60-case golden + 8-task regression
chain re-executes every T16 path at the frozen HEAD (see regression/).
No downstream commit changes the dispositions/verdicts/bindings listed above.
