# T16/#95 ER1 — Source & History Audit

## Frozen implementation identity

| item | value |
|---|---|
| frozen HEAD | `c889fb0c82be2f67e9a3cf5c35064264ba91fe78` |
| tree | `6e6fea5eda634c4d8d991f8e23eee189b7412af3` |
| parent | `db17cf6d53418f776008848d94962c91f5471cdc` |
| branch | `milestone/mysql-tidb-ddl-completion` (local only, NOT pushed) |
| remote milestone | `d0c7cf3373167db7065d3027088a43c56ed6dbf5` (unchanged) |

## T16 implementation commit chain (on-branch order)

1. `7985c774` feat(ddl): T16 table lifecycle, temporary namespaces, rename ordering (#95)
   — core: `batch_state.go` (+1409 lines net), `batch_state_namespace.go` (new, 260),
   `batch_state_fk.go` (new, 88), `lifecycle_t16_rules.go`, `spec/rename.go`,
   ADR `2026-11-09-ddl-lifecycle-temporary-conditional.md`, CONTRACT.md,
   native probe logs + scripts, `T16.json` first corpus.
2. `882f5171` docs(verification): T16 evidence bundle @7985c774
3. `eb919d19` docs(t16): probes README index
4. `034e9859` fix(ddl): T16-R1 — multi-DROP temp veto, rename last-write,
   self-pair, inbound-FK truth (#95)
   — `batch_state.go` rework 188 lines, new `batch_state_t16r1_test.go` (489),
   `lifecycle_t16_rules.go` +98/-…, `spec/rename.go` +74, T16.json +383.
5. `8784346d` docs(verification): T16-R1 evidence bundle @034e9859
6. `b5e1b346` test(ddl-golden): harden inventory evidence, purge fixture
   credentials (cross-task, includes T16.json credential hygiene)
7. `c889fb0c` test(ddl-golden): drop empty password fields from T16 TiDB
   metadata cases — testdata-only, minimal diff (9 TiDB cli_metadata cases)

## Downstream-impact audit (034e9859..HEAD touching T16 core files)

Commits touching `batch_state.go`/`batch_state_namespace.go`/`batch_state_fk.go`/
`lifecycle_t16_rules.go`/`spec/rename.go` between the R1 fix and HEAD:

`db17cf6d` (T15 stats fix), `7fda04e9`..`6bc67bdd` (T22–T26 slices: TiDB RU
resource groups, T23 physical layout/cache, T24 MySQL CPU resource groups,
T25 tablespace, T26 SERVER/SRS/ALTER INSTANCE).

Audit verdict (per-file diff inspection): all downstream changes are **purely
additive** — new statement families, new namespace slices, new ordered-publication
channels for view/TTL/sequence/SRS. No T16 semantic was relaxed: persistent vs
temporary namespaces remain disjoint, ordered-state transitions unchanged,
rename left-to-right evaluation unchanged, multi-target atomicity tables unchanged.

Confirmation at frozen HEAD: T16 Golden 60/60 / 844 assertions PASS
(`artifact.json` in this bundle), plus the full T08–T15 regression chain
re-run at `c889fb0c` (see `regression/`).

## Working-tree posture

- tracked diff vs HEAD: clean except pre-existing untracked agent/evidence
  directories (`.agents/`, `.cursor/`, `artifacts/t16*/`, etc.) — preserved, not
  staged, not part of product identity.
- no product push, no tag, no release.
