# Performance Erratum (R2)

R1 warm.timing integer-ms samples: 16,16,17,17,18,19,19,19,20,20,20,22
- median = 19.0ms
- p95 nearest-rank = 22.0ms
- p95 linear-interpolation (type 7) = 20.9ms

R1 receipt's "p95li=21.7ms" is NOT supported by the samples. Formally revoked.
Raw high-precision timing was not persisted for those samples -> marked
unrecoverable; not reconstructed. A fresh reproducible measurement (with
per-sample argv/rc/ms) is provided in this directory.
