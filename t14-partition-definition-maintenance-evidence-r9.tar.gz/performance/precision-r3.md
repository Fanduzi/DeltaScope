# ER4-B — Performance Precision (R3)

R1 erratum (preserved): samples 16,16,17,17,18,19,19,19,20,20,20,22 →
median=19.0ms, p95nr=22.0ms, p95li(type7)=20.9ms; 21.7ms REVOKED;
high-precision raw not persisted → unrecoverable, not reconstructed.

R2 measurement (preserved verbatim): cold=60.41ms; warm n=12:
14.16,14.91,14.1,13.59,13.38,13.67,13.63,13.92,13.3,13.33,13.54,13.14 →
median=13.61ms, p95nr=14.91ms, p95li(type7)=14.50ms.

Reproduction template (exact argv; fixture bound by SHA):
  ./bin/deltascope audit --dialect mysql --sql "$(cat fixture.sql)" \
    --config <golden-policy-t14-reorg-warn-only.yaml> --format json
fixture.sql SHA=3db0a0de03f9e01b11e786b8d00f6fb37c12cd922cf38a38514734ffe413a260
generator.py SHA=a5d2e5c685a6847a9ca547b98ada3ae872c7fdf42ab75bd5d15f8141a6b31979
binary SHA=1fffdd765ef3055940ba7a77789d84a9acc7274204c5665e0ae3058a2a5bdd48
frozen HEAD=9d2c439c46f6faed434e91c8b54ebc82abbf0787
NOTE: samples.log argv column shows an abbreviated "..." — it is a display
truncation of the template above, NOT a claimed complete argv.
Saved originals: cold.stdout.json (non-empty audit proof: verdict=review,
50 statements, 5 findings). Warm per-sample stdout was hashed (sha16 in
samples.log); raw warm stdout was NOT persisted — not reconstructed.
Timing = DeltaScope audit-path latency only; no database DDL time claimed.
