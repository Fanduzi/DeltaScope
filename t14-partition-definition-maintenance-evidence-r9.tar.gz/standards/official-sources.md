# T14 Official Sources (per version)

- MySQL 5.7: https://dev.mysql.com/doc/refman/5.7/en/partitioning-management-range-list.html ,
  partitioning-management-hash-key.html , alter-table-partition-operations.html
  => ADD/REORGANIZE on RANGE/LIST; COALESCE on HASH/KEY only; REORGANIZE/ADD refused
  on HASH/KEY (native: 1512-class); maintenance ops; MyISAM tablespace transport 1031.
- MySQL 8.0: https://dev.mysql.com/doc/refman/8.0/en/partitioning-management-range-list.html ,
  partitioning-management-hash-key.html , alter-table-partition-operations.html ,
  partitioning-limitations.html => same lifecycle; CHECK/REPAIR/OPTIMIZE soft-fail
  status-table rows on non-partitioned/missing members (native-observed); REBUILD
  1505; DISCARD/IMPORT PARTITION TABLESPACE InnoDB-only.
- MySQL 8.4: same refman/8.4 pages => identical semantics observed at 8.4.10.
- TiDB v8.5: https://docs.pingcap.com/tidb/v8.5/partitioned-table/ ,
  /tidb/v8.5/sql-statement-alter-table/ , /tidb/v8.5/mysql-compatibility/
  => partitioned ALTER subset; six maintenance ops + whole-table tablespace
  transport refused at vendor boundary (native: 8200-class); COALESCE refused.
Labels: official (doc URL) + native-observed (probe logs/artifact) + source-proven.
