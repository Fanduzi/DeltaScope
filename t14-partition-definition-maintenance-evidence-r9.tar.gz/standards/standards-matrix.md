# T14 Standards Matrix — MySQL 5.7.44 / 8.0.46 / 8.4.10 / TiDB v8.5.0

Sources: docs/work-plans/t14-partition-topology/CONTRACT.md (native probe matrix),
probes p13_topology_maintenance.log, p14_nonpart_maintenance.log, p15_t14r1_matrix.log
— committed at frozen HEAD (blob SHAs in native/historical-probes-INDEX.txt).
Labels: official / native-observed / source-proven / bounded / unresolved.

| Action | Method | MySQL 5.7 | MySQL 8.0 | MySQL 8.4 | TiDB 8.5 | DeltaScope audit | Label |
|---|---|---|---|---|---|---|---|
| CREATE PARTITION BY | RANGE/LIST/HASH/KEY/LINEAR | accepted | accepted | accepted | accepted | audited; provably-invalid scheme (1493/1517/1495/mid-MAXVALUE/>8192) keeps table unpublished; valid scheme publishes member directory | official+native-observed+source-proven |
| ALTER ADD PARTITION | RANGE/LIST | accepted (defs or count) | same | same | accepted | audited; non-increasing bound->1493, dup name->1517, count 0->1514, >8192->1499 | native-observed+source-proven |
| ALTER ADD PARTITION | HASH/KEY | count-only | same | same | accepted | audited (applyAddPartitionCount) | native-observed+source-proven |
| ALTER REORGANIZE | RANGE/LIST | accepted | accepted | accepted | accepted | audited; 1520 bound/order, missing/non-adjacent member checks | native-observed+source-proven |
| ALTER REORGANIZE | HASH/KEY | refused (probe) | refused | refused | refused | applicability gate; TiDB vendor boundary | native-observed+source-proven |
| ALTER COALESCE | HASH/KEY | accepted n | accepted | accepted | refused (vendor) | audited; count0->1515, oversize->1509-class, vendor-refused keeps pre-state | native-observed+source-proven |
| ALTER PARTITION BY | all | accepted | accepted | accepted | bounded | transitionPartitionBy + partitionSchemeOutcome | source-proven+native-observed |
| REMOVE PARTITIONING | all | accepted | accepted | accepted | refused/bounded | transitionRemovePartitioning | native-observed+source-proven |
| CHECK PARTITION | all | rc=0 status rows (soft-fail non-part/missing) | same | same | vendor boundary | warning/notice model; never fabricated refusal | native-observed+source-proven |
| REPAIR PARTITION | all | soft-fail class | same | same | vendor boundary | same | native-observed+source-proven |
| OPTIMIZE PARTITION | all | InnoDB whole-table rebuild+re-analyze (native-observed) | same | same | vendor boundary | warn + scope metadata | native-observed+source-proven |
| REBUILD PARTITION | all | non-partitioned->1505 hard refusal | same | same | vendor boundary | blocker applicability/target | native-observed+source-proven |
| DISCARD PARTITION TABLESPACE | all | InnoDB-only; MyISAM->1031 (5.7) | same; MyISAM partitioning refused at CREATE 1178 | same | vendor boundary | own forbid blocker + engine fact | native-observed+source-proven |
| IMPORT PARTITION TABLESPACE | all | InnoDB-only; MyISAM->1031 | same | same | vendor boundary | applicability/target; unobserved engine owes target_table.engine gap | native-observed+source-proven |
| ANALYZE PARTITION | all | parses as AnalyzeTableStmt | same | same | same | outside T14 alter action space | source-proven |
| SUBPARTITION decl | any | CREATE-supported | same | same | unsupported | bounded gap (subpartitioned dir stays unknown — T13R2 provider test) | native-observed+bounded |

Refusal classes pinned: 1492/1493/1481/1495/1499/1505/1507/1508/1509/1514/1517/1519/1520/1735/1031/1178/1512.
Bound checks only on comparable numeric/MAXVALUE facts; uncomparable string-collation/expression bounds -> unvouch directory/evidence gap, never fabricated refusal. Expression bound items = capability boundary (incomplete coverage).
