// T14-R2 SDK parity probe — source preserved in archive
package main

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/Fanduzi/DeltaScope/pkg/deltascope"
)

func main() {
	req := deltascope.Request{
		SQL:        "ALTER TABLE t14r REORGANIZE PARTITION p0 INTO (PARTITION p1 VALUES LESS THAN (120), PARTITION p2 VALUES LESS THAN (200));",
		Dialect:    "mysql",
		ConfigPath: "/tmp/ddl-golden-t14/T14/golden-policy-t14-reorg-warn-only.yaml",
	}
	res, err := deltascope.Audit(context.Background(), req)
	if err != nil {
		fmt.Println("ERR", err)
		return
	}
	b, _ := json.MarshalIndent(map[string]any{"request": req, "verdict": res.Verdict, "coverage": res.Coverage, "summary": res.Summary, "statements": res.Statements, "unsupported": res.Unsupported}, "", " ")
	fmt.Println(string(b))
}
