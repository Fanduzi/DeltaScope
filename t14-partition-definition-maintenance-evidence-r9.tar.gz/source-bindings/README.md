# Source Bindings @ HEAD 9d2c439c (R2 complete set)

Each *.src file = `git show HEAD:<path>` verbatim at frozen HEAD.

| file | blob | key symbols (line) |
|---|---|---|
| partition_transitions.go.src | d56a813d | applyPartitionOperation(80) applyPartitionAction(358) transitionDropPartition(389) transitionReorganizePartition(491) reorganizeRangeOutcome(570) reorganizeListOutcome(683) publishReorganizedSpan(719) transitionAddPartitions(750) applyAddPartitionDefs(781) applyAddPartitionCount(884) transitionCoalescePartitions(929) transitionPartitionBy(970) partitionSchemeOutcome(1041) declaredSchemeOutcome(1069) transitionRemovePartitioning(1128) transitionPartitionMaintenance(1160) partitionTopologyUnproven(1222) |
| batch_state.go.src | 0c8ae529 | partitionMixedOutcome(3576) partitionModifierOutcome(3638) fullyAuditedStatement/partitionStateAdmissible/applyAlterTable/applyPartitionOperation |
| coverage.go.src | b8b64554 | unauditedActionVendor(807) partitionActionFeatureName(827) partitionBoundUnproven(849) partition-bound aspects(754,763) |
| partition_topology_rules.go.src | b2d97137 | tidbRefusedPartitionActions, tidbVendorGatedRule, applicability/target/warn rule bindings |
| partition_bounds.go.src | d3256bb1 | spec.PartitionBound/PartitionDef model |
| ddl.go.src | adf99e6b | spec.DDL/Alter partition fields |
| partition_defs.go.src | 4b9644d0 | parser partition extraction |
| extractor.go.src | ceafd4cd | TiDB parser DDL extraction |
| provider.go.src | 2d0250c4 | PartitionScheme/defs/Subpartitioned metadata reads |
| defaults_ddl_alter.go.src | 1afa409a | 11 warn/notice/forbid + 9 applicability + 8 target T14 rules (lines 80-206) |
| service.go.src | 7c47a9a8 | AuditSQL shared entry (L88) — all four surfaces funnel here |

bindings.txt (R1) lists the same SHAs + symbol grep output.
