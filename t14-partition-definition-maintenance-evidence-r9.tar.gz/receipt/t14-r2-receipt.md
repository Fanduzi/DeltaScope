# T14/#93 R2 Worker Receipt — T14-R2-EVIDENCE-CORRECTION-01

## A. Identity
GPT-6 + Extra High (极高), verified in session. Repo DeltaScope branch
milestone/mysql-tidb-ddl-completion @ 9d2c439c46f6faed434e91c8b54ebc82abbf0787
(tree bcec2a29, parent d6af1241). Remote d0c7cf33 unchanged; 317 local-only.
Zero tracked/staged diff. #79 OPEN, #92 CLOSED, #93 OPEN 0 comments.

## B. R1 Preservation + ER1 Archive Correction
R1 tar preserved byte-wise (SHA 52efaf90…, 429,293B, r1-preservation.txt).
Erratum: manifest was written before the final payload-index/receipt updates —
ordering bug, no evidence tampering. R2 manifest generated LAST; every payload
SHA/size re-computed; unified denominator = all payload files excl. manifest.tsv.

## C. ER2 Matrix + ER3 Counts/Performance
- acceptance-matrix-r2.md: 69 rows, actuals from artifact.json parsed/stdout/
  steps — never copied from expected. Reconciliation: required==executed==69,
  assertions==1099, dup=0, missing=0, extra=0.
- Focused erratum: 83 top-level + 159 subtests = 242 total RUN, 0 FAIL;
  T14-named 51+120=171. "242 top-level" revoked.
- Perf erratum: p95li 21.7 revoked → samples support 20.9ms; high-precision raw
  not persisted (marked unrecoverable). New reproducible run: cold 60.41ms,
  warm n=12 median 13.61ms, p95nr 14.91ms, p95li 14.50ms; per-sample argv/rc/ms;
  non-empty-run proof (verdict=review, 50 stmts, 5 findings, single stdout SHA).
- ER4 parity NEW RUN: CLI exit 1, SDK rc 0, HTTP 200, MCP id=2 — all
  review/complete/1 warning ddl.alter.reorganize_partition.warn/0 gaps/0 unsup;
  policy SHA e908f6cd… recomputed; three binaries vcs.revision=9d2c439c…;
  default-policy probe filed separately.

## D. ER4 Transport Parity
Full provenance in transports/: argv/rc/stdout/stderr per surface, SDK probe
source + Request fields, HTTP request+status+teardown, MCP init+tools/call
frames (id=1 init, id=2 call, isError ABSENT), complete structuredContent.

## E. ER5 Source/Standards/Native + ER6 Privacy
- Source: 11 verbatim git-show files + blob table incl. AuditSQL entry (service.go L88).
- Downstream: 43 commits mapped; sole T14-file touch = ed2ea4a7 (2 whole-table
  tablespace keys + EvidenceGaps forwarding) — hunk-level diff + reachability
  proof that T14 branches are unrelaxed.
- Standards: per-version official URLs (5.7/8.0/8.4 refman + TiDB v8.5 docs).
- Native bindings: historical probe blob SHAs + First Golden Path row-level
  verify (p1:120/p2:200/pmax order, total=2, p1∋100, p2∋150) distinguished
  from count-only checks.
- Privacy: R2 rescan 1177 benign hits classified (test names, mysql warnings,
  1045 errors, ephemeral refs) — zero real credentials.

## F. Gates/Golden Preservation + R2 Archive Ledger
Golden denominators preserved: T14 69/1099, T13 47/709, T12 25/294, T11 40/518.
Six gates rc=0 logs REUSED. Archive: t14-partition-definition-maintenance-evidence-r2.tar.gz
— 339 payloads (NEW 49 / REUSED 290, byte-verified vs R1), reuse-ledger.tsv
six-tuple provenance, manifest regenerated last.

## G. Remaining Blockers and Recommendation
All R2 work-order items addressed. No product defect found.
READY FOR REVIEWER T14 ACCEPTANCE
