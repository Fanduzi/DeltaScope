# T14/#93 R4 Worker Receipt — docs/evidence correction

## A. Identity
GPT-6 + Extra High (极高) verified. DeltaScope @ 9d2c439c46f6faed434e91c8b54ebc82abbf0787
(tree bcec2a29, parent d6af1241), branch milestone/mysql-tidb-ddl-completion.
Remote d0c7cf33 unchanged; 317 local-only. Zero tracked/staged diff.
#79 OPEN, #92 CLOSED, #93 OPEN 0 comments.

## B. R1–R3 archive preservation
R1 52efaf90…(429,293B) / R2 c36a83d0…(560,915B) / R3 d1864cfa…(585,290B)
all preserved byte-wise; no history rewritten.

## C. ER1 accounting
accounting-final-r4.md records the R3 357/359 denominator erratum. R4 order:
frozen path set → payload-index (all 367 paths incl. itself+ledger) →
reuse-ledger (REUSED-only, six-tuple provenance w/ source archive SHA +
member SHA/size) → manifest LAST → independent re-read validator:
manifest==index==physical=367, 0 sha/size mismatches, 0 dupes, 0 AppleDouble.

## D. ER2 source/reachability
downstream-impact-r4.md (FINAL): 7-branch condition table for 9012677d
(facts-nil/Refused/absent/unknown/action-nil/structuralUnknown/publish arms —
pure-T14 reachable branches preserve semantics; two tightened arms only add
honest refused/unproven); 2f01f500 if→switch proven 1:1; 8ce694df additive
Placement field (pure-T14 input → zero-value → unchanged); ed2ea4a7
EvidenceGaps forwarding can only add gaps; R2-tail tightenings mapped to
t14r2tail golden + T20R4 test names (32 fns listed). R2 downstream-impact.md
preserved, marked SUPERSEDED.

## E. ER3 matrix + ER4 commands/privacy
acceptance-matrix-r4.md + .tsv: 69 rows, gaps carry idx/rule_id/reason_code/
required_facts, db stderr untruncated, full db step details. verify-matrix-r4.py
runs on archive-relative paths with field-level compare: 69/69/1099/0/0/0,
0 field mismatches, FINAL PASS. r4-commands-and-results.log inside archive;
privacy rescan classified (zero real credentials).

## F. R4 archive integrity
t14-partition-definition-maintenance-evidence-r4.tar.gz
SHA-256 52acae3dd301a130fee539939994d7f24c3fba0784a8fc50384daf7b7d8463fe
size 606,701B; manifest 367 rows NEW=26/REUSED=341; all REUSED byte-identical
vs R1/R2 with recorded provenance.

## G. Remaining blockers / recommendation
All R4 items closed. No product defect found.
READY FOR REVIEWER T14 ACCEPTANCE
