# ER4 — Native Evidence Precision (R3)

Three DISTINCT evidence types kept separate:

1. db_ddl Golden (4 cases): native DDL rc + directory COUNT + data COUNT —
   count-level proof only (see matrix db step details).
2. cli_metadata Golden (46 cases): for t14-mysql80-golden — GROUP_CONCAT
   ordered directory "p1:120,p2:200,pmax:MAXVALUE" (order+bounds proof) AND
   SELECT COUNT(*) … PARTITION(p1)=1, PARTITION(p2)=1. Under the pinned seed
   (INSERT (100),(150)) and declared bounds (p1<120, p2<200), the single row
   in p1 is necessarily id=100 and the single row in p2 is id=150 — an
   inference from seed+bound+count, NOT a direct id read.
3. Historical p13 probe (committed blob 36b0d1f8, historical-committed NOT
   R3 NEW RUN): direct SELECT id FROM … PARTITION(pN) row-identity output
   where present — the only evidence type that reads actual id values.

No count output is described as having read row identity directly.
