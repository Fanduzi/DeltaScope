# T14 Native Evidence Bindings

## Historical committed probes (frozen-HEAD blobs)
- p13_topology_maintenance.log blob 36b0d1f8… — four-anchor topology+maintenance
  matrix; refusal classes 1492/1493/1481/1495/1499/1505/1507/1508/1509/1514/1517/
  1519/1520/1735; MyISAM DISCARD/IMPORT 1031 (5.7); MyISAM partitioning 1178 (8.x CREATE);
  OPTIMIZE InnoDB whole-table rebuild+re-analyze; TiDB six maintenance ops vendor refused.
- p14_nonpart_maintenance.log blob 51e6f77d… — non-partitioned targets.
- p15_t14r1_matrix.log blob daab0ef1… — T14-R1 remediation matrix.
Paths: native/historical-probes/… (archive-relative).

## R1 NEW RUN Golden DB evidence (artifact.json)
T14.meta.t14-mysql80-golden (anchor mysql80, version 8.0.46, image_digest
mysql@sha256:7dcddc01…, container deltascope-ddl-golden-mysql80):
- setup: CREATE RANGE fixture p0<200/pmax MAXVALUE + INSERT (100),(150), rc=0
- execute: REORGANIZE p0 -> p1<120,p2<200 rc=0
- verify (row-level, not TABLE_ROWS):
  1. GROUP_CONCAT ordered directory = "p1:120,p2:200,pmax:MAXVALUE"
     => p0 gone, p1 ordinal=1 bound=120, p2 ordinal=2 bound=200, pmax preserved
  2. COUNT(*)=2 total rows preserved
  3. SELECT … PARTITION (p1) => 1 (id=100 routes p1)
  4. SELECT … PARTITION (p2) => 1 (id=150 routes p2)
Capability note: golden verifies ORDERED directory+bounds AND per-partition
row routing — distinct from a pure count check. Historical p13 adds
pre/post SHOW CREATE + PARTITIONS rows for the same operation class.
db_syntax_negative cases (4) carry argv/rc/stderr/error_class in artifact.
