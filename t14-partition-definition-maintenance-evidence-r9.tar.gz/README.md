# T14 Evidence Archive R9 — FINAL TRACE+ACCOUNTING ROUND (docs/evidence only)

Authoritative entry points (latest wins; earlier docs are preserved history):
- Matrix: matrix/acceptance-matrix-r7.tsv + verify-matrix-r8.py (oracle reconcile) (69 rows × 23 cols, incl. db_steps/db_verify) — supersedes r4 matrix.
- Validator: matrix/verify-matrix-r8.py + verify-matrix-r8.out.txt (SELFTEST PASS). Older r5-r7 out logs kept as history.
- Branch trace: source-audit/t20r4-branch-trace-r9.md (FINAL — r6/r7/r8 superseded) — binds 7 applyPartitionOperation arms to named tests + golden cases. Evidence: focused/t20r4-focused-count1.stdout.txt (non-cached `-count=1`, 79 RUN/0 FAIL) + t20r4-test-names.txt (32 real fns).
- Source audit: source-audit/downstream-impact-r4.md (FINAL) — r2 downstream-impact.md SUPERSEDED.
- Accounting: accounting-final-r5.md convention preserved; manifest generated LAST; payload-index includes itself+ledger; reuse-ledger REUSED-only six-tuple.
- Privacy: privacy/scan-r9.txt — exact denominator = manifest payload count.

Rounds: R1 52efaf90…(429,293B) R2 c36a83d0…(560,915B) R3 d1864cfa…(585,290B)
R4 821be494…(607,631B, uploaded identity) R5 d40faab7…(618,368B) — all preserved.
Frozen product HEAD 9d2c439c46f6faed434e91c8b54ebc82abbf0787.
