# ER3 Focused-Test Count Erratum (R2)

R1 receipt said "242 top-level RUN" — WRONG. Corrected counts recomputed
independently from the original raw log focused/t14-focused.stdout.txt:

command: go test ./internal/... -run 'T14|Partition' -v   (rc=0)

- top-level `=== RUN` (no slash in name): 83
- subtest `=== RUN` (name contains "/"): 159
- total RUN lines: 242
- `--- FAIL`: 0

T14-named subset: total=171 = top-level 51 + subtests 120.

The 242 figure was the TOTAL RUN count mislabeled as top-level. Revoked.
