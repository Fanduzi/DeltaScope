# T20R4 seven-branch trace — R9 (FINAL). Replaces r8 trace.

Frozen HEAD 9d2c439c. partition_transitions.go applyPartitionOperation L80–145.
Tests (REUSED `-count=1` log, rc=0, 79 RUN/0 FAIL):
focused/t20r4-focused-count1.stdout.txt. Golden: real ids only, each checked
SQL → target state → source condition → actual transition result.

R8 erratum applied: T14.meta.t14-mysql80-discard-blocker is a POLICY reject
(ddl.alter.discard_partition_tablespace.forbid) — native execution rc=0 and
transitionPartitionMaintenance returns a non-nil updated snapshot for the
present InnoDB partition. Policy reject ≠ action refused; it does NOT prove
applyPartitionAction → nil. Removed from arm 5; recorded under arm 7 note
(policy reject still publishes the applied transition).

| # | branch (L#) | pure-T14 | T14+placement | state effect | Go-test proof | Golden proof |
|---|---|---|---|---|---|---|
| 1 | facts==nil → Applied (L85-88) | YES | n/a | legacy T14 path unchanged | — (default arm) | T14.cli.t14-cli-reorganize-warn; T14.meta.t14-mysql80-golden (no PLACEMENT in SQL) |
| 2 | PlacementRefused early return (L90-93) | NO | YES | atomic refusal, no mutation | TestT20R4RefusedMemberState, TestT20R4R2ConfiguredLevelsKeepRefusedState, TestT20R4R1RefusedCreateSilentWarn | Golden: NONE |
| 3 | tableAbsent → refuse (L98-103) | YES | YES | refused; no member publication | TestT20R4R1AbsentAndUnknownTargets | Golden: NONE |
| 4 | unknown target → Unproven (L104-118) | YES | YES | stays unknown; refs revoked; +existence fact | TestT20R4R1AbsentAndUnknownTargets, TestT20R4R2UnknownAggregateNoDropAuthorization, TestT20R4R2UnknownTargetRetirement, TestT20R4R2UnknownThenMissing, TestT20R4R2T14UnknownStaticFacts | Golden: NONE |
| 5 | applyPartitionAction → nil (L119-123) | YES | YES | proven refusal; pre-state kept | TestT20R4RefusedMemberState (placement side) | T14.meta.t14-mysql80-reorg-collision, -reorg-missing-source, -reorg-nonconsecutive, -reorg-shrink, -add-partitions-n-range (1492), -coalesce-range, -remove-nonpartitioned — each reject comes from the action's own applicability/structure check, NOT a policy rule. |
| 6 | structuralUnknown → Unproven (L132-139) | YES | YES | topologyUnproven + undecided + gaps | TestT20R4R1UncertainReorgThenDropOK, TestT20R4R1ReorgSurvivorRefAndRelease | T14.meta.t14r2tail-mysql80-pby-single-expr-member, T14.meta.t14r1-mysql80-string-domain-unproven (incomplete + gaps). Adjacent: reorg-then-truncate-absent = partition_absent member judgement (not PartitionNames==nil). |
| 7 | publishAlterMemberPlacements (L140-143) | YES ("" overrides) | YES | member defs + overrides stamped | TestT20R4R1QualifiedMemberRefs, TestT20R4R1ReorgSurvivorRefAndRelease, TestT20R4R2QualifiedMemberSameName, TestT20R4R1BoundSetSortedOutput, TestT20R4PublicBindingControls | T14.meta.t14-mysql80-golden, -mysql57-golden, -mysql84-golden, -tidb85-golden (review/complete; successor published, row-level proof in ER4); T14.meta.t14-mysql80-add-defs, -add-hash-defs, -add-then-drop, -partition-by-hash, -coalesce-hash. Policy-reject-with-applied-transition: T14.meta.t14-mysql80-discard-blocker (forbid finding + snapshot still published — policy level, not arm-5). Override stamping itself: Golden: NONE (T20 scope). |

Discipline: arms 2/3/4 and arm-7 override stamping = named-test proof only
(Golden: NONE). Other 25 T20R4 fns cover collector/provider/finding semantics.
