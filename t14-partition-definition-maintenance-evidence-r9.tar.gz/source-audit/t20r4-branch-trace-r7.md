# T20R4 seven-branch trace — R7 (FINAL). Replaces r6 trace.

Frozen HEAD 9d2c439c. Source: internal/application/audit/partition_transitions.go
`applyPartitionOperation` L80–145.
Test evidence (REUSED from R6, non-cached `-count=1`, rc=0, 79 RUN/0 FAIL):
focused/t20r4-focused-count1.stdout.txt; 32 real fn names:
source-audit/t20r4-test-names.txt.
Golden evidence: golden/artifact/cases/*.json — only REAL ids listed.
Proof discipline: Go-test proof and Golden proof recorded SEPARATELY;
no wildcard claims; branches without a direct golden say "Golden: NONE".

| # | branch (L#) | pure-T14 reachable | T14+placement | state effect | Go-test proof | Golden proof |
|---|---|---|---|---|---|---|
| 1 | facts==nil → bindingOutcome=Applied (L85-88) | YES | n/a (nil facts) | legacy T14 path runs unchanged | — (default path; exercised by every placement-free input) | T14.cli.t14-cli-reorganize-warn, T14.meta.t14-mysql80-reorg-collision (both: no PLACEMENT in SQL → facts==nil arm taken) |
| 2 | PlacementRefused early return (L90-93) | NO | YES | atomic refusal, zero mutation | TestT20R4RefusedMemberState, TestT20R4R2ConfiguredLevelsKeepRefusedState, TestT20R4R1RefusedCreateSilentWarn | Golden: NONE |
| 3 | proven-absent target → refuse (L98-103) | YES | YES | refused; no member publication | TestT20R4R1AbsentAndUnknownTargets | T14.meta.t14-mysql80-reorg-then-truncate-absent (alter on absent table → reject/complete). Edge note: t14r1-mysql80-create-decreasing-stays-absent proves absent-state PERSISTENCE, not this arm's entry. |
| 4 | unknown target → Unproven (L104-118) | YES | YES | stays unknown; refs revoked; +target_table.existence fact | TestT20R4R1AbsentAndUnknownTargets, TestT20R4R2UnknownAggregateNoDropAuthorization, TestT20R4R2UnknownTargetRetirement, TestT20R4R2UnknownThenMissing, TestT20R4R2T14UnknownStaticFacts | Golden: NONE (no golden case id marks target-level unknown; member-level unknown is arm 6) |
| 5 | applyPartitionAction → nil → Refused (L119-123) | YES | YES | proven refusal; exact pre-state kept | TestT20R4RefusedMemberState (placement side) | T14.meta.t14-mysql80-reorg-collision, T14.meta.t14-mysql80-reorg-missing-source, T14.meta.t14-mysql80-reorg-nonconsecutive (reject verdicts = action refused) |
| 6 | structuralUnknown → Unproven (L132-139) | YES | YES | topologyUnproven + undecided placements + undecided facts | TestT20R4R1UncertainReorgThenDropOK, TestT20R4R1ReorgSurvivorRefAndRelease | T14.meta.t14r2tail-mysql80-pby-single-expr-member, T14.meta.t14r1-mysql80-string-domain-unproven (incomplete coverage + evidence gaps present) |
| 7 | publishAlterMemberPlacements → Applied (L140-143) | YES ("" overrides) | YES (explicit) | member defs + overrides stamped | TestT20R4R1QualifiedMemberRefs, TestT20R4R1ReorgSurvivorRefAndRelease, TestT20R4R2QualifiedMemberSameName, TestT20R4R1BoundSetSortedOutput, TestT20R4PublicBindingControls | Golden: NONE for override stamping (placement semantics are T20 scope); T14-side member publication proven by review/complete reorg+add cases e.g. T14.cli.t14-cli-reorganize-warn, T14.meta.t14-mysql80-add-partitions-n-range |

Coverage claim (limited): arms 1/3/5/6 have named golden cases AND/OR named
tests as bound above; arms 2/4 have named-test proof only (Golden: NONE);
arm 7 override stamping is T20-test proof only. The other 25 of 32 T20R4
functions cover collector/provider/finding/subpartition semantics — NOT
claimed as arm coverage. No "all 69 cases" claims made.
