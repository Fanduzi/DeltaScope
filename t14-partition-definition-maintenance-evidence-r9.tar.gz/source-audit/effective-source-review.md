# T14 Effective Source Review @ frozen HEAD 9d2c439c
## Commits (ancestor-of-HEAD=y, in-remote-milestone=n for all)
b5b2ac7007121c9319e1ab55f568b462a49f9af3 feat(audit) T14 original (34 files)
14850fb23eb525d489099b27bb8b033efe3e2a9e docs T14 evidence bundle
c29ebc38dc5fd289ca92f23c13f4d925250449df feat(audit) T14-R1 remediation
17539dbbaddb2168a4ac76679880330f4bc52c39 docs T14-R1 evidence bundle
ce9a73dc3b193d4668ef12ffa5874db6a12d86bd fix(audit) T14-R2 remediation
Full file lists: t14-commit-ledger.txt (1310 lines).

## Source chain @ HEAD
parser tidb/partition_defs.go (4b9644d0) -> extractor.go (ceafd4cd)
  -> spec PartitionDef/PartitionBound partition_bounds.go (d3256bb1), ddl.go (adf99e6b)
  -> metadata mysql provider.go (2d0250c4, PartitionScheme/defs/Subpartitioned)
  -> rules partition_topology_rules.go (b2d97137) + defaults_ddl_alter.go (1afa409a)
  -> state partition_transitions.go (d56a813d) + batch_state.go (0c8ae529)
  -> coverage coverage.go (b8b64554)
  -> AuditSQL shared entry -> cli/http/mcp/pkg/deltascope.
