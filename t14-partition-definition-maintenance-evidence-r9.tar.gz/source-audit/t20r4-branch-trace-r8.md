# T20R4 seven-branch trace — R8 (FINAL). Replaces r7 trace.

Frozen HEAD 9d2c439c. Source: partition_transitions.go applyPartitionOperation
L80–145. Test evidence (REUSED, `-count=1`, rc=0, 79 RUN/0 FAIL):
focused/t20r4-focused-count1.stdout.txt. Golden: real case ids only, each
checked SQL → target state → source condition → actual transition.
R7 errata applied: (a) reorg-then-truncate-absent is partition_absent
(member-level) NOT tableAbsent — withdrawn from arm 3, kept under arm 6-adjacent
member-level note; (b) add-partitions-n-range is applicability reject (1492) —
withdrawn from arm 7, belongs to arm 5 refusals.

| # | branch (L#) | pure-T14 | T14+placement | state effect | Go-test proof | Golden proof |
|---|---|---|---|---|---|---|
| 1 | facts==nil → Applied (L85-88) | YES | n/a | legacy T14 path unchanged | — (default arm; every placement-free input) | T14.cli.t14-cli-reorganize-warn (REORG, no PLACEMENT → review/complete); T14.meta.t14-mysql80-golden (same path → p1/p2/pmax successor) |
| 2 | PlacementRefused early return (L90-93) | NO | YES | atomic refusal, no mutation | TestT20R4RefusedMemberState, TestT20R4R2ConfiguredLevelsKeepRefusedState, TestT20R4R1RefusedCreateSilentWarn | Golden: NONE |
| 3 | tableAbsent → refuse (L98-103) | YES | YES | refused; no member publication | TestT20R4R1AbsentAndUnknownTargets | Golden: NONE (no case alters a proven-absent TABLE; create-decreasing-stays-absent proves absent-state persistence only, not this arm's entry) |
| 4 | unknown target → Unproven (L104-118) | YES | YES | stays unknown; refs revoked; +existence fact | TestT20R4R1AbsentAndUnknownTargets, TestT20R4R2UnknownAggregateNoDropAuthorization, TestT20R4R2UnknownTargetRetirement, TestT20R4R2UnknownThenMissing, TestT20R4R2T14UnknownStaticFacts | Golden: NONE (member-level unknown is arm 6) |
| 5 | applyPartitionAction → nil (L119-123) | YES | YES | proven refusal; pre-state kept | TestT20R4RefusedMemberState (placement side) | T14.meta.t14-mysql80-reorg-collision, -reorg-missing-source, -reorg-nonconsecutive, -reorg-shrink, -add-partitions-n-range (native 1492), -coalesce-range, -remove-nonpartitioned, -discard-blocker — all reject/complete = action refused |
| 6 | structuralUnknown → Unproven (L132-139) | YES | YES | topologyUnproven + undecided + gaps | TestT20R4R1UncertainReorgThenDropOK, TestT20R4R1ReorgSurvivorRefAndRelease | T14.meta.t14r2tail-mysql80-pby-single-expr-member, T14.meta.t14r1-mysql80-string-domain-unproven (incomplete coverage + evidence gaps). Member-level absent note: t14-mysql80-reorg-then-truncate-absent exercises partition_absent member judgement, NOT this arm's PartitionNames==nil condition — recorded as adjacent coverage, not arm-6 proof. |
| 7 | publishAlterMemberPlacements (L140-143) | YES ("" overrides) | YES | member defs + overrides stamped | TestT20R4R1QualifiedMemberRefs, TestT20R4R1ReorgSurvivorRefAndRelease, TestT20R4R2QualifiedMemberSameName, TestT20R4R1BoundSetSortedOutput, TestT20R4PublicBindingControls | T14.meta.t14-mysql80-golden, -mysql57-golden, -mysql84-golden, -tidb85-golden (review/complete; successor dir published per ER4 native proof); T14.meta.t14-mysql80-add-defs, -add-hash-defs, -add-then-drop, -partition-by-hash, -coalesce-hash (applied mutations). Placement-override stamping itself: Golden: NONE (T20 scope). |

Claim discipline: each golden listed was checked SQL→state→condition→result;
arms 2/3/4 and arm-7 override stamping have named-test proof only (Golden: NONE).
25 other T20R4 fns cover collector/provider/finding semantics — not claimed here.
