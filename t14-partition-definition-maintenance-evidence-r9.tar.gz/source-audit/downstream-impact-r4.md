# T14 Downstream Impact — FINAL (R4). R2 downstream-impact.md = SUPERSEDED.

Real diffs in source-audit/diff-<sha>.txt (frozen HEAD 9d2c439c).

## 9012677d — applyPartitionOperation per-condition reachability (lines 80-145)

| branch | entry condition | pure-T14 input reachable? | T14+placement reachable? | partition-state effect | placement-state effect | findings | gaps/unsupported |
|---|---|---|---|---|---|---|---|
| facts==nil → bindingOutcome=Applied | no placement clauses in statement | YES (facts nil) | n/a | none (falls through to old path) | none | unchanged | unchanged |
| PlacementRefused (early return) | any collected premise refused | NO (pure T14 SQL never yields placement facts) | YES | statement refuses atomically; state untouched | refused outcome recorded | placement findings only | none added |
| target proven-absent (tableAbsent) | entry.state==tableAbsent | YES | YES | statement refused; no member publication — TIGHTER than old code (old code `continue` silently) | refused | none new | none |
| target unknown (!ok / not present / nil shape) | unresolvable or non-present entry | YES | YES | stays unknown; refs revoked under resolved identity | completeness undecided | none | +target_table.existence undecided fact |
| applyPartitionAction → nil | proven T14 refusal | YES | YES | exact pre-state preserved (unchanged semantics) | refused recorded | unchanged | unchanged |
| structuralUnknown (memberMutation && next.PartitionNames==nil) | unvouched directory | YES (add/reorg/partition with unproven members) | YES | topologyUnproven (was: publish unproven dirs) — TIGHTER | placements marked undecided | unchanged | +undecided binding facts |
| publishAlterMemberPlacements | applied + vouched dir | YES (defs published as "" overrides — metadata-only) | YES | member defs published (same as before) | explicit overrides stamped | unchanged | unchanged |

Verdict per item: pure-T14 semantics preserved in all reachable branches; the two
new tightened arms (proven-absent refusal, structural-unknown → unproven) only
convert previously-silent/optimistic paths into refused/unproven — direction is
strictly more honest, never relaxed. Coverage/gaps can only increase.

Tests covering these branches (batch_state_t20r4_test.go, 32 test fns):
TestT20R4R1AbsentAndUnknownTargets, TestT20R4RefusedMemberState,
TestT20R4R1ReorgSurvivorRefAndRelease, TestT20R4R1UncertainReorgThenDropOK,
TestT20R4R1SubpartitionAspectBoundary, TestT20R4R1QualifiedMemberRefs,
TestT20R4R2UnknownAggregateNoDropAuthorization + 25 more (file lists all).
Raw test log: focused/t14-focused.stdout.txt (83+159=242 RUN, 0 FAIL).
Golden: T14 69/69 re-run at post-change HEAD.

## 2f01f500 — if/else-if → switch equivalence
Condition set identical: alter.Action=="partition" vs =="reorganize_partition",
mutually exclusive, same bodies. Zero semantic delta (20-line diff is 1:1).

## 8ce694df — PartitionDef.Placement (additive)
Parser now copies member PLACEMENT POLICY option into def.Placement. For pure-T14
input (no placement option) the field stays zero-value → all existing reads
unchanged. No bound/method/count logic touched.

## ed2ea4a7 — EvidenceGaps forwarding + two whole-table keys
tidbVendorGatedRule.EvidenceGaps forwards only when wrapped rule implements
rule.EvidenceReporter. T14 vendor-gated rules that implement it may now surface
their declared gaps under the same gate — can only ADD honest gaps, never findings.
"import_tablespace"/"discard_tablespace" keys = whole-table actions, unreachable
from partition-level action names.

## 85b6d01a + 2119f230 — T14 R2-tail tightenings (in T14 ledger-r3)
- 85b6d01a: lone member with unprojectable bound → undecidable (was auto-pass).
- 2119f230: pair check independent of member comparability — proven MAXVALUE
  predecessor refuses whatever follows.
Golden: t14r2tail-mysql80-pby-single-expr-member + string-domain-unproven cases.

## Final conclusion
- Pure-T14 input semantics: PRESERVED (all diffs are tightenings or additive).
- T14+placement combinations: bounded changes — refused/absent/unknown arms and
  member-ref bookkeeping (accepted scope).
- Honest gap/coverage changes: +undecided binding facts, +existence undecided.
- Untested branches: none identified (every arm maps to named test/golden above).
No DEFECT found.
