# T20R4 seven-branch trace — R6 (FINAL). Replaces R5 trace (not archived).

Frozen HEAD: 9d2c439c. Source: internal/application/audit/
partition_transitions.go `applyPartitionOperation` L80–145.
Execution evidence: focused/t20r4-focused-count1.stdout.txt
(`go test ./internal/application/audit/ -run 'TestT20R4' -v -count=1`,
rc=0, 79 RUN, 0 FAIL, non-cached). Test names cross-checked against
source-audit/t20r4-test-names.txt (32 real functions in
batch_state_t20r4_test.go). Golden evidence: golden/artifact/cases/.

| # | branch (L#) | pure-T14 reachable | T14+placement reachable | state effect | binding tests | golden case |
|---|---|---|---|---|---|---|
| 1 | facts==nil → bindingOutcome=Applied (L85-88) | YES — pure-T14 SQL yields no placement clauses | YES (implicitly) | falls through to legacy T14 path unchanged | — (default path exercised by every placement-free golden) | all 69 T14 cases |
| 2 | PlacementRefused early return (L90-93) | NO | YES | statement refused atomically, zero mutation | TestT20R4RefusedMemberState, TestT20R4R2ConfiguredLevelsKeepRefusedState, TestT20R4R1RefusedCreateSilentWarn | T14.meta.*-vendor-* cases (gate level) |
| 3 | proven-absent target (L98-103) | YES | YES | refused; no member publication (tighter than pre-T20 silent continue) | TestT20R4R1AbsentAndUnknownTargets | T14.meta.*-absent cases |
| 4 | unknown target (L104-118) | YES | YES | stays unknown; refs revoked; +target_table.existence undecided fact | TestT20R4R1AbsentAndUnknownTargets, TestT20R4R2UnknownAggregateNoDropAuthorization, TestT20R4R2UnknownTargetRetirement, TestT20R4R2UnknownThenMissing, TestT20R4R2T14UnknownStaticFacts | T14.meta.*unknown* cases |
| 5 | applyPartitionAction → nil (L119-123) | YES | YES | proven refusal: pre-state preserved | TestT20R4RefusedMemberState | T14 refusal Golden cases |
| 6 | structuralUnknown arm (L132-139) | YES | YES | topologyUnproven + undecided placements + undecided-facts gaps | TestT20R4R1UncertainReorgThenDropOK, TestT20R4R1ReorgSurvivorRefAndRelease | T14.meta.t14r2tail-*-single-expr-member |
| 7 | publishAlterMemberPlacements (L140-143) | YES (publishes "" overrides) | YES | member defs + explicit overrides stamped | TestT20R4R1QualifiedMemberRefs, TestT20R4R1ReorgSurvivorRefAndRelease, TestT20R4R2QualifiedMemberSameName, TestT20R4R1BoundSetSortedOutput, TestT20R4PublicBindingControls | T14.meta.*reorg*/add cases |

Coverage claim (limited): branches 1–7 each have ≥1 named non-cached test
and/or golden case as bound above. The remaining 25 of 32 T20R4 functions
cover collector/provider/finding/subpartition semantics (see test-names list);
they are NOT claimed as per-branch coverage for the seven mutation arms.

Uncovered bounds (honest): pure-T14 reachability of arm 3 (proven-absent
without placement facts) and arm 4 relies on T14 golden absent/unknown cases
rather than a dedicated T20R4 test name; arm 5 pure-T14 refusal is covered by
T14 golden refusal cases, T20R4RefusedMemberState covers the placement side.
