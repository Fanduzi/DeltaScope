# T14 Downstream Impact — ce9a73dc..HEAD (43 commits touching shared paths)

See downstream-commits-full.txt (43 commits) + downstream-file-map.txt (per-commit file map).

## Only commit touching a T14-owned file
ed2ea4a7 "feat: T25 MySQL tablespace family auditing (#104)" touched
internal/domain/rule/ddl/partition_topology_rules.go. Real diff: downstream-t14rules.diff (49 lines).

Hunks:
1. tidbRefusedPartitionActions gained "import_tablespace"/"discard_tablespace" —
   WHOLE-TABLE tablespace actions (T25), NOT the partition-level forms T14 owns.
   Reachability: T14 actions map to the original six names
   (rebuild/check_partitions/optimize/repair/import_partition_tablespace/
   discard_partition_tablespace). The two new keys are reachable only from
   ALTER TABLE ... IMPORT/DISCARD TABLESPACE (whole-table), never from
   ... PARTITION ... TABLESPACE. No T14 branch relaxed.
2. tidbVendorGatedRule.EvidenceGaps forwarding — surfaces (never suppresses)
   evidence gaps under the same TiDB vendor gate. Can only add gaps, not findings.

## Other shared-path commits
batch_state.go / coverage.go touched by T18-T26 commits for new statement
families (placement, TTL, sequence, RG, tablespace, server/SRS, alter instance).
All diffs add new action branches; none modify partition transitions or
partition outcome functions (file-map verifies no partition_transitions.go /
partition_bounds.go / partition_defs.go changes after ce9a73dc).

## Regression proof
T13 47/47/709, T12 25/25/294, T11 40/40/518, T14 69/69/1099 all re-run green
at frozen HEAD — combined with the diff-level reachability above.
