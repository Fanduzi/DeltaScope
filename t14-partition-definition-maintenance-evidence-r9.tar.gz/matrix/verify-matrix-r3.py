import json
a=json.load(open("/tmp/ddl-golden-t14/T14/artifact.json"))
o=json.load(open("/Users/fan/GolangProjects/DeltaScope/testdata/ddl-golden/T14.json"))
cases=a["cases"];ids=[c["case_id"] for c in cases]
tot=sum(len(c.get("assertions") or []) for c in cases)
req=set(o["required_case_ids"])
rows=[l for l in open("/tmp/t14-r1-archive/t14-r3/archive/matrix/acceptance-matrix-r3.md") if l.startswith("| T14.")]
print("required",len(req),"executed",len(ids),"matrix_rows",len(rows),"assertions",tot,"duplicate",len(ids)-len(set(ids)),"missing",len(req-set(ids)),"extra",len(set(ids)-req))
print("all_pass",all(c.get("status") in ("pass","passed") for c in cases))
