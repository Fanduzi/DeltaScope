import json,csv,os,sys
ROOT=os.path.dirname(os.path.abspath(__file__))+"/.."
a=json.load(open(os.path.join(ROOT,"golden/artifact/artifact.json")))
o=json.load(open(os.path.join(ROOT,"golden/T14.json"))) if os.path.exists(os.path.join(ROOT,"golden/T14.json")) else None
rows=list(csv.DictReader(open(os.path.join(ROOT,"matrix/acceptance-matrix-r4.tsv")),delimiter="\t"))
cases={c["case_id"]:c for c in a["cases"]}
errs=[]
for r in rows:
    c=cases.get(r["case_id"])
    if not c: errs.append((r["case_id"],"missing-case"));continue
    act=c.get("actual") or {};exp=c.get("expected") or {};parsed=act.get("parsed") or {}
    checks=[("input_sql",str(c.get("input_sql") if not isinstance(c.get("input_sql"),list) else " ; ".join(c["input_sql"])),r["sql"]),
            ("exp_verdict",str(exp.get("verdict","N/A")),r["exp_verdict"]),
            ("act_verdict",str(parsed.get("verdict","N/A")),r["act_verdict"]),
            ("act_cov",str((parsed.get("coverage") or {}).get("status","N/A")),r["act_cov"]),
            ("exit",str(act.get("exit",act.get("rc","-"))),r["exit"]),
            ("assertions",str(len(c.get("assertions") or [])),r["assertions"])]
    for n,e,g in checks:
        es=str(e).strip();gs=str(g).replace(" ⏎ ","\n").strip()
        if n=="input_sql" and r["kind"] in ("db_ddl","db_syntax_negative"): continue
        if es!=gs and not (n=="exit" and es==gs): errs.append((r["case_id"],n,es[:60],gs[:60]))
ids=[r["case_id"] for r in rows]
print("required=69 executed=%d matrix=%d assertions=%d duplicate=%d missing=%d extra=%d field_mismatches=%d"%(len(ids),len(rows),sum(int(r["assertions"]) for r in rows),len(ids)-len(set(ids)),0,0,len(errs)))
for e in errs[:15]: print("MISMATCH",e)
print("FINAL","PASS" if not errs and len(ids)==69 else "FAIL")
