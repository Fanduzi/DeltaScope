#!/usr/bin/env python3
# T14 matrix validator R7 — archive-relative, full untruncated fields, dynamic
# required set, evidence-path binding, negative self-check, nonzero exit.
import json,csv,os,sys,copy,subprocess
ROOT=os.path.dirname(os.path.abspath(__file__))+"/.."
def unesc(s): return (s or "").replace(" ⏎ ","\n").replace("\\|","|")
def esc(s): return str(s if s is not None else '').replace('|','\\|').replace('\n',' ⏎ ').replace('\t',' ')
def norm(x):
    if isinstance(x,list): return " ; ".join(str(i) for i in x)
    return str(x) if x is not None else ""
def gapi(act):
    return ";".join(f"idx{s.get('index')}:{g.get('rule_id','-')}:{g.get('reason_code','-')}:{','.join(g.get('required_facts') or [])}"
        for s in (act.get('parsed') or {}).get('statements') or [] for g in s.get('evidence_gaps') or [])
def egaps(exp):
    e=exp.get('evidence_gaps')
    if e is None: return 'N/A'
    if isinstance(e,int): return str(e)
    if isinstance(e,list):
        return ";".join(f"idx{g.get('index')}:{g.get('rule_id','-')}:{g.get('reason_code','-')}:{','.join(g.get('required_facts') or [])}" for g in e) or '[]'
    return str(e)
def findings_of(act):
    return ";".join(f"{f.get('rule_id')}@{f.get('level')}"
        for s in (act.get('parsed') or {}).get('statements') or [] for f in s.get('findings') or [])
def exp_steps(act):
    return ";;".join(f"{s.get('name')}|{s.get('sql')}|rc={s.get('rc')}|out={s.get('stdout')}|err={s.get('stderr')}" for s in act.get('steps') or [])
def exp_verify(act):
    return ";;".join(f"{s.get('name')}.{v.get('assert')}|{v.get('sql')}|rc={v.get('rc')}|out={v.get('output')}|err={v.get('stderr')}"
        for s in act.get('steps') or [] for v in s.get('verify') or [])
def exp_neg(act):
    return f"argv={' '.join(act.get('argv') or [])}|rc={act.get('rc')}|stdout={act.get('stdout','')}|stderr={act.get('stderr','')}|error_class={act.get('error_class','-')}"
def load():
    a=json.load(open(os.path.join(ROOT,"golden/artifact/artifact.json")))
    o=json.load(open(os.path.join(ROOT,"golden/T14.json")))
    rows=list(csv.DictReader(open(os.path.join(ROOT,"matrix/acceptance-matrix-r7.tsv")),delimiter="\t"))
    return a,o,rows
def compare(a,required,rows,verbose=True):
    cases={c["case_id"]:c for c in a["cases"]}
    errs=[]
    for r in rows:
        c=cases.get(r["case_id"])
        if not c: errs.append((r["case_id"],"missing-case"));continue
        act=c.get("actual") or {};exp=c.get("expected") or {};parsed=act.get("parsed") or {};kind=c["kind"]
        checks=[("kind",norm(kind),r["kind"]),("dialect",norm(c.get("dialect","-")),r["dialect"]),
            ("anchor",norm(c.get("anchor") or "-"),r["anchor"]),("policy",norm(c.get("policy_profile") or "-"),r["policy"]),
            ("exp_verdict",norm(exp.get("verdict","N/A")),r["exp_verdict"]),
            ("act_verdict",norm(parsed.get("verdict","N/A")),r["act_verdict"]),
            ("exp_cov",norm(exp.get("coverage","N/A")),r["exp_cov"]),
            ("act_cov",norm((parsed.get("coverage") or {}).get("status","N/A")),r["act_cov"]),
            ("exit",norm(act.get("exit",act.get("rc","-"))),r["exit"]),
            ("assertions",norm(len(c.get("assertions") or [])),r["assertions"]),
            ("unsup",norm(len(parsed.get("unsupported") or [])),r["unsup"]),
            ("exp_gaps",egaps(exp),r["exp_gaps"]),
            ("result",norm(c.get("status")),("pass" if r["result"]=="PASS" else r["result"]))]
        # evidence-path binding: file must exist and its case_id must match
        ep=os.path.join(ROOT,r["evidence"])
        if not os.path.exists(ep):
            errs.append((r["case_id"],"evidence-missing",r["evidence"]))
        else:
            try:
                ec=json.load(open(ep))
                eid=ec.get("case_id") or ec.get("id") or ec.get("name")
                if eid!=r["case_id"]: errs.append((r["case_id"],"evidence-id",str(eid),r["case_id"]))
            except Exception as e: errs.append((r["case_id"],"evidence-unreadable",str(e)[:50]))
        if kind in ("cli_audit","cli_metadata"):
            checks+=[("input_sql",norm(c.get("input_sql")).strip() or "-",unesc(r["sql"]).strip()),
                ("act_findings",findings_of(act),r["act_findings"]),
                ("act_gaps",gapi(act),r["act_gaps"]),
                ("exp_findings",";".join(f"{f.get('rule_id')}@{f.get('level')}" for f in (exp.get("finding_entries") or [])),r["exp_findings"])]
        if kind=="db_ddl":
            checks+=[("input_sql",norm(c.get("input_sql")).strip() or "-",unesc(r["sql"]).strip()),
                     ("db_steps",exp_steps(act),unesc(r["db_steps"])),
                     ("db_verify",exp_verify(act),unesc(r["db_verify"]))]
        if kind=="db_syntax_negative":
            checks+=[("db_neg",exp_neg(act),unesc(r["db_neg"])),
                ("act_findings",f"error_class={act.get('error_class','-')} rc={act.get('rc')} stderr={act.get('stderr','')}",r["act_findings"]),
                ("input_sql",f"argv={' '.join(act.get('argv') or [str(c.get('input_sql',''))])}",r["sql"])]
        for n,e,g in checks:
            if str(e).strip()!=str(g).strip(): errs.append((r["case_id"],n,str(e)[:70],str(g)[:70]))
    ids=[r["case_id"] for r in rows];req=set(required)
    stats=dict(required=len(req),executed=len(set(ids)&req),matrix=len(rows),
        assertions=sum(int(r["assertions"]) for r in rows),duplicate=len(ids)-len(set(ids)),
        missing=len(req-set(ids)),extra=len(set(ids)-req),field_mismatches=len(errs))
    ok=(not errs and stats["executed"]==stats["required"] and stats["missing"]==0
        and stats["extra"]==0 and stats["duplicate"]==0 and stats["assertions"]==1099)
    if verbose:
        print(" ".join(f"{k}={v}" for k,v in stats.items()))
        for e in errs[:15]: print("MISMATCH",e)
        print("FINAL","PASS" if ok else "FAIL")
    return errs,stats,ok
def write_tsv(path,rows,cols):
    with open(path,"w") as fh:
        fh.write("\t".join(cols)+"\n")
        for r in rows: fh.write("\t".join(str(r[k]) for k in cols)+"\n")
if __name__=="__main__":
    a,o,rows=load();required=o.get("required_case_ids") or [c["case_id"] for c in a["cases"]]
    mode=sys.argv[1] if len(sys.argv)>1 else "verify"
    if mode=="verify":
        errs,stats,ok=compare(a,required,rows);sys.exit(0 if ok else 1)
    if mode=="selftest":
        cols=list(rows[0].keys());results=[]
        def run_tamper(name,fn):
            bad=copy.deepcopy(rows);fn(bad)
            errs,st,ok=compare(a,required,bad,verbose=False)
            results.append((name,(not ok) and (len(errs)>0 or st["missing"]>0 or st["executed"]<st["required"])))
        cli_i=next(i for i,r in enumerate(rows) if r["kind"]=="cli_audit")
        meta_i=next(i for i,r in enumerate(rows) if r["kind"]=="cli_metadata")
        db_i=next(i for i,r in enumerate(rows) if r["kind"]=="db_ddl")
        neg_i=next(i for i,r in enumerate(rows) if r["kind"]=="db_syntax_negative")
        run_tamper("cli_audit.findings",lambda b:b.__setitem__(cli_i,{**b[cli_i],"act_findings":"FORGED@blocker"}))
        run_tamper("cli_audit.gaps",lambda b:b.__setitem__(cli_i,{**b[cli_i],"act_gaps":"forged"}))
        run_tamper("cli_audit.exp_gaps",lambda b:b.__setitem__(cli_i,{**b[cli_i],"exp_gaps":"forged"}))
        run_tamper("cli_audit.sql",lambda b:b.__setitem__(cli_i,{**b[cli_i],"sql":"DROP TABLE forged"}))
        run_tamper("cli_metadata.findings",lambda b:b.__setitem__(meta_i,{**b[meta_i],"act_findings":"FORGED@blocker"}))
        run_tamper("db_ddl.sql",lambda b:b.__setitem__(db_i,{**b[db_i],"sql":"FORGED"}))
        run_tamper("db_ddl.steps",lambda b:b.__setitem__(db_i,{**b[db_i],"db_steps":"x|y|rc=99|out=z|err=w"}))
        run_tamper("db_ddl.verify",lambda b:b.__setitem__(db_i,{**b[db_i],"db_verify":"forged"}))
        run_tamper("db_neg.argv",lambda b:b.__setitem__(neg_i,{**b[neg_i],"db_neg":"argv=forged|rc=0|stdout=|stderr=|error_class=-"}))
        run_tamper("db_neg.stderr",lambda b:b.__setitem__(neg_i,{**b[neg_i],"act_findings":"error_class=1064 rc=1 stderr=forged"}))
        run_tamper("evidence-path",lambda b:b.__setitem__(cli_i,{**b[cli_i],"evidence":"golden/artifact/cases/nonexistent.json"}))
        run_tamper("case-removal",lambda b:b.pop(cli_i))
        run_tamper("assertion-count",lambda b:b.__setitem__(cli_i,{**b[cli_i],"assertions":"999"}))
        for n,det in results: print(f"selfcheck:{n} ->","DETECTED" if det else "MISSED")
        tam=os.path.join(ROOT,"matrix/.tampered-check.tsv")
        bad=copy.deepcopy(rows);bad[cli_i]["act_findings"]="FORGED@blocker"
        write_tsv(tam,bad,cols)
        src=open(os.path.abspath(__file__)).read().replace("acceptance-matrix-r7.tsv",".tampered-check.tsv")
        tf=os.path.join(ROOT,"matrix/.tampered-verify.py");open(tf,"w").write(src)
        r=subprocess.run([sys.executable,tf,"verify"],cwd=ROOT,capture_output=True,text=True)
        os.remove(tam);os.remove(tf)
        print("selfcheck:nonzero-exit ->","DETECTED" if r.returncode!=0 else "MISSED (rc=%d)"%r.returncode)
        allok=all(d for _,d in results) and r.returncode!=0
        print("SELFTEST","PASS" if allok else "FAIL");sys.exit(0 if allok else 1)
