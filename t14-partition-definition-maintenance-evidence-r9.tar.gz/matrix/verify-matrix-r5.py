#!/usr/bin/env python3
# T14 matrix validator R5 — archive-relative paths, full field compare, negative self-check.
import json,csv,os,sys,copy
ROOT=os.path.dirname(os.path.abspath(__file__))+"/.."
def norm(x):
    if isinstance(x,list): return " ; ".join(str(i) for i in x)
    return str(x) if x is not None else ""
def gaps_of(act):
    out=[]
    parsed=act.get("parsed") or {}
    for s in parsed.get("statements") or []:
        for g in s.get("evidence_gaps") or []:
            out.append(f"idx{s.get('index')}:{g.get('rule_id','-')}:{g.get('reason_code','-')}:{','.join(g.get('required_facts') or [])}")
    return ";".join(out)
def findings_of(act):
    out=[]
    parsed=act.get("parsed") or {}
    for s in parsed.get("statements") or []:
        for f in s.get("findings") or []:
            out.append(f"{f.get('rule_id')}@{f.get('level')}")
    return out
def load():
    a=json.load(open(os.path.join(ROOT,"golden/artifact/artifact.json")))
    rows=list(csv.DictReader(open(os.path.join(ROOT,"matrix/acceptance-matrix-r4.tsv")),delimiter="\t"))
    return a,rows
def compare(a,rows,verbose=True):
    cases={c["case_id"]:c for c in a["cases"]}
    errs=[]
    for r in rows:
        c=cases.get(r["case_id"])
        if not c: errs.append((r["case_id"],"missing-case"));continue
        act=c.get("actual") or {};exp=c.get("expected") or {};parsed=act.get("parsed") or {}
        checks=[
          ("exp_verdict",norm(exp.get("verdict","N/A")),r["exp_verdict"]),
          ("act_verdict",norm(parsed.get("verdict","N/A")),r["act_verdict"]),
          ("exp_cov",norm(exp.get("coverage","N/A")),r["exp_cov"]),
          ("act_cov",norm((parsed.get("coverage") or {}).get("status","N/A")),r["act_cov"]),
          ("exit",norm(act.get("exit",act.get("rc","-"))),r["exit"]),
          ("assertions",norm(len(c.get("assertions") or [])),r["assertions"]),
          ("unsup",norm(len(parsed.get("unsupported") or [])),r["unsup"]),
          ("kind",norm(c.get("kind","-")),r["kind"]),
          ("dialect",norm(c.get("dialect","-")),r["dialect"]),
          ("anchor",norm(c.get("anchor") or "-"),r["anchor"]),
          ("policy",norm(c.get("policy_profile") or "-"),r["policy"]),
        ]
        if c.get("kind") in ("cli","cli_metadata","cli_offline"):
            sql=norm(c.get("input_sql")).strip() or "-"
            checks.append(("input_sql",sql,r["sql"].replace(" ⏎ ","\n").replace("\\|","|")))
            checks.append(("act_findings",";".join(findings_of(act)),r["act_findings"]))
            checks.append(("act_gaps",gaps_of(act),r["act_gaps"]))
            efn=exp.get("finding_entries") or []
            checks.append(("exp_findings",";".join(f"{f.get('rule_id')}@{f.get('level')}" for f in efn) if efn else "",r["exp_findings"]))
        if c.get("kind")=="db_ddl":
            for s in act.get("steps") or []:
                checks.append((f"dbstep:{s.get('name')}:rc",norm(s.get("rc")),present:=str(s.get("rc"))))
        if c.get("kind")=="db_syntax_negative":
            emb=r.get("act_findings","")
            checks.append(("error_class",norm(act.get("error_class","-")),
                emb.split("error_class=")[1].split(" ")[0] if "error_class=" in emb else "-"))
            checks.append(("rc",norm(act.get("rc","-")),
                emb.split("rc=")[1].split(" ")[0] if "rc=" in emb else "-"))
            checks.append(("stderr-nonempty","yes" if norm(act.get("stderr")) else "no",
                "yes" if "stderr=" in emb and emb.split("stderr=")[1].strip() else "no"))
        for n,e,g in checks:
            if str(e).strip()!=str(g).strip(): errs.append((r["case_id"],n,str(e)[:80],str(g)[:80]))
    ids=[r["case_id"] for r in rows]
    stats=dict(required=69,executed=len(set(ids)),matrix=len(rows),
        assertions=sum(int(r["assertions"]) for r in rows),
        duplicate=len(ids)-len(set(ids)),
        missing=len(set(cases)-set(ids)),extra=len(set(ids)-set(cases)),
        field_mismatches=len(errs))
    if verbose:
        print(" ".join(f"{k}={v}" for k,v in stats.items()))
        for e in errs[:15]: print("MISMATCH",e)
        print("FINAL","PASS" if not errs and stats["executed"]==69 and stats["assertions"]==1099 else "FAIL")
    return errs,stats
if __name__=="__main__":
    a,rows=load()
    mode=sys.argv[1] if len(sys.argv)>1 else "verify"
    if mode=="verify":
        compare(a,rows)
    elif mode=="selftest":
        fails=[]
        cli_i=next(i for i,r in enumerate(rows) if r["kind"] in ("cli","cli_metadata","cli_offline"))
        # tamper 1: corrupt one findings field on a checked row
        bad=copy.deepcopy(rows);bad[cli_i]["act_findings"]="FORGED.rule@blocker"
        e,_=compare(a,bad,verbose=False);fails.append(("findings-tamper",len(e)>0))
        # tamper 2: corrupt one gaps field on a checked row
        bad=copy.deepcopy(rows);bad[cli_i]["act_gaps"]="idx0:forged:forged:forged"
        e,_=compare(a,bad,verbose=False);fails.append(("gaps-tamper",len(e)>0))
        # tamper 3: remove a required case
        bad=[r for r in rows if r["case_id"]!=rows[2]["case_id"]]
        _,st=compare(a,bad,verbose=False);fails.append(("case-removal",st["executed"]<69 or st["missing"]>0))
        # tamper 4: alter an assertion count
        bad=copy.deepcopy(rows);bad[0]["assertions"]="999"
        e,_=compare(a,bad,verbose=False);fails.append(("assertion-tamper",len(e)>0))
        for n,ok in fails: print(f"selfcheck:{n} ->","DETECTED" if ok else "MISSED")
        allok=all(ok for _,ok in fails)
        print("SELFTEST","PASS" if allok else "FAIL")
        sys.exit(0 if allok else 1)
