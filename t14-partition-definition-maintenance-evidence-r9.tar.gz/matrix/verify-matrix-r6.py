#!/usr/bin/env python3
# T14 matrix validator R6 — archive-relative, full-field, dynamic required set, nonzero exit.
import json,csv,os,sys,copy,subprocess
ROOT=os.path.dirname(os.path.abspath(__file__))+"/.."
def unesc(s): return s.replace(" ⏎ ","\n").replace("\\|","|")
def norm(x):
    if isinstance(x,list): return " ; ".join(str(i) for i in x)
    return str(x) if x is not None else ""
def gapi(act):
    return ";".join(f"idx{s.get('index')}:{g.get('rule_id','-')}:{g.get('reason_code','-')}:{','.join(g.get('required_facts') or [])}"
        for s in (act.get('parsed') or {}).get('statements') or [] for g in s.get('evidence_gaps') or [])
def findings_of(act):
    return ";".join(f"{f.get('rule_id')}@{f.get('level')}"
        for s in (act.get('parsed') or {}).get('statements') or [] for f in s.get('findings') or [])
def load():
    a=json.load(open(os.path.join(ROOT,"golden/artifact/artifact.json")))
    o=json.load(open(os.path.join(ROOT,"golden/T14.json")))
    rows=list(csv.DictReader(open(os.path.join(ROOT,"matrix/acceptance-matrix-r6.tsv")),delimiter="\t"))
    return a,o,rows
def exp_steps(act):
    return ";;".join(f"{s.get('name')}|{s.get('sql')}|rc={s.get('rc')}|err={str(s.get('stderr') or '')[:60]}" for s in act.get('steps') or [])
def exp_verify(act):
    return ";;".join(f"{s.get('name')}.{v.get('assert')}|{v.get('sql')}|rc={v.get('rc')}|out={str(v.get('output') or '')[:60]}"
        for s in act.get('steps') or [] for v in s.get('verify') or [])
def compare(a,required,rows,verbose=True):
    cases={c["case_id"]:c for c in a["cases"]}
    errs=[]
    for r in rows:
        c=cases.get(r["case_id"])
        if not c: errs.append((r["case_id"],"missing-case"));continue
        act=c.get("actual") or {};exp=c.get("expected") or {};parsed=act.get("parsed") or {};kind=c["kind"]
        checks=[("kind",norm(kind),r["kind"]),("dialect",norm(c.get("dialect","-")),r["dialect"]),
            ("anchor",norm(c.get("anchor") or "-"),r["anchor"]),("policy",norm(c.get("policy_profile") or "-"),r["policy"]),
            ("exp_verdict",norm(exp.get("verdict","N/A")),r["exp_verdict"]),
            ("act_verdict",norm(parsed.get("verdict","N/A")),r["act_verdict"]),
            ("exp_cov",norm(exp.get("coverage","N/A")),r["exp_cov"]),
            ("act_cov",norm((parsed.get("coverage") or {}).get("status","N/A")),r["act_cov"]),
            ("exit",norm(act.get("exit",act.get("rc","-"))),r["exit"]),
            ("assertions",norm(len(c.get("assertions") or [])),r["assertions"]),
            ("unsup",norm(len(parsed.get("unsupported") or [])),r["unsup"])]
        if kind in ("cli_audit","cli_metadata"):
            sql=norm(c.get("input_sql")).strip() or "-"
            checks+=[("input_sql",sql,unesc(r["sql"]).strip()),
                ("act_findings",findings_of(act),r["act_findings"]),
                ("act_gaps",gapi(act),r["act_gaps"]),
                ("exp_findings",";".join(f"{f.get('rule_id')}@{f.get('level')}" for f in (exp.get("finding_entries") or [])),r["exp_findings"])]
        if kind=="db_ddl":
            checks+=[("input_sql",norm(c.get("input_sql")).strip() or "-",unesc(r["sql"]).strip()),
                     ("db_steps",exp_steps(act),unesc(r["db_steps"])),
                     ("db_verify",exp_verify(act),unesc(r["db_verify"]))]
        if kind=="db_syntax_negative":
            emb=r.get("act_findings","")
            checks+=[("error_class",norm(act.get("error_class","-")),emb.split("error_class=")[1].split(" ")[0] if "error_class=" in emb else "-"),
                ("rc",norm(act.get("rc","-")),emb.split("rc=")[1].split(" ")[0] if "rc=" in emb else "-"),
                ("stderr-nonempty","yes" if norm(act.get("stderr")) else "no","yes" if "stderr=" in emb and emb.split("stderr=")[1].strip() else "no"),
                ("input_sql","argv="+" ".join(act.get("argv") or [str(c.get("input_sql",""))]),r["sql"])]
        for n,e,g in checks:
            if str(e).strip()!=str(g).strip(): errs.append((r["case_id"],n,str(e)[:70],str(g)[:70]))
    ids=[r["case_id"] for r in rows];req=set(required)
    stats=dict(required=len(req),executed=len(set(ids)&req),matrix=len(rows),
        assertions=sum(int(r["assertions"]) for r in rows),duplicate=len(ids)-len(set(ids)),
        missing=len(req-set(ids)),extra=len(set(ids)-req),field_mismatches=len(errs))
    ok=(not errs and stats["executed"]==stats["required"] and stats["missing"]==0
        and stats["extra"]==0 and stats["duplicate"]==0 and stats["assertions"]==1099)
    if verbose:
        print(" ".join(f"{k}={v}" for k,v in stats.items()))
        for e in errs[:15]: print("MISMATCH",e)
        print("FINAL","PASS" if ok else "FAIL")
    return errs,stats,ok
if __name__=="__main__":
    a,o,rows=load();required=o.get("required_case_ids") or [c["case_id"] for c in a["cases"]]
    mode=sys.argv[1] if len(sys.argv)>1 else "verify"
    if mode=="verify":
        errs,stats,ok=compare(a,required,rows);sys.exit(0 if ok else 1)
    if mode=="selftest":
        results=[]
        def run_tamper(name,fn):
            bad=copy.deepcopy(rows);fn(bad)
            errs,st,ok=compare(a,required,bad,verbose=False)
            results.append((name,(not ok) and (len(errs)>0 or st["missing"]>0 or st["executed"]<st["required"])))
        cli_i=next(i for i,r in enumerate(rows) if r["kind"]=="cli_audit")
        meta_i=next(i for i,r in enumerate(rows) if r["kind"]=="cli_metadata")
        db_i=next(i for i,r in enumerate(rows) if r["kind"]=="db_ddl")
        neg_i=next(i for i,r in enumerate(rows) if r["kind"]=="db_syntax_negative")
        run_tamper("cli_audit.findings",lambda b:b.__setitem__(cli_i,{**b[cli_i],"act_findings":"FORGED@blocker"}))
        run_tamper("cli_audit.gaps",lambda b:b.__setitem__(cli_i,{**b[cli_i],"act_gaps":"forged"}))
        run_tamper("cli_audit.sql",lambda b:b.__setitem__(cli_i,{**b[cli_i],"sql":"DROP TABLE forged"}))
        run_tamper("cli_metadata.findings",lambda b:b.__setitem__(meta_i,{**b[meta_i],"act_findings":"FORGED@blocker"}))
        run_tamper("db_ddl.sql",lambda b:b.__setitem__(db_i,{**b[db_i],"sql":"FORGED"}))
        run_tamper("db_ddl.steps",lambda b:b.__setitem__(db_i,{**b[db_i],"db_steps":"x|y|rc=99|err="}))
        run_tamper("db_neg.sql",lambda b:b.__setitem__(neg_i,{**b[neg_i],"sql":"argv=forged"}))
        run_tamper("db_neg.error_class",lambda b:b.__setitem__(neg_i,{**b[neg_i],"act_findings":"error_class=9999 rc=1 stderr=x"}))
        run_tamper("case-removal",lambda b:b.pop(cli_i))
        run_tamper("assertion-count",lambda b:b.__setitem__(cli_i,{**b[cli_i],"assertions":"999"}))
        for n,det in results: print(f"selfcheck:{n} ->","DETECTED" if det else "MISSED")
        # verify nonzero exit on tampered matrix
        tampered=os.path.join(ROOT,"matrix/.tampered-check.tsv")
        bad=copy.deepcopy(rows);bad[cli_i]["act_findings"]="FORGED@blocker"
        cols=list(rows[0].keys())
        with open(tampered,"w") as fh:
            fh.write("\t".join(cols)+"\n")
            for r in bad: fh.write("\t".join(str(r[k]) for k in cols)+"\n")
        src=open(os.path.abspath(__file__)).read().replace("acceptance-matrix-r6.tsv",".tampered-check.tsv")
        tmpf=os.path.join(ROOT,"matrix/.tampered-verify.py");open(tmpf,"w").write(src)
        r=subprocess.run([sys.executable,tmpf,"verify"],cwd=ROOT,capture_output=True,text=True)
        os.remove(tampered);os.remove(tmpf)
        print("selfcheck:nonzero-exit ->","DETECTED" if r.returncode!=0 else "MISSED (rc=%d)"%r.returncode)
        allok=all(d for _,d in results) and r.returncode!=0
        print("SELFTEST","PASS" if allok else "FAIL");sys.exit(0 if allok else 1)
