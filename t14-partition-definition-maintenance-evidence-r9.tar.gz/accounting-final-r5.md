# ER1 — R5 archive accounting (final)

R4 erratum root cause: the R4 receipt was written INTO the archive dir after
the manifest/tar had been computed once, then the archive was repacked to
include it — producing SHA 821be494…/607,631B while the receipt text still
carried the pre-repack SHA 52acae3d…/606,701B and count 367.

R5 convention: the receipt is EXTERNAL ONLY (delivered in message, not in
archive). Ledger order A–F preserved: frozen path set → payload-index (all
paths incl. itself+ledger) → reuse-ledger (REUSED six-tuple) → manifest LAST →
independent re-extract validator. Final SHA/size appear only in the external
receipt.
