# ER1 — Final Archive Accounting (R4)

R3 issue: manifest=359 rows but payload-index.txt and reuse-ledger.tsv each
listed only 357 — the two bookkeeping files counted themselves inconsistently.

R4 convention (per work order A–F):
A. Payload path set frozen BEFORE any bookkeeping write.
B. payload-index.txt lists EVERY payload path — including payload-index.txt
   and reuse-ledger.tsv themselves (self-reference as PATH only, no SHA).
C. reuse-ledger.tsv lists REUSED members only with six-tuple provenance
   (member path, r4 sha/size, source archive name+sha, source member sha/size).
   NEW members need no provenance (classified by manifest).
D. All payload files finalized before manifest.
E. manifest.tsv written LAST: one row per payload file (incl. index+ledger),
   excluding only manifest.tsv itself.
F. Independent re-read validator: manifest paths == payload-index paths ==
   physical payload paths; every SHA/size recomputed; no dupes; no AppleDouble.
