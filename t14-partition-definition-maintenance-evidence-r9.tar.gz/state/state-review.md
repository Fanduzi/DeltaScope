# T14 ER5 — Prospective Schema-State Review @ 9d2c439c

Source: internal/application/audit/partition_transitions.go (blob d56a813d…),
batch_state.go (blob 0c8ae529…), coverage.go (blob b8b64554…).

## Chain
applyAlterTable -> applyPartitionOperation (L80) -> applyPartitionAction (L358)
  drop->transitionDropPartition(L389, T13) reorganize->L491 add->L750/781/884
  coalesce->L929 partition_by->L970 remove_partitioning->L1128
  check/rebuild/repair/optimize/discard/import->transitionPartitionMaintenance(L1160)
Shared outcome fns: partitionMixedOutcome (batch_state L3576), partitionModifierOutcome (L3638),
partitionSchemeOutcome (trans L1041), declaredSchemeOutcome (L1069), partitionBoundUnproven (coverage L849).

## Findings vs work order checks
1. Proven native refusal -> no success post-state: reorganizeRangeOutcome/ListOutcome return
   refused outcomes carrying 1493/1517/1495/1520/1514/1515/1499 classes; refused action keeps
   exact pre-state (TestT14RefusedReorgKeepsPreState, TestT14R1VendorRefusalPreservesPreState).
2. Proven refusal + trusted pre-state -> pre-state preserved verbatim (vendor-refused keeps
   directory+stats, T14R1TiDBMaintenanceVendorUnified / t14r1-tidb85-vendor-check-preserves).
3. Bound-undecidable only -> unvouch member/directory facts via unvouchPartitionMembers(L60),
   not unrelated table facts (t14r1-mysql80-string-domain-unproven).
4. Maintenance preserves member directory, clears data-derived statistics
   (transitionPartitionMaintenance L1160-1221); OPTIMIZE records InnoDB whole-table scope.
5. Unmodelled alter aspects: coverage.go L659 unauditedActionVendor + partition-bound aspects
   (L754/763) — only bounded partition-bound aspects get bounded gaps; others fail closed via
   partitionStateAdmissible/fullyAuditedStatement (batch_state).
6. partitionModifierOutcome gates ALGORITHM/LOCK/modifiers by version — unproven modifier cannot
   substitute a proven one (T13R1 algorithm tests).
7. No "member not found" inference from missing directory: partitionMemberIndexes returns
   undecided -> topologyUnproven (L1222).
8-9. Refused/topology-changed stats: refused keeps stats; accepted topology change unvouches or
   clears only affected stats.
10. Policy blocker does not cancel state transition: state applies per outcome, rule findings
   attach independently (TestT14R1RefusalStateIndependentOfRules).

## Ordered-state cases (Golden metadata_cases, 46)
CREATE->REORG->DROP / ADD->EXCHANGE / COALESCE->TRUNCATE / REORG->DROP old&new members /
REMOVE PARTITIONING->DROP / refused->member refs / unproven pre-state->T13 ops /
maintenance->stats deps — all pass with per-statement assertions (see acceptance-matrix.md).

## Downstream (T15-T26) shared-code impact
ce9a73dc..HEAD touched batch_state.go/coverage.go/partition_transitions.go for later tasks
(see source-audit/t14-downstream-commits.txt, 30 commits listed). T13/T12/T11 golden
regressions re-run green at frozen HEAD: T13 47/47/709, T12 25/25/294, T11 40/40/518 —
no T14 contract weakened. Reachability: T14 admission path still permits only bounded
partition-bound aspects + proven vendor refusals; T13 actions reach shared fns but their
branches unchanged (diff review in downstream-impact.md).
