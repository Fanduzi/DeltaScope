# T14 Spec Review — #93 Acceptance Criteria -> evidence mapping

AC1 (declarations: CREATE PARTITION BY methods/members/bounds/COLUMNS/MAXVALUE/VALUES IN/counts/names/subpartition boundary):
- t14r1-mysql80-create-decreasing-stays-absent
- t14r1-mysql80-pby-expr-bound-incomplete
- t14r2tail-mysql80-pby-single-expr-member

AC2 (topology ADD/REORGANIZE/COALESCE/PARTITION BY/REMOVE; refusals; member identity/order/bounds):
- t14-cli-reorganize-warn
- t14-cli-reorganize-off
- t14-cli-add-warn
- t14-cli-coalesce-warn
- t14-cli-remove-partitioning-warn
- t14-cli-addcol-control
- t14-cli-reorganize-applicability-gap
- t14-mysql80-reorg-missing-source
- t14-mysql80-reorg-collision
- t14-mysql80-reorg-nonconsecutive
- t14-mysql80-reorg-shrink
- t14-tidb85-reorg-hash
- t14-tidb85-reorg-missing-source
- t14-mysql80-reorg-then-truncate-present
- t14-mysql80-reorg-then-truncate-absent
- t14-mysql80-add-then-drop
- t14-mysql80-add-defs
- t14-mysql80-add-collision
- t14-mysql80-add-partitions-n-range
- t14-mysql80-add-hash-defs

AC3 (maintenance CHECK/REBUILD/REPAIR/OPTIMIZE/DISCARD/IMPORT; soft-fail vs hard refusal; TiDB vendor; engine):
- t14-cli-rebuild-warn
- t14-cli-check-notice
- t14-cli-optimize-warn
- t14-cli-repair-warn
- t14-cli-discard-blocker
- t14-cli-import-warn
- t14-cli-tidb-rebuild-vendor
- t14-mysql80-rebuild-missing
- t14-mysql80-rebuild-nonpartitioned
- t14-mysql80-check-missing-softfail
- t14-mysql80-check-nonpartitioned-softfail
- t14-mysql80-optimize-warn
- t14-mysql80-repair-nonpartitioned-softfail
- t14-mysql80-discard-blocker
- t14-mysql80-discard-missing
- t14-mysql80-import-missing
- t14-tidb85-rebuild-vendor
- t14r1-tidb85-vendor-check-preserves
- t14r1-mysql57-myisam-discard-1031

AC4 (prospective ordered state):
Tests: TestT14ReorganizeGoldenSuccessorDirectory, TestT14RemovePartitioningSuccessorReadsPlain,
TestT14RefusedReorgKeepsPreState, TestT14R1VendorRefusalPreservesPreState,
TestT14UnobservedPartitionStateOwesGaps, TestT14R1RefusalStateIndependentOfRules
metadata_cases exercising successor reads: 
- t14-cli-reorganize-applicability-gap
- t14-mysql80-reorg-then-truncate-present
- t14-mysql80-reorg-then-truncate-absent
- t14-mysql80-add-then-drop
- t14r1-mysql80-create-decreasing-stays-absent
- t14r1-tidb85-vendor-check-preserves
- t14r1-mysql80-string-domain-unproven

AC5 (policy semantics: levels, rules-off coverage, vendor boundaries, gaps not silent-pass):
Cases: t14-cli-* policy profiles (warn-only/all-off/applicability-only/target/discard-blocker-only)
Tests: TestT14RulesOffKeepAuditedCoverage, TestT14TiDBMaintenanceVendorBoundary, TestT14R1TiDBMaintenanceVendorUnified


Result: Golden T14 69/69, 1099 assertions, all pass @ 9d2c439c46f6faed434e91c8b54ebc82abbf0787.