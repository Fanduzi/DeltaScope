# ER1 — Archive Accounting R3 (supersedes R2 reuse-ledger)

Independent byte comparison of every R2 payload vs R1 members:

- R2 manifest.tsv truth: 344 payloads → NEW=55 / REUSED=289
  (matches reviewer's recount NEW=55/REUSED=289).
- R2 reuse-ledger.tsv had 339 entries — missing 5 members
  (written before final file additions; same ordering bug class as R1):
  ['payload-index.txt', 'reuse-ledger.tsv', 'r1-preservation.txt', 'archive-integrity-erratum.md', 'receipt/t14-r2-receipt.md']
- Wrong classifications in old ledger: ['README.md']
  (README.md content changed in R2 → must be NEW, ledger said REUSED.)

Root cause: reuse-ledger.tsv was generated BEFORE the README/receipt/erratum/
payload-index were finalized — an ordering bug in archive assembly, identical
class to the R1 manifest bug. No evidence content was altered.

Corrected ledger for R3 is generated LAST (see reuse-ledger.tsv in R3 root);
every REUSED is byte-identical vs the newest available source round.
