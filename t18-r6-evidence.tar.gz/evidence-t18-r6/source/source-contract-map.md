# T18 ER3 — Source / Contract / case_id Mapping (acceptance HEAD 48e6de51; code frozen inside 36e616f8)

Scope: view lifecycle & security attributes for MySQL 5.7.44 / 8.0.46 /
8.4.10 and TiDB v8.5.0 — CREATE/OR REPLACE/ALTER/DROP VIEW, view RENAME,
DEFINER/SQL SECURITY/ALGORITHM/CHECK OPTION, source-reference facts,
prospective batch state, coverage/unsupported/gap contract.
AC1–AC5 refer to issue #97.

T18 implementation provenance: commits `879c49f5` ("complete T18 view
lifecycle and security", 2026-11-01) + `abe88235` ("publish proven T18
view state") landed on the milestone branch BEFORE the T17 freeze; they
are inside frozen parent 36e616f8. Acceptance commit 48e6de51 changed
only `testdata/ddl-golden/T18.json` + `docs/decisions/2026-11-01-ddl-
view-lifecycle.md` — zero product code.

## 1. Pipeline map (SQL → verdict)

| Stage | File (blob @48e6de51) | Key symbols / lines | Fact ownership | T18 case_ids |
|---|---|---|---|---|
| SQL parse / AST | `internal/infrastructure/parser/tidb/extractor.go` (`ceafd4cd`) | `*ast.CreateViewStmt` :174 dispatch; TiDB vendor boundary `:163` — `dialect==TiDB && (AlterView || CheckBare)` → unsupported; `parseViewHeader` :176; `extractCreateView` :676 (operation/target/options/definer/security/algorithm/check-option); `viewOptionNames` :692; `DDLOperationDropView` :764; multi-target drop list preserved | statement shape; vendor-boundary classification; per-target list | all 150 |
| Normalized model | `internal/domain/spec/ddl.go` (`adf99e6b`); `spec/view_query.go` | `DDL.Operation`, `DDL.View` (Definition/Definer/Security/Algorithm/CheckOption/Sources); `assessViewQuery` :37 — bounded column/source analysis; `viewQueryEvaluator` star-expansion :304, first-root :186 | view identity ≠ table identity; bounded query facts | all 150 |
| Metadata provider | `internal/application/audit/metadata.go` (`d0d6978b`) | view metadata read :503-538 — CTE vendor boundary :503-507 (`view_query_cte` unsupported on MySQL); `projectViewMetadata` call :536; `viewStateReadError` propagation | source existence 3-state; view object read | all `t18-meta-*` (114) |
| Policy / rules | `internal/domain/rule/ddl/view_lifecycle_rules.go` (`7651d99c`) | `newViewLifecycleRule`; per-rule gating :43 (target.valid), :76 (source.valid + SourceFailures), :89 (options.ignored.warn); definer/security/algorithm/check-option assessments | findings vs gaps ownership | t18-meta-*-*, t18-cli-* |
| Register | `internal/domain/rule/ddl/register.go` (`ed8f3aed`) | :567-584 — 8 view rules: target.valid(B), source.valid(B), security.definer.warn(W), algorithm.warn(W), check_option.valid(B), options.ignored.warn(W), create.forbid, drop.forbid (`common.go` `3e298012` :251-252) | rule surface | t18-cli-*-disabled, all-off cases |
| Prospective batch state | `internal/application/audit/batch_state_view.go` (`9e9faf87`) | `applyDropView` :15 (per-target drop + namespace invalidate); `projectViewMetadata` :31; `applyView` :136 (recreate/replace/alter publish proven state; refused/withheld never mutate) | ordered multi-statement semantics | t18-meta-*-source-drop*, *-recreate*, *-review-* |
| Coverage / gaps | `internal/application/audit/coverage.go` (`dee2cd26`) | :429 `view.dependencies.limit` aspectGap (dependency_limit aspect) — zero-source CTE DAG budget; unsupported shapes classified unaudited not gap | incomplete-coverage contract (T03) | t18-cli-review-*-boundary, *-cte-dag-budget |
| Verdict / report | `internal/application/audit/service.go` (`7c47a9a8`) | `AuditSQL` → `Service.Audit`; aggregate precedence incomplete>unverified>complete; reject never hidden | public tuple (kind/index/findings/gaps/unsupported/verdict/coverage) | all 150 |
| SDK | `pkg/deltascope/audit.go` (`4cfb78d6`) | `Audit(ctx, Request)` → same engine | SDK parity | parity 5 cases |
| CLI | `internal/interfaces/cli/audit.go` (`b613e964`) | `audit --file --dialect --config --fail-on --target-version --format json` → exit code | CLI parity + exit mapping | 28 cli_audit + 114 cli_metadata |
| HTTP | `internal/interfaces/http/handler.go` (`1e6e581c`) | `POST /v1/audit` | HTTP parity | parity |
| MCP | `internal/interfaces/mcp/audit_tool.go` (`e0cb1fba`) | `audit_sql` tool, `config_path`, structuredContent | MCP parity | parity |
| Oracle | `testdata/ddl-golden/T18.json` (`526f36c7` @48e6de51) | 150 required==executed; per-case expect incl. statement_indices/statement_sql/finding_locations/finding_metadata/fail_on_triggered/serialized_not_contains | independent expectations | — |
| ADR | `docs/decisions/2026-11-01-ddl-view-lifecycle.md` (`16122a5a`) | view lifecycle decisions + R1 errata (oracle credential wiring, assertion tightening) | contract rationale | — |

## 2. AC → source → case_id

- **AC1 legal forms & parse boundary**: extractor ops + `parseViewHeader` + TiDB alter vendor boundary (:163). Cases: `t18-meta-*-alter-*`, `t18-cli-tidb-alter-vendor`, `t18-cli-review-*-boundary` (LIMIT/window/positional/named-set → unsupported), `t18-cli-*-cte-dag-budget` (dependency_limit).
- **AC2 security & multi-target**: definer/security/algorithm/check-option assessments in view_lifecycle_rules + per-target drop adjudication in `applyDropView`. Cases: `t18-*-definer*`, `t18-*-security*`, `t18-*-algorithm*`, `t18-*-check*`, `t18-meta-*-multi-drop*`, `t18-*-missing-target`, `t18-*-type-conflict`.
- **AC3 references & batch state**: `spec/view_query.go` bounded analysis + `projectViewMetadata`/`applyView` proven-state publication (abe88235); frozen `*` projection; invisible-column interaction; CTE dependency shape. Cases: `t18-*-source-drop-*`, `t18-*-recreate`, `t18-*-frozen-*`, `t18-*-invisible*`, `t18-*-cte*`.
- **AC4 TiDB boundaries**: ALTER VIEW vendor boundary (:163 + native ERROR 1064); CHECK OPTION four-form native verdict at 8.5.0 (R3): bare `WITH CHECK OPTION` ERROR 1064 (matches CheckBare vendor boundary), `WITH LOCAL|CASCADED CHECK OPTION` rc=0, `ALGORITHM=MERGE + CASCADED` rc=0 — all declared-compatible non-enforced (views non-updatable, insert ERROR 1105); ALGORITHM accepted-ignored; DEFINER silently accepted. Cases: `t18-cli-tidb-alter-vendor`, `t18-meta-tidb85-*`, `t18-*-ignored*`.
- **AC5 public contract**: same tuple across 4 surfaces; parity 5 cases IDENTICAL.

## 3. Boundary explanations (contract-owned)

1. **Multi-target DROP version split (native-verified R2)**: 5.7.44 + TiDB 8.5 = partial commit (existing view dropped despite ERROR 1051/1347); 8.0.46 + 8.4.10 = atomic refuse. Doc conflict adjudicated by real probes — rules emit per-target findings, never blanket atomicity.
2. **TiDB ALTER VIEW**: engine syntax-rejects (ERROR 1064) — expressed as vendor boundary unsupported, not parser_error (form recognized, not applicable).
3. **TiDB CHECK OPTION**: per-form native verdict at 8.5.0 — bare reject 1064 (CheckBare boundary correct); LOCAL/CASCADED/ALGORITHM+CASCADED accepted rc=0, declared-compatible non-enforced. Never one verdict across forms.
4. **TiDB ALGORITHM/DEFINER**: accepted-silently — `ddl.view.options.ignored.warn` / definer warn; enforcement NOT claimed.
5. **DEFINER prerequisite version split (native)**: 5.7 SUPER / 8.0 +SET_USER_ID / 8.4 +SET_ANY_DEFINER (ERROR 1227); nonexistent definer = Note 1449 warning, view still created.
6. **Declaration ≠ runtime proof**: definer identity, security mode, algorithm, check-option are recorded as declared facts; invocation-time privilege/updatability remain evidence gaps or unproven, never asserted.

## 4. Cross-task dependencies

- T05 (#84): ordered prospective state infra.
- T16 (#95): table lifecycle — `applyDropSchema`-style invalidation composes with view source facts.
- T17 (#96): schema state; TiDB schema placement stays at T17/T20 boundary.
- T20 (#99): UNACCEPTED — no placement claims for views.
- T03 (#82): incomplete-coverage contract (unaudited ≠ pass).
- Consumers checked: batch_state_t18* tests green; no shared-type bypass to T16/T17/Query Access/PostgreSQL-tag paths (make test + corpus gates at 48e6de51).
