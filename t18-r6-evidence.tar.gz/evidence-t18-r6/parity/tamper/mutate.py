import json,sys,copy,random,os
op,base=sys.argv[1],sys.argv[2]
def load(p): return json.load(open(p))
def dump(p,d):
    with open(p,'w') as f: json.dump(d,f)
if op=='pos-key-order':
    # real byte-level key permutation on CLI output: parse+redump reversed order
    p=f'{base}/cli/out-dual.json';d=load(p)
    def rev(o):
        if isinstance(o,dict): return {k:rev(o[k]) for k in reversed(list(o))}
        if isinstance(o,list): return [rev(x) for x in o]
        return o
    dump(p,rev(d))
elif op=='pos-findings-order':
    p=f'{base}/cli/out-dual2.json';d=load(p)
    d['statements'][0]['findings']=list(reversed(d['statements'][0]['findings']))
    dump(p,d)
elif op=='neg-owner-move':
    p=f'{base}/sdk/out-dual2.json';d=load(p)
    sts=d['result']['statements']
    f=sts[0]['findings'].pop()          # move last stmt0 finding
    sts[1]['findings'].append(f)        # into stmt1 — internal fields unchanged
    dump(p,d)
elif op=='neg-rule':
    p=f'{base}/cli/out-dual.json';d=load(p)
    d['statements'][0]['findings'][0]['rule_id']='ddl.view.drop.forbid'
    dump(p,d)
elif op=='neg-level':
    p=f'{base}/cli/out-dual.json';d=load(p)
    d['statements'][0]['findings'][0]['level']='notice'
    dump(p,d)
elif op=='neg-location':
    p=f'{base}/mcp/dual/structured.json';d=load(p)
    d['statements'][0]['findings'][0]['location']['line']=99
    dump(p,d)
elif op=='neg-verdict':
    p=f'{base}/http/response-dual.json';d=load(p)
    t=d.get('result') or d; t['verdict']='pass'
    dump(p,d)
elif op=='neg-unsup-metadata':
    p=f'{base}/sdk/out-unsup.json';d=load(p)
    d['result']['unsupported'][0]['metadata']['aspect']='dependency_limit'
    dump(p,d)
elif op=='neg-diag':
    p=f'{base}/cli/out-parseerr.json';d=load(p)
    d['diagnostics'][0]['classification']='unsupported_statement'
    dump(p,d)
elif op=='neg-stmt-index':
    p=f'{base}/sdk/out-dual2.json';d=load(p)
    sts=d['result']['statements']
    sts[0]['findings'][0]['statement_index']=1   # smuggle stmt0 finding as stmt1-owned
    dump(p,d)
else:
    sys.exit(f'unknown op {op}')
