#!/bin/bash
# T18 parity control replay — deterministic mutations + comparator verdicts.
# Each control copies the authoritative tree, mutates ONE surface artifact,
# runs compare.py, records rc/stdout/stderr. Expectation: pos→rc0 PASS, neg→rc1 DIFF.
set -u
ROOT=/tmp/t18-parity
SRC=/tmp/t18-parity
mkdir -p /tmp/t18-parity/tamper
declare -A OPS=(
 [pos-key-order]='dual,unsup,parseerr,disabled:0'
 [pos-findings-order]='dual2:0'
 [neg-owner-move]='dual2:1'
 [neg-rule]='dual,unsup,parseerr,disabled:1'
 [neg-level]='dual,unsup,parseerr,disabled:1'
 [neg-location]='dual,unsup,parseerr,disabled:1'
 [neg-verdict]='dual,unsup,parseerr,disabled:1'
 [neg-unsup-metadata]='unsup:1'
 [neg-diag]='parseerr:1'
 [neg-stmt-index]='dual2:1'
)
: > /tmp/t18-parity/tamper/gate.txt
fails=0
for name in pos-key-order pos-findings-order neg-owner-move neg-rule neg-level neg-location neg-verdict neg-unsup-metadata neg-diag neg-stmt-index; do
  spec="${OPS[$name]}"; cases="${spec%%:*}"; want="${spec##*:}"
  dir="/tmp/t18-parity/tamper/$name"
  rm -rf "$dir"; mkdir -p "$dir"
  cp -R "$SRC/cli" "$SRC/sdk" "$SRC/http" "$SRC/mcp" "$dir/"
  rm -f "$dir/sdk/sdkprobe-t18"   # comparator reads JSON only; probe binary excluded
  python3 "$SRC/tamper/mutate.py" "$name" "$dir" > "$dir/mutate-stdout.txt" 2> "$dir/mutate-stderr.txt"
  mrc=$?
  python3 "$SRC/compare.py" "$dir" "$cases" > "$dir/compare-stdout.txt" 2> "$dir/compare-stderr.txt"
  crc=$?
  verdict="?"; grep -q 'PARITY: PASS' "$dir/compare-stdout.txt" && verdict=PASS
  grep -q 'PARITY: FAIL' "$dir/compare-stdout.txt" && verdict=FAIL
  tb=$(grep -c 'Traceback' "$dir/compare-stderr.txt" 2>/dev/null || true)
  status=OK; { [ "$mrc" -ne 0 ] || [ "$crc" -ne "$want" ]; } && status=BAD
  echo "$name cases=$cases mutate_rc=$mrc compare_rc=$crc verdict=$verdict want_rc=$want traceback=$tb -> $status" | tee -a /tmp/t18-parity/tamper/gate.txt
  [ "$status" = BAD ] && fails=$((fails+1))
done
# authoritative baseline must stay pristine
python3 "$SRC/compare.py" "$SRC" 'dual,unsup,parseerr,disabled,dual2' > /tmp/t18-parity/tamper/baseline-compare-stdout.txt 2> /tmp/t18-parity/tamper/baseline-compare-stderr.txt
brc=$?
echo "baseline cases=dual,unsup,parseerr,disabled,dual2 compare_rc=$brc -> $([ $brc -eq 0 ] && echo OK || echo BAD)" | tee -a /tmp/t18-parity/tamper/gate.txt
[ $brc -ne 0 ] && fails=$((fails+1))
echo "controls fails=$fails" | tee -a /tmp/t18-parity/tamper/gate.txt
[ "$fails" -eq 0 ] && echo ALL-CONTROLS-PASS | tee -a /tmp/t18-parity/tamper/gate.txt
exit $fails
