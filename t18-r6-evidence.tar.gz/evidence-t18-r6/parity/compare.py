#!/usr/bin/env python3
"""T17 four-surface semantic parity comparator (R3 formal entry).

Usage: compare.py <base-dir>
  base-dir must contain cli/out-<case>.json, sdk/out-<case>.json,
  http/response-<case>.json, mcp/<case>/structured.json
  for cases: disabled reject gap placement

Compares the COMPLETE semantic tuple per case across surfaces:
  verdict, top-level coverage, per-statement coverage (per index),
  findings as (enclosing index, finding.statement_index, rule_id,
  level, line, column) multisets with statement_index==index binding,
  evidence gaps as (enclosing index, rule_id, reason_code,
  sorted required_facts) multisets,
  unsupported as (feature, reason, sorted metadata, sql) multisets,
  diagnostics as (classification, reason, action_hint, audited, dialect)
  multisets.
Exit 0 when all cases identical across all surfaces, 1 otherwise.
"""
import json, sys, os

CASES = ["disabled", "reject", "gap", "placement"]


def _n(v):
    """Sort-stable normaliser: None -> ('', ) sentinel tuple so mixed
    None/int/str fields never crash tuple comparison. Booleans and
    numbers become tagged strings to keep ordering total."""
    if v is None:
        return ("\x00null",)
    if isinstance(v, bool):
        return ("\x01bool", v)
    if isinstance(v, (int, float)):
        return ("\x02num", v)
    return ("\x03str", str(v))


def tup(r):
    sts = r.get("statements", [])
    fs = []
    for s in sts:
        idx = s.get("index")
        for f in s.get("findings", []):
            si = f.get("statement_index")
            loc = f.get("location") or {}
            fs.append((_n(idx), _n(si), _n(f.get("rule_id")),
                       _n(f.get("level")), _n(loc.get("line")),
                       _n(loc.get("column")),
                       "owner-mismatch" if si is not None and si != idx else "ok"))
    gs = sorted((_n(s.get("index")), _n(g.get("rule_id")),
                 _n(g.get("reason_code")),
                 tuple(sorted(str(x) for x in (g.get("required_facts") or []))))
                for s in sts for g in s.get("evidence_gaps", []))
    uns = sorted((_n(u.get("feature")), _n(u.get("reason")),
                  tuple(sorted((str(k), str(v))
                               for k, v in (u.get("metadata") or {}).items())),
                  _n(u.get("sql")))
                 for u in r.get("unsupported", []))
    diag = sorted((_n(d.get("classification")), _n(d.get("reason")),
                   _n(d.get("action_hint")), _n(d.get("audited")),
                   _n(d.get("dialect")))
                  for d in r.get("diagnostics", []))
    stmt_cov = sorted((_n(s.get("index")),
                       _n((s.get("coverage") or {}).get("status")))
                      for s in sts)
    return {"verdict": r.get("verdict"),
            "coverage": (r.get("coverage") or {}).get("status"),
            "stmt_coverage": stmt_cov,
            "findings": sorted(fs), "gaps": gs,
            "unsupported": uns, "diagnostics": diag}


def load(base, surf, case, suffix=None):
    fn = suffix or case
    if surf == "cli":
        return json.load(open(f"{base}/cli/out-{fn}.json"))
    if surf == "sdk":
        return json.load(open(f"{base}/sdk/out-{fn}.json"))["result"]
    if surf == "http":
        d = json.load(open(f"{base}/http/response-{fn}.json"))
        return d.get("result") or d
    if surf == "mcp":
        p = f"{base}/mcp/{fn}/structured.json"
        if not os.path.exists(p):
            p = f"{base}/mcp/structured-{fn}.json"
        return json.load(open(p))


def main():
    base = sys.argv[1] if len(sys.argv) > 1 else "."
    cases = sys.argv[2].split(",") if len(sys.argv) > 2 else CASES
    suffix = sys.argv[3] if len(sys.argv) > 3 else None
    ok = True
    for case in cases:
        rows = {s: tup(load(base, s, case, suffix)) for s in ("cli", "sdk", "http", "mcp")}
        ref = rows["cli"]
        same = all(v == ref for v in rows.values())
        ok &= same
        print(f"== {case}: {'IDENTICAL' if same else 'DIFF'}")
        if not same:
            for k, v in rows.items():
                if v != ref:
                    print(f"  {k}: {json.dumps(v, sort_keys=True)[:400]}")
        else:
            print("   tuple:", json.dumps(ref, sort_keys=True)[:400])
    print("PARITY:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
