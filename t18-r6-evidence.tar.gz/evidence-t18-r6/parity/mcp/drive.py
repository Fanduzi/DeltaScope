import json,subprocess,os,threading,time
BIN='/tmp/t18-parity/bin/deltascope-mcp'
def run(case,sqlfile,policy):
    d=f'/tmp/t18-parity/mcp/{case}';os.makedirs(d,exist_ok=True)
    init={"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"t18parity","version":"0"}}}
    inited={"jsonrpc":"2.0","method":"notifications/initialized","params":{}}
    sql=open(f'/tmp/t18-parity/{sqlfile}').read()
    call={"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"audit_sql","arguments":{"sql":sql,"dialect":"mysql","config_path":f"/tmp/t18-parity/{policy}"}}}
    for n,f in [('sent-init.json',init),('sent-initialized.json',inited),('sent-call.json',call)]:
        open(f'{d}/{n}','w').write(json.dumps(f))
    p=subprocess.Popen([BIN],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    got=[];done=[False]
    def reader():
        for line in p.stdout:
            got.append(line)
            try:
                if json.loads(line).get('id')==2: done[0]=True;break
            except: pass
    t=threading.Thread(target=reader,daemon=True);t.start()
    for f in (init,inited,call):
        p.stdin.write(json.dumps(f)+'\n');p.stdin.flush()
    t.join(timeout=20)
    try:p.stdin.close()
    except:pass
    try:p.wait(timeout=10)
    except:p.kill();p.wait()
    open(f'{d}/recv-frames.jsonl','w').write(''.join(got))
    open(f'{d}/stderr.log','w').write(p.stderr.read())
    open(f'{d}/exit.txt','w').write(str(p.returncode))
    for l in got:
        try:
            f=json.loads(l)
            if f.get('id')==1:open(f'{d}/recv-init.json','w').write(l)
            if f.get('id')==2:
                open(f'{d}/recv-call.json','w').write(l)
                sc=(f.get('result') or {}).get('structuredContent')
                if sc is not None:open(f'{d}/structured.json','w').write(json.dumps(sc))
        except:pass
    print(case,'rc=',p.returncode,'frames=',len(got))
for c,pol in [('dual','policy-t18.yaml'),('unsup','policy-t18.yaml'),('parseerr','policy-t18.yaml'),('disabled','policy-t18-disabled.yaml')]:
    run(c,'case-dual.sql' if c=='disabled' else f'case-{c}.sql',pol)
