package main

import (
	"context"
	"encoding/json"
	"fmt"
	"os"

	"github.com/Fanduzi/DeltaScope/pkg/deltascope"
)

func main() {
	name, sqlFile, dialect, config := os.Args[1], os.Args[2], os.Args[3], os.Args[4]
	sql, err := os.ReadFile(sqlFile)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	d := deltascope.DialectMySQL
	if dialect == "tidb" {
		d = deltascope.DialectTiDB
	}
	res, err := deltascope.Audit(context.Background(), deltascope.Request{
		SQL:        string(sql),
		Dialect:    d,
		ConfigPath: config,
	})
	out := map[string]any{"case": name, "sdk_error": nil, "result": res}
	if err != nil {
		out["sdk_error"] = err.Error()
	}
	b, _ := json.Marshal(out)
	fmt.Println(string(b))
}
