required: 187 present; members: 1354; failures: 3
FAIL missing required: ['README.md']
FAIL index drift missing=[] extra=['README.md'] bad=[] req_not_in_idx=[]
FAIL manifest drift missing=[] extra=['README.md'] bad=[] req_not_in_man=[]
