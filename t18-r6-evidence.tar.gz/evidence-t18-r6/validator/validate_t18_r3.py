#!/usr/bin/env python3
"""T18-R3 independent oracle validator — fail-closed.

Inputs (all three REQUIRED, missing/empty/unreadable => rc=1):
  --artifact   golden run artifact.json (actual + runner-transcribed expected)
  --matrix     ORACLE-DERIVED expected matrix (gen_oracle_matrix.py from T18.json;
               never derived from artifact.actual)
  --oracle     T18.json (human-authored expectation declarations)

Bindings:
  A. oracle -> artifact.expected      runner transcription fidelity
  B. matrix(oracle) -> artifact.actual DIRECT independent binding:
     verdict/coverage/stmt_coverage/exit/fail_on/stmt indices+SQL/
     finding entries (rule_id,level,index multiset)/finding locations
     (exact set equality - extra locations rejected)/finding metadata/
     evidence_gaps reason codes+required facts/unsupported+metadata/
     serialized_not_contains/version
  C. db_* step identity: name/order/expect_rc/verify.expect -> actual
     name/order/rc/verify.output; metadata setup+execute+post phases
  D. fail-closed invariants: required_case_ids non-empty & == executed;
     executed_count == len(cases); every case status==pass; assertions>0
  E. diagnostics: count == oracle; each entry non-empty
     classification/reason/remediation; parsed blob == stdout JSON
  F. actual-derived projection check kept only as consistency layer
"""
import json, sys, os, argparse, collections

def load(p):
    try:
        return json.load(open(p))
    except Exception as e:
        print(f"required input unreadable/malformed: {p} :: {e}")
        sys.exit(1)

def must(cond, msg, errs):
    if not cond:
        errs.append(msg)

def norm_sql(s):
    return ' '.join((s or '').split()).rstrip(';').lower()

def steps_of(blk):
    if isinstance(blk, list):
        return blk
    return (blk or {}).get('steps') or []

def stmt_index(st, pos):
    v = st.get('index')
    return v if isinstance(v, int) else pos

# ---------- oracle structures ----------

def oracle_case_map(oracle):
    m = {}
    for c in oracle.get('cli_cases') or []:
        m['T18.cli.' + c['id']] = ('cli_audit', c)
    for c in oracle.get('metadata_cases') or []:
        m['T18.meta.' + c['id']] = ('cli_metadata', c)
    for anchor in (oracle.get('anchors') or {}):
        m[f'T18.db.{anchor}.ddl'] = ('db_ddl',
            {'steps': oracle.get('ddl_steps') or [], 'anchor': anchor})
        m[f'T18.db.{anchor}.syntax_negative'] = ('db_syntax_negative',
            dict(oracle.get('syntax_negative') or {}, anchor=anchor))
    return m

def matrix_map(matrix):
    return {r['case_id']: r for r in matrix or []}

# ---------- A: oracle -> artifact.expected ----------

def bind_oracle(oracle, artifact, errs):
    omap = oracle_case_map(oracle)
    req = set(oracle.get('required_case_ids') or [])
    ids = [c['case_id'] for c in artifact.get('cases') or []]
    if req and req != set(ids):
        errs.append(f"oracle.required!=artifact diff={set(req) ^ set(ids)}")
    for c in artifact.get('cases') or []:
        cid = c['case_id']
        if cid not in omap:
            errs.append(f"{cid}: no oracle case")
            continue
        kind, oc = omap[cid]
        if c.get('kind') != kind:
            errs.append(f"{cid}.kind oracle={kind} artifact={c['kind']}")
        oc_sql = oc.get('sql')
        if oc_sql and norm_sql(oc_sql) != norm_sql(c.get('input_sql') or (c.get('input') or {}).get('sql')):
            errs.append(f"{cid}.input_sql differs from oracle")
        e = c.get('expected') or {}
        oe = oc.get('expect') or {}
        if kind == 'db_ddl':
            onames = [s.get('name') for s in oc.get('steps') or []]
            enames = [s.get('name') for s in steps_of(e.get('steps'))]
            if onames != enames:
                errs.append(f"{cid}.expected.steps.names")
        for f in oe:
            if f not in e:
                errs.append(f"{cid}.expected.{f} missing")
            elif e[f] != oe[f]:
                errs.append(f"{cid}.expected.{f} oracle!=artifact")

# ---------- B: matrix(oracle-derived) -> artifact.actual ----------

def grouped_findings_actual(sts):
    g = collections.defaultdict(collections.Counter)
    locs = collections.defaultdict(list)
    metas = collections.defaultdict(list)
    for pos, st in enumerate(sts or []):
        si = stmt_index(st, pos)
        for f in st.get('findings') or []:
            g[si][(f.get('rule_id'), f.get('level'))] += 1
            locs[si].append(f.get('location'))
            metas[si].append(f.get('metadata'))
    return g, locs, metas

def grouped_entries_expected(entries):
    g = collections.defaultdict(collections.Counter)
    for x in entries or []:
        g[x.get('index')][(x.get('rule_id'), x.get('level'))] += 1
    return g

def bind_matrix_to_actual(mrow, c, errs):
    cid = c['case_id']
    kind = mrow.get('kind')
    a = c.get('actual') or {}
    e = mrow.get('expected') or {}
    if kind not in ('cli_audit', 'cli_metadata'):
        return
    p = a.get('parsed') or {}
    # scalar bindings
    if 'exit' in e and e['exit'] != a.get('exit'):
        errs.append(f"{cid}.matrix.exit expected={e['exit']} actual={a.get('exit')}")
    if 'verdict' in e and e['verdict'] != p.get('verdict'):
        errs.append(f"{cid}.matrix.verdict")
    cov = p.get('coverage')
    cov = cov.get('status') if isinstance(cov, dict) else cov
    if 'coverage' in e and e['coverage'] != cov:
        errs.append(f"{cid}.matrix.coverage expected={e['coverage']} actual={cov}")
    sc = [(s.get('coverage') or {}).get('status') for s in p.get('statements', [])]
    if 'statement_coverage' in e and e['statement_coverage'] != sc:
        errs.append(f"{cid}.matrix.stmt_coverage")
    if 'statement_indices' in e:
        ai = [s.get('index') for s in p.get('statements', [])]
        if e['statement_indices'] != ai:
            errs.append(f"{cid}.matrix.stmt_indices")
    if 'statement_sql' in e:
        asql = [s.get('raw_sql') for s in p.get('statements', [])]
        if [norm_sql(x) for x in e['statement_sql']] != [norm_sql(x) for x in asql]:
            errs.append(f"{cid}.matrix.stmt_sql")
    # fail_on derived from matrix args + actual levels (evidence_gap=warning)
    if 'fail_on_triggered' in e:
        thr = 'blocker'
        args = mrow.get('args') or []
        if '--fail-on' in args:
            thr = args[args.index('--fail-on') + 1]
        sev = {'blocker': 3, 'warning': 2, 'notice': 1}.get(thr, 3)
        levels = []
        for st in p.get('statements', []):
            for f in st.get('findings') or []:
                levels.append(f.get('level'))
            for g in st.get('evidence_gaps') or []:
                levels.append('warning')
        triggered = any({'blocker': 3, 'warning': 2, 'notice': 1}.get(l, 0) >= sev for l in levels)
        if bool(e['fail_on_triggered']) != triggered:
            errs.append(f"{cid}.matrix.fail_on expected={e['fail_on_triggered']} derived={triggered}")
    # findings multiset (rule_id,level) per index — independent of order
    if 'finding_entries' in e:
        ga, _, _ = grouped_findings_actual(p.get('statements'))
        ge = grouped_entries_expected(e['finding_entries'])
        if ga != ge:
            errs.append(f"{cid}.matrix.finding_entries expected={dict(ge)} actual={dict(ga)}")
    # locations EXACT set equality per index — extra/missing locations rejected
    if 'finding_locations' in e:
        # oracle pins a SUBSET of findings' locations: every declared
        # (index,line,column) must appear among actual findings at that index.
        _, locs_a, _ = grouped_findings_actual(p.get('statements'))
        for x in e['finding_locations']:
            idx = x.get('index')
            want = {'line': x.get('line'), 'column': x.get('column')}
            if want not in (locs_a.get(idx) or []):
                errs.append(f"{cid}.matrix.finding_location idx={idx} want={want} actual={locs_a.get(idx)}")
    # finding metadata exact match per (index, rule_id) pairing
    if 'finding_metadata' in e:
        # declared entries pair (index, rule_id, metadata): the actual finding
        # carrying that rule_id at that index must carry exactly that metadata.
        flat_a = []
        for pos, st in enumerate(p.get('statements', [])):
            si = stmt_index(st, pos)
            for f in st.get('findings') or []:
                flat_a.append((si, f.get('rule_id'), f.get('metadata')))
        for x in e['finding_metadata']:
            idx, rid, want = x.get('index'), x.get('rule_id'), x.get('metadata')
            cand = [m for (i, r, m) in flat_a if i == idx and r == rid]
            if not cand:
                errs.append(f"{cid}.matrix.finding_metadata no actual finding idx={idx} rule={rid}")
            elif not any(m == want for m in cand):
                errs.append(f"{cid}.matrix.finding_metadata idx={idx} rule={rid} want={want} got={cand}")
    # evidence gaps reason codes + required facts
    if 'evidence_gaps' in e:
        gaps_a = []
        for pos, st in enumerate(p.get('statements', [])):
            for g in st.get('evidence_gaps') or []:
                gaps_a.append({'index': stmt_index(st, pos),
                               'reason_code': g.get('reason_code'),
                               'required_facts': g.get('required_facts')})
        expg = e['evidence_gaps']
        if isinstance(expg, list) and expg and isinstance(expg[0], dict):
            en = sorted(map(lambda d: json.dumps(d, sort_keys=True), expg))
            an = sorted(map(lambda d: json.dumps(d, sort_keys=True), gaps_a))
            if en != an:
                errs.append(f"{cid}.matrix.evidence_gaps")
        elif isinstance(expg, int):
            if len(gaps_a) != expg:
                errs.append(f"{cid}.matrix.evidence_gaps count expected={expg} actual={len(gaps_a)}")
    # unsupported + metadata
    if 'unsupported' in e:
        uns_a = list(p.get('unsupported') or []) + [u for st in p.get('statements', []) for u in st.get('unsupported') or []]
        if isinstance(e['unsupported'], int):
            if len(uns_a) != e['unsupported']:
                errs.append(f"{cid}.matrix.unsupported count")
        else:
            en = sorted(map(lambda d: json.dumps(d, sort_keys=True), e['unsupported']))
            an = sorted(map(lambda d: json.dumps(d, sort_keys=True), uns_a))
            if en != an:
                errs.append(f"{cid}.matrix.unsupported")
    # declared evidence_gap_entries: field-level binding
    #   oracle entry {index, rule_id, reason_code, required_facts} must equal the
    #   actual gap entry carried by statements[index]; declared set == actual set
    if 'evidence_gap_entries' in e:
        actual_gaps = []
        for pos, st in enumerate(p.get('statements', [])):
            si = stmt_index(st, pos)
            for g in st.get('evidence_gaps') or []:
                actual_gaps.append({'index': si, 'rule_id': g.get('rule_id'),
                                    'reason_code': g.get('reason_code'),
                                    'required_facts': sorted(g.get('required_facts') or [])})
        declared = [{'index': x.get('index'), 'rule_id': x.get('rule_id'),
                     'reason_code': x.get('reason_code'),
                     'required_facts': sorted(x.get('required_facts') or [])}
                    for x in e['evidence_gap_entries']]
        dn = sorted(map(lambda d: json.dumps(d, sort_keys=True), declared))
        an = sorted(map(lambda d: json.dumps(d, sort_keys=True), actual_gaps))
        if dn != an:
            errs.append(f"{cid}.matrix.gap_entries expected={dn} actual={an}")
    # declared unsupported_entries: field-level binding incl. index<->sql
    #   oracle entry {index, feature, reason, metadata?}; the actual unsupported
    #   entry's sql must be statements[index].raw_sql and fields must match
    if 'unsupported_entries' in e:
        uns_a = list(p.get('unsupported') or [])
        declared = e['unsupported_entries'] or []
        used = set()
        for i, x in enumerate(declared):
            idx = x.get('index')
            want_sql = None
            sts = p.get('statements') or []
            for pos, st in enumerate(sts):
                if stmt_index(st, pos) == idx:
                    want_sql = st.get('raw_sql')
                    break
            cands = [(j, u) for j, u in enumerate(uns_a)
                     if j not in used and u.get('feature') == x.get('feature')]
            hit = None
            for j, u in cands:
                if u.get('reason') != x.get('reason'):
                    continue
                if 'metadata' in x and u.get('metadata') != x.get('metadata'):
                    continue
                if want_sql is not None and norm_sql(u.get('sql')) != norm_sql(want_sql):
                    continue
                hit = j
                break
            if hit is None:
                errs.append(f"{cid}.matrix.unsup_entry[{i}] idx={idx} feature={x.get('feature')!r} no matching actual")
            else:
                used.add(hit)
        if len(declared) != len(uns_a):
            errs.append(f"{cid}.matrix.unsup_entries count declared={len(declared)} actual={len(uns_a)}")
    # diagnostics count + real-field schema contract + dual serialization
    if 'diagnostics' in e:
        diags = list(p.get('diagnostics') or []) + [d for st in p.get('statements', []) for d in st.get('diagnostics') or []]
        if isinstance(e['diagnostics'], int) and len(diags) != e['diagnostics']:
            errs.append(f"{cid}.matrix.diagnostics count expected={e['diagnostics']} actual={len(diags)}")
    # declared statements/findings counts + version fields
    if 'statements' in e and isinstance(e['statements'], int):
        ns = len(p.get('statements') or [])
        if e['statements'] != ns:
            errs.append(f"{cid}.matrix.statements count expected={e['statements']} actual={ns}")
    if 'findings' in e and isinstance(e['findings'], int):
        nf = sum(len(st.get('findings') or []) for st in p.get('statements', []))
        if e['findings'] != nf:
            errs.append(f"{cid}.matrix.findings count expected={e['findings']} actual={nf}")
    if isinstance(e.get('version'), dict):
        va = p.get('version') or {}
        for k, v in e['version'].items():
            if va.get(k) != v:
                errs.append(f"{cid}.matrix.version.{k} expected={v!r} actual={va.get(k)!r}")
    # finding.statement_index must equal its enclosing statement's index
    for pos, st in enumerate(p.get('statements', [])):
        si = stmt_index(st, pos)
        for f in st.get('findings') or []:
            if 'statement_index' in f and f['statement_index'] != si:
                errs.append(f"{cid}.finding.statement_index={f['statement_index']} enclosing={si}")
    # serialized literals must not appear
    if 'serialized_not_contains' in e:
        out = a.get('stdout') or ''
        for lit in e['serialized_not_contains']:
            if lit in out:
                errs.append(f"{cid}.matrix.serialized_contains {lit!r}")

# ---------- diagnostics shape + cross-representation ----------

# Source-derived classification enum (frozen HEAD 48e6de51):
#   internal/domain/spec/statement.go:110        DiagnosticParserError
#   internal/application/audit/diagnostics.go:14 DiagnosticUnsupportedStatement
#   internal/application/audit/diagnostics.go:26 DiagnosticGuidanceParserUpgradeCandidate
KNOWN_DIAG_CLASSES = {'parser_error', 'unsupported_statement', 'parser_upgrade_candidate'}

def diagnostics_contract(c, odial, errs, templates):
    cid = c['case_id']
    a = c.get('actual') or {}
    p = a.get('parsed') or {}
    diags = list(p.get('diagnostics') or []) + [d for st in p.get('statements', []) for d in st.get('diagnostics') or []]
    for i, d in enumerate(diags):
        cls = d.get('classification')
        if cls not in KNOWN_DIAG_CLASSES:
            errs.append(f"{cid}.diag[{i}].classification={cls!r} not in source enum")
        for f in ('reason', 'action_hint'):
            if not str(d.get(f) or '').strip():
                errs.append(f"{cid}.diag[{i}].{f} empty")
        if d.get('audited') is not False:
            errs.append(f"{cid}.diag[{i}].audited={d.get('audited')!r} expected False")
        if odial and d.get('dialect') != odial:
            errs.append(f"{cid}.diag[{i}].dialect={d.get('dialect')!r} oracle={odial!r}")
        if cls:
            templates[cls].add((d.get('reason'), d.get('action_hint')))
    # gap/unsupported real-field shape contract (oracle declares count only)
    pgaps = [g for st in p.get('statements', []) for g in st.get('evidence_gaps') or []]
    for i, g in enumerate(pgaps):
        if not (g.get('reason_code') or '').strip():
            errs.append(f"{cid}.gap[{i}].reason_code empty")
        if not (g.get('required_facts') or []):
            errs.append(f"{cid}.gap[{i}].required_facts empty")
    puns = list(p.get('unsupported') or [])
    for i, u in enumerate(puns):
        for f in ('feature', 'reason'):
            if not str(u.get(f) or '').strip():
                errs.append(f"{cid}.unsup[{i}].{f} empty")
    # cross-representation (R5+R6): stdout and parsed are TWO serializations of the
    # same audit result — they must agree bidirectionally, for EVERY structured
    # case, including cases where both sides are empty.
    #   - stdout must be valid JSON whenever parsed is a structured dict
    #   - top-level key SETS must be identical (field presence, both directions)
    #   - every shared non-'statements' top-level field compared — lists as exact
    #     serialized multisets, scalars/dicts by deep equality
    #   - statements: (index, raw_sql) identity + per-statement key-set parity +
    #     per-field equality with the same multiset rule — covers findings,
    #     evidence_gaps, diagnostics, coverage and any future field
    #   - verified on all 142 dual-serialized cases: zero serialization
    #     differences, so deep equality is the binding (no normalization beyond
    #     multiset ordering, which the findings-order positive control requires)
    out = a.get('stdout') or ''
    try:
        sj = json.loads(out)
    except Exception:
        sj = None
    if not isinstance(sj, dict):
        if p:
            errs.append(f"{cid}.xrepr stdout not valid JSON object while parsed is structured")
    else:
        # core identity, both directions
        for f in ('verdict',):
            if p.get(f) != sj.get(f):
                errs.append(f"{cid}.xrepr.verdict {p.get(f)!r}!={sj.get(f)!r}")
        pcov = p.get('coverage'); pcov = pcov.get('status') if isinstance(pcov, dict) else pcov
        scov = sj.get('coverage'); scov = scov.get('status') if isinstance(scov, dict) else scov
        if pcov != scov:
            errs.append(f"{cid}.xrepr.coverage {pcov!r}!={scov!r}")
        def stmt_ids(doc):
            return sorted((s.get('index'), ' '.join((s.get('raw_sql') or '').split()))
                          for s in doc.get('statements', []) or [])
        if stmt_ids(p) != stmt_ids(sj):
            errs.append(f"{cid}.xrepr.statements identity desync")
        # R6: full bidirectional field parity with STATEMENT OWNERSHIP preserved —
        # findings/evidence_gaps/diagnostics are compared per owning statement,
        # never flattened across statements (flattening would let a cross-
        # statement relocation pass undetected).
        # The reviewer's demonstrated misses (stdout-only finding delete and
        # stdout-only statement coverage change, both previously rc=0) are now
        # covered generically for all fields.
        def mset(xs):
            return sorted(map(lambda d: json.dumps(d, sort_keys=True), xs))
        def field_eq(pv, sv):
            if isinstance(pv, list) and isinstance(sv, list):
                return mset(pv) == mset(sv)
            return pv == sv
        pe, se = sorted(set(p) - set(sj)), sorted(set(sj) - set(p))
        if pe or se:
            errs.append(f"{cid}.xrepr keyset desync parsed-only={pe} stdout-only={se}")
        for k in sorted((set(p) & set(sj)) - {'statements'}):
            if not field_eq(p[k], sj[k]):
                errs.append(f"{cid}.xrepr.{k} desync")
        pm = {st.get('index'): st for st in p.get('statements', []) or [] if isinstance(st, dict)}
        sm = {st.get('index'): st for st in sj.get('statements', []) or [] if isinstance(st, dict)}
        for idx in sorted(set(pm) & set(sm)):
            ps_, ss_ = pm[idx], sm[idx]
            pe, se = sorted(set(ps_) - set(ss_)), sorted(set(ss_) - set(ps_))
            if pe or se:
                errs.append(f"{cid}.xrepr.stmt[{idx}] keyset desync parsed-only={pe} stdout-only={se}")
            for k in sorted(set(ps_) & set(ss_)):
                if not field_eq(ps_[k], ss_[k]):
                    errs.append(f"{cid}.xrepr.stmt[{idx}].{k} desync")

# ---------- C: step identity ----------

def bind_steps(cid, exp_steps, act_steps, label, errs):
    se, sa = steps_of(exp_steps), steps_of(act_steps)
    if len(se) != len(sa):
        errs.append(f"{cid}.{label}.steps len {len(se)}!={len(sa)}")
        return
    for i, (x, y) in enumerate(zip(se, sa)):
        if x.get('name') != y.get('name'):
            errs.append(f"{cid}.{label}[{i}].name {x.get('name')}!={y.get('name')}")
        erc = x.get('expect_rc', x.get('rc'))
        if erc is not None and erc != y.get('rc'):
            errs.append(f"{cid}.{label}[{i}].rc expected={erc} actual={y.get('rc')}")
        if x.get('sql') is not None and norm_sql(x.get('sql')) != norm_sql(y.get('sql')):
            errs.append(f"{cid}.{label}[{i}].sql")
        ve, va = x.get('verify') or [], y.get('verify') or []
        if len(ve) != len(va):
            errs.append(f"{cid}.{label}[{i}].verify len")
        for j, (vx, vy) in enumerate(zip(ve, va)):
            if 'expect' in vx and str(vx['expect']) != str(vy.get('output')):
                errs.append(f"{cid}.{label}[{i}].verify[{j}].expect={vx['expect']!r} out={vy.get('output')!r}")
            if vx.get('sql') is not None and norm_sql(vx.get('sql')) != norm_sql(vy.get('sql')):
                errs.append(f"{cid}.{label}[{i}].verify[{j}].sql")

def bind_case_steps(mrow, c, errs):
    cid = c['case_id']
    kind = mrow.get('kind')
    a = c.get('actual') or {}
    if kind == 'db_ddl':
        bind_steps(cid, mrow.get('steps'), a.get('steps'), 'ddl_steps', errs)
    elif kind == 'db_syntax_negative':
        if 'error_class' in mrow and mrow['error_class'] != a.get('error_class'):
            errs.append(f"{cid}.matrix.error_class expected={mrow['error_class']} actual={a.get('error_class')}")
        if mrow.get('rc_nonzero') and not a.get('rc'):
            errs.append(f"{cid}.matrix.rc_nonzero")
        for m in mrow.get('forbidden_markers') or []:
            if m in (a.get('stderr') or '') or m in (a.get('stdout') or ''):
                errs.append(f"{cid}.matrix.forbidden_marker {m!r}")
        if mrow.get('sql') is not None and norm_sql(mrow['sql']) != norm_sql(c.get('input_sql')):
            errs.append(f"{cid}.matrix.sql")
    elif kind == 'cli_metadata':
        e = mrow.get('expected') or {}
        for ph in ('setup', 'structure', 'execute', 'post_verify', 'teardown'):
            if ph in e:
                actp = (a.get(ph) or {})
                bind_steps(cid, e[ph], actp, ph, errs)

# ---------- D: fail-closed invariants ----------

def fail_closed(artifact, oracle, errs):
    req = artifact.get('required_case_ids')
    if not req:
        errs.append("artifact.required_case_ids missing or empty")
    ids = [c['case_id'] for c in artifact.get('cases') or []]
    if len(ids) != len(set(ids)):
        errs.append("artifact.cases duplicate case_id present")
    if req and set(req) != set(ids):
        errs.append(f"artifact.required!=executed diff={set(req) ^ set(ids)}")
    oreq = oracle.get('required_case_ids')
    if isinstance(oreq, list) and req and list(req) != list(oreq):
        errs.append("artifact.required_case_ids list != oracle.required_case_ids (content/order)")
    ec = artifact.get('executed_count')
    if ec is None:
        errs.append("artifact.executed_count missing")
    elif ec != len(artifact.get('cases') or []):
        errs.append(f"artifact.executed_count {ec}!={len(artifact.get('cases') or [])}")
    for c in artifact.get('cases') or []:
        cid = c.get('case_id')
        if c.get('status') != 'pass':
            errs.append(f"{cid}.status={c.get('status')!r}")
        astr = c.get('assertions')
        cnt = len(astr) if isinstance(astr, list) else (astr or 0)
        if not cnt > 0:
            errs.append(f"{cid}.assertions={astr!r:.80}")
        if isinstance(astr, list):
            for i, x in enumerate(astr):
                if isinstance(x, dict) and x.get('ok') is not True:
                    errs.append(f"{cid}.assertions[{i}].ok={x.get('ok')!r}")

# ---------- main ----------

def main():
    ap = argparse.ArgumentParser()
    here = os.path.dirname(os.path.abspath(__file__))
    ap.add_argument('--artifact', default=os.path.join(here, '..', 'golden', 'artifact.json'))
    ap.add_argument('--matrix', default=os.path.join(here, '..', 'oracle', 'matrix-v3.json'))
    ap.add_argument('--oracle', default=os.path.join(here, '..', 'golden', 'T18.json'))
    a = ap.parse_args()
    for p in (a.artifact, a.matrix, a.oracle):
        if not os.path.isfile(p):
            print(f"required input missing: {p}")
            sys.exit(1)
        if os.path.getsize(p) == 0:
            print(f"required input empty: {p}")
            sys.exit(1)
    artifact, matrix, oracle = load(a.artifact), load(a.matrix), load(a.oracle)
    errs = []
    bind_oracle(oracle, artifact, errs)
    mm = matrix_map(matrix)
    oracle_ids = set(oracle_case_map(oracle))
    matrix_ids = set(mm)
    if matrix_ids != oracle_ids:
        errs.append(f"matrix.case_ids != oracle diff={matrix_ids ^ oracle_ids}")
    omap = oracle_case_map(oracle)
    for cid, (kind, oc) in omap.items():
        mr = mm.get(cid)
        if not mr:
            continue
        if mr.get('kind') != kind:
            errs.append(f"{cid}.matrix.kind oracle={kind} matrix={mr.get('kind')}")
        oe = oc.get('expect') or {}
        me = mr.get('expected') or {}
        for f in (oe if kind != 'db_syntax_negative' else {}):
            if f not in me:
                errs.append(f"{cid}.matrix_missing.{f}")
            elif me[f] != oe[f]:
                errs.append(f"{cid}.matrix_vs_oracle.{f}")
        if kind == 'db_syntax_negative':
            for f in ('error_class', 'rc_nonzero', 'forbidden_markers'):
                if f in oe:
                    if f not in mr:
                        errs.append(f"{cid}.matrix_missing.{f}")
                    elif mr[f] != oe[f]:
                        errs.append(f"{cid}.matrix_vs_oracle.{f}")
            if oc.get('sql') and norm_sql(oc['sql']) != norm_sql(mr.get('input_sql')):
                errs.append(f"{cid}.matrix_vs_oracle.sql")
        if kind == 'db_ddl':
            osteps = [(s.get('name'), s.get('expect_rc')) for s in oc.get('steps') or []]
            msteps = [(s.get('name'), s.get('expect_rc')) for s in mr.get('steps') or []]
            if osteps != msteps:
                errs.append(f"{cid}.matrix_vs_oracle.steps")
            for i, s in enumerate(oc.get('steps') or []):
                ov = [v.get('expect') for v in s.get('verify') or []]
                mv = [v.get('expect') for v in (mr.get('steps') or [{}])[i].get('verify') or []]
                if ov != mv:
                    errs.append(f"{cid}.matrix_vs_oracle.steps[{i}].verify")
        for ph in ('setup', 'structure', 'execute', 'post_verify', 'teardown'):
            if ph in oc:
                osteps = [(s.get('name'), s.get('expect_rc')) for s in oc[ph]]
                msteps = [(s.get('name'), s.get('expect_rc')) for s in (me.get(ph) or [])]
                if osteps != msteps:
                    errs.append(f"{cid}.matrix_vs_oracle.{ph}")
    odial = {}
    for c in (oracle.get('cli_cases') or []):
        odial['T18.cli.' + c['id']] = c.get('dialect')
    for c in (oracle.get('metadata_cases') or []):
        odial['T18.meta.' + c['id']] = c.get('dialect')
    templates = collections.defaultdict(set)
    for c in artifact.get('cases') or []:
        cid = c['case_id']
        if cid not in mm:
            errs.append(f"{cid}: no matrix row")
            continue
        bind_matrix_to_actual(mm[cid], c, errs)
        bind_case_steps(mm[cid], c, errs)
        diagnostics_contract(c, odial.get(cid), errs, templates)
    # diagnostics template consistency: every entry of one classification must
    # carry the identical (reason, action_hint) — synced tampering on a single
    # entry desyncs it from all sibling entries of the same class.
    for cls, ts in templates.items():
        if len(ts) > 1:
            errs.append(f"diag.template[{cls}] {len(ts)} distinct (reason,action_hint) tuples")
    fail_closed(artifact, oracle, errs)
    if errs:
        for e in errs[:60]:
            print("MISMATCH", e)
        print(f"verify: {len(errs)} mismatches")
        sys.exit(1)
    print("verify: 0 mismatches")

if __name__ == '__main__':
    main()
