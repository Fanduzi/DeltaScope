#!/usr/bin/env python3
"""T18-R3 validator process-level selftest — clean-baseline isolation.

For every control: (1) copy the three inputs unmutated, run verify, require
rc=0 (clean baseline); (2) apply ONLY the recorded mutation, rerun, require
rc=1 AND at least one MISMATCH line in the target family AND no traceback.

Mutations are expressed as JSON-path ops on the copied inputs so the record is
self-describing. Results appended to process_selftest_r3.jsonl / .tsv with
argv, rc, stdout, stderr, input SHAs.
"""
import copy, hashlib, json, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ART = os.path.join(HERE, '..', 'golden', 'artifact.json')
MAT = os.path.join(HERE, '..', 'oracle', 'matrix-v3.json')
ORC = os.path.join(HERE, '..', 'golden', 'T18.json')
VAL = os.path.join(HERE, 'validate_t18_r3.py')
CASE_CLI = 'T18.cli.target-source-unvouched-current' # cli_audit, 1 finding idx0
CASE_META = 'T18.meta.mysql57-review-orderby-refusal' # cli_metadata, full phases+locations+metadata
CASE_DB = 'T18.db.mysql80.ddl'                       # db_ddl steps
CASE_SN = 'T18.db.mysql80.syntax_negative'           # syntax_negative

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''):
            h.update(c)
    return h.hexdigest()

def jget(d, path):
    for k in path:
        d = d[k]
    return d

def jset(d, path, val):
    for k in path[:-1]:
        d = d[k]
    d[path[-1]] = val

def jdel(d, path):
    for k in path[:-1]:
        d = d[k]
    del d[path[-1]]

def case_idx(matrix, cid):
    return next(i for i, r in enumerate(matrix) if r['case_id'] == cid)

def art_idx(artifact, cid):
    return next(i for i, r in enumerate(artifact['cases']) if r['case_id'] == cid)

# ---- mutation library: (name, which_file, mutator, expected_family) ----
# expected_family = substring that must appear in a MISMATCH line
MUTS = []

def mut(name, fn):
    def deco(f):
        MUTS.append((name, f))
        return f
    return deco

def in_matrix(mtx, cid):
    return next(r for r in mtx if r['case_id'] == cid)

def in_art(art, cid):
    return next(r for r in art['cases'] if r['case_id'] == cid)

@mut('R3-neg-matrix-verdict', 'matrix')
def _(d): in_matrix(d, CASE_CLI)['expected']['verdict'] = 'pass'
@mut('R3-neg-matrix-coverage', 'matrix')
def _(d): in_matrix(d, CASE_CLI)['expected']['coverage'] = 'complete'
@mut('R3-neg-matrix-stmt-indices', 'matrix')
def _(d): in_matrix(d, CASE_CLI)['expected']['statement_indices'] = [0, 1]
@mut('R3-neg-matrix-stmt-sql', 'matrix')
def _(d): in_matrix(d, CASE_CLI)['expected']['statement_sql'] = ['DROP VIEW x']
@mut('R3-neg-matrix-finding-rule', 'matrix')
def _(d): in_matrix(d, CASE_CLI)['expected']['finding_entries'][0]['rule_id'] = 'ddl.other.rule'
@mut('R3-neg-matrix-finding-level', 'matrix')
def _(d): in_matrix(d, CASE_CLI)['expected']['finding_entries'][0]['level'] = 'notice'
@mut('R3-neg-matrix-finding-index', 'matrix')
def _(d): in_matrix(d, CASE_CLI)['expected']['finding_entries'][0]['index'] = 9
@mut('R3-neg-matrix-finding-dup', 'matrix')
def _(d): e = in_matrix(d, CASE_CLI)['expected']['finding_entries']; e.append(dict(e[0]))
@mut('R3-neg-matrix-location', 'matrix')
def _(d): in_matrix(d, CASE_META)['expected']['finding_locations'][0]['line'] = 99
@mut('R3-neg-matrix-location-del', 'matrix')
def _(d): in_matrix(d, CASE_META)['expected']['finding_locations'].pop(0)
@mut('R3-neg-matrix-metadata', 'matrix')
def _(d): in_matrix(d, CASE_META)['expected']['finding_metadata'][0]['metadata']['view'] = 'zzz'
@mut('R3-neg-matrix-fail-on', 'matrix')
def _(d):
    r = in_matrix(d, CASE_CLI)
    r['expected']['fail_on_triggered'] = not r['expected'].get('fail_on_triggered')
@mut('R3-neg-artifact-gap-facts', 'artifact')
def _(d):
    a = next(x for x in d['cases'] if any(s.get('evidence_gaps') for s in (x.get('actual',{}).get('parsed') or {}).get('statements',[])))
    for s in a['actual']['parsed']['statements']:
        if s.get('evidence_gaps'):
            s['evidence_gaps'][0]['required_facts'] = ['nonexistent_fact']
            break
@mut('R3-neg-artifact-unsupported', 'artifact')
def _(d):
    a = next(x for x in d['cases'] if (x.get('actual',{}).get('parsed') or {}).get('unsupported'))
    a['actual']['parsed']['unsupported'][0]['feature'] = 'zz.nine'
@mut('R3-neg-matrix-serialized', 'matrix')
def _(d):
    r = next(x for x in d if (x.get('expected') or {}).get('serialized_not_contains'))
    r['expected']['serialized_not_contains'].append('nonexistent_literal_xyz')
@mut('R3-neg-matrix-diag-count', 'matrix')
def _(d):
    r = next(x for x in d if (x.get('expected') or {}).get('diagnostics'))
    r['expected']['diagnostics'] = 99
@mut('R3-neg-matrix-step-name', 'matrix')
def _(d): in_matrix(d, CASE_DB)['steps'][1]['name'] = 'renamed-step'
@mut('R3-neg-matrix-step-rc', 'matrix')
def _(d): in_matrix(d, CASE_DB)['steps'][1]['expect_rc'] = 7
@mut('R3-neg-matrix-step-verify', 'matrix')
def _(d):
    s = next(s for s in in_matrix(d, CASE_DB)['steps'] if s.get('verify'))
    s['verify'][0]['expect'] = 'zzz'
@mut('R3-neg-matrix-meta-setup-rc', 'matrix')
def _(d): in_matrix(d, CASE_META)['expected']['setup'][0]['expect_rc'] = 9
@mut('R3-neg-matrix-meta-exec-verify', 'matrix')
def _(d):
    s = next(s for s in in_matrix(d, CASE_META)['expected']['execute'] if s.get('verify'))
    s['verify'][0]['expect'] = 'zzz'
@mut('R3-neg-matrix-sn-errorclass', 'matrix')
def _(d): in_matrix(d, CASE_SN)['error_class'] = 'zz_nine'
@mut('R3-neg-artifact-actual-verdict', 'artifact')
def _(d): in_art(d, CASE_CLI)['actual']['parsed']['verdict'] = 'pass'
@mut('R3-neg-artifact-actual-finding', 'artifact')
def _(d): in_art(d, CASE_CLI)['actual']['parsed']['statements'][0]['findings'][0]['rule_id'] = 'ddl.other.rule'
@mut('R3-neg-artifact-actual-location', 'artifact')
def _(d): in_art(d, CASE_META)['actual']['parsed']['statements'][0]['findings'][0]['location'] = {'line': 9, 'column': 9}
@mut('R3-neg-artifact-required-del', 'artifact')
def _(d): del d['required_case_ids']
@mut('R3-neg-artifact-required-empty', 'artifact')
def _(d): d['required_case_ids'] = []
@mut('R3-neg-artifact-required-shrink', 'artifact')
def _(d): d['required_case_ids'].pop(0)
@mut('R3-neg-artifact-executed-del', 'artifact')
def _(d): del d['executed_count']
@mut('R3-neg-artifact-executed-wrong', 'artifact')
def _(d): d['executed_count'] = 999
@mut('R3-neg-artifact-status', 'artifact')
def _(d): in_art(d, CASE_CLI)['status'] = 'fail'
@mut('R3-neg-artifact-assertions-empty', 'artifact')
def _(d): in_art(d, CASE_CLI)['assertions'] = []
@mut('R3-neg-matrix-gap-entry-reason', 'matrix')
def _(d):
    r = next(x for x in d if (x.get('expected') or {}).get('evidence_gap_entries'))
    r['expected']['evidence_gap_entries'][0]['reason_code'] = 'zz_reason'
@mut('R3-neg-matrix-gap-entry-facts', 'matrix')
def _(d):
    r = next(x for x in d if (x.get('expected') or {}).get('evidence_gap_entries'))
    r['expected']['evidence_gap_entries'][0]['required_facts'] = ['zz.fact']
@mut('R3-neg-matrix-unsup-entry-feature', 'matrix')
def _(d):
    r = next(x for x in d if (x.get('expected') or {}).get('unsupported_entries'))
    r['expected']['unsupported_entries'][0]['feature'] = 'zz.feature'
@mut('R3-neg-matrix-unsup-entry-reason', 'matrix')
def _(d):
    r = next(x for x in d if (x.get('expected') or {}).get('unsupported_entries'))
    r['expected']['unsupported_entries'][0]['reason'] = 'zz reason'
@mut('R3-neg-matrix-unsup-entry-meta', 'matrix')
def _(d):
    r = next(x for x in d if any(u.get('metadata') for u in (x.get('expected') or {}).get('unsupported_entries') or []))
    for u in r['expected']['unsupported_entries']:
        if u.get('metadata'):
            u['metadata'] = {'aspect': 'zz'}; break
@mut('R3-neg-matrix-unsup-entry-index', 'matrix')
def _(d):
    r = next(x for x in d if (x.get('expected') or {}).get('unsupported_entries'))
    r['expected']['unsupported_entries'][0]['index'] = 9
@mut('R3-neg-oracle-gap-entry', 'oracle')
def _(d):
    c = next(x for x in d['cli_cases'] if (x.get('expect') or {}).get('evidence_gap_entries'))
    c['expect']['evidence_gap_entries'][0]['reason_code'] = 'zz_reason'
@mut('R3-neg-oracle-unsup-entry', 'oracle')
def _(d):
    c = next(x for x in d['cli_cases'] if (x.get('expect') or {}).get('unsupported_entries'))
    c['expect']['unsupported_entries'][0]['feature'] = 'zz.feature'
@mut('R3-neg-artifact-diag-class', 'artifact')
def _(d):
    a = in_art(d, 'T18.cli.mysql-invalid-select')
    if a['actual']['parsed'].get('diagnostics'):
        a['actual']['parsed']['diagnostics'][0]['classification'] = 'zz_class'
    else:
        a['actual']['parsed']['statements'][0]['diagnostics'][0]['classification'] = 'zz_class'
@mut('R3-neg-oracle-verdict', 'oracle')
def _(d):
    c = next(x for x in d['cli_cases'] if 'T18.cli.' + x['id'] == CASE_CLI)
    c['expect']['verdict'] = 'pass'
# ---- synced parsed+stdout dual-write mutations (bypass xrepr; must be caught
# ---- by field-level oracle/enum/template bindings)
def dual_mut(d, cid, fn):
    a = in_art(d, cid)
    fn(a['actual']['parsed'])
    sj = json.loads(a['actual']['stdout'])
    fn(sj)
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-assertions-ok', 'artifact')
def _(d): in_art(d, CASE_CLI)['assertions'][0]['ok'] = False
@mut('R3-neg-artifact-dup-case', 'artifact')
def _(d):
    dup = copy.deepcopy(d['cases'][0])
    d['cases'].append(dup)
    d['executed_count'] = len(d['cases'])
@mut('R3-neg-artifact-finding-stindex', 'artifact')
def _(d):
    a = in_art(d, 'T18.meta.mysql80-alter-dependencies')
    for s in a['actual']['parsed']['statements']:
        for f in s.get('findings') or []:
            if 'statement_index' in f:
                f['statement_index'] = f['statement_index'] + 1
                return
@mut('R3-neg-artifact-gap-dual', 'artifact')
def _(d):
    def m(doc):
        for s in doc.get('statements', []):
            if s.get('evidence_gaps'):
                s['evidence_gaps'][0]['reason_code'] = 'zz_reason'
                return
    dual_mut(d, 'T18.cli.source-unvouched-current', m)
@mut('R3-neg-artifact-unsup-dual', 'artifact')
def _(d):
    def m(doc): doc['unsupported'][0]['feature'] = 'zz.feature'
    dual_mut(d, 'T18.cli.tidb-alter-vendor', m)
@mut('R3-neg-artifact-diag-dual', 'artifact')
def _(d):
    def m(doc): doc['diagnostics'][0]['reason'] = 'zz synced tamper'
    dual_mut(d, 'T18.cli.mysql-invalid-select', m)
@mut('R3-neg-artifact-stdout-bad', 'artifact')
def _(d): in_art(d, 'T18.cli.mysql-invalid-select')['actual']['stdout'] = '{not json'
@mut('R3-neg-artifact-stdout-badjson-pass', 'artifact')
def _(d): in_art(d, 'T18.cli.mysql-plain-all-off')['actual']['stdout'] = '{not json'
@mut('R3-neg-artifact-stdout-empty-obj', 'artifact')
def _(d): in_art(d, 'T18.cli.mysql-plain-all-off')['actual']['stdout'] = '{}'
@mut('R3-neg-artifact-stdout-diag-del', 'artifact')
def _(d):
    a = in_art(d, 'T18.cli.mysql-invalid-select')
    sj = json.loads(a['actual']['stdout']); sj['diagnostics'] = []
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-gap-del', 'artifact')
def _(d):
    a = in_art(d, 'T18.cli.source-unvouched-current')
    sj = json.loads(a['actual']['stdout'])
    for s in sj.get('statements', []): s['evidence_gaps'] = []
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-unsup-del', 'artifact')
def _(d):
    a = in_art(d, 'T18.cli.tidb-alter-vendor')
    sj = json.loads(a['actual']['stdout']); sj['unsupported'] = []
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-entry-del', 'artifact')
def _(d):
    a = in_art(d, 'T18.cli.mysql-invalid-select')
    sj = json.loads(a['actual']['stdout']); sj['diagnostics'].pop(0)
    a['actual']['stdout'] = json.dumps(sj)
# R6 controls — work-order N1..N9 stdout-only semantic mutations.
# N1/N5/N6 replicate the reviewer's demonstrated misses verbatim.
@mut('R3-neg-artifact-stdout-N1-finding-del', 'artifact')
def _(d):  # N1: stdout-only delete finding
    a = in_art(d, 'T18.cli.target-source-unvouched-current')
    sj = json.loads(a['actual']['stdout'])
    sj['statements'][0]['findings'].pop(0)
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-N2-finding-dup', 'artifact')
def _(d):  # N2: stdout-only add duplicate finding (multiplicity)
    a = in_art(d, 'T18.cli.target-source-unvouched-current')
    sj = json.loads(a['actual']['stdout'])
    sj['statements'][0]['findings'].append(sj['statements'][0]['findings'][0])
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-N3-finding-rule', 'artifact')
def _(d):  # N3: stdout-only change finding rule_id + level
    a = in_art(d, 'T18.cli.target-source-unvouched-current')
    sj = json.loads(a['actual']['stdout'])
    sj['statements'][0]['findings'][0]['rule_id'] = 'ddl.other.rule'
    sj['statements'][0]['findings'][0]['level'] = 'blocker'
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-N4-finding-loc', 'artifact')
def _(d):  # N4: stdout-only change finding location + suggestion(metadata)
    a = in_art(d, 'T18.cli.target-source-unvouched-current')
    sj = json.loads(a['actual']['stdout'])
    f = sj['statements'][0]['findings'][0]
    f['location'] = {'line': 99, 'column': 99}
    f['suggestion'] = 'zz tampered hint'
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-N5-finding-move', 'artifact')
def _(d):  # N5: stdout-only move finding across statements (owner lost if flattened)
    a = in_art(d, 'T18.meta.mysql80-alter-dependencies')
    sj = json.loads(a['actual']['stdout'])
    f = sj['statements'][0]['findings'].pop(0)
    sj['statements'][1]['findings'].append(f)
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-N6-stmt-cov', 'artifact')
def _(d):  # N6: stdout-only change statement coverage
    a = in_art(d, 'T18.cli.mysql-plain-all-off')
    sj = json.loads(a['actual']['stdout'])
    sj['statements'][0]['coverage']['status'] = 'incomplete'
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-N7-summary-mut', 'artifact')
def _(d):  # N7: stdout-only change summary counts
    a = in_art(d, 'T18.cli.mysql-plain-all-off')
    sj = json.loads(a['actual']['stdout']); sj['summary']['warnings'] = 9
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-N8-stmt-kind', 'artifact')
def _(d):  # N8: stdout-only change statement identity field (kind)
    a = in_art(d, 'T18.cli.mysql-plain-all-off')
    sj = json.loads(a['actual']['stdout']); sj['statements'][0]['kind'] = 'dml'
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-N9a-unsup-owner', 'artifact')
def _(d):  # N9a: stdout-only change unsupported statement ownership (sql identity)
    a = in_art(d, 'T18.cli.tidb-alter-vendor')
    sj = json.loads(a['actual']['stdout'])
    sj['unsupported'][0]['sql'] = 'ALTER VIEW other.x AS SELECT 1;'
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-N9b-gap-owner', 'artifact')
def _(d):  # N9b: stdout-only cross-statement gap relocation. Sealed corpus has
    # NO multi-statement gap-bearing case (verified) — deterministic derived
    # probe: clone stmt[0] as stmt[1] in STDOUT ONLY and move one gap there.
    a = in_art(d, 'T18.cli.target-source-unvouched-current')
    sj = json.loads(a['actual']['stdout'])
    s0 = sj['statements'][0]
    s1 = dict(s0); s1['index'] = 1; s1['raw_sql'] = 'SELECT 2'
    s1['evidence_gaps'] = [s0['evidence_gaps'].pop(0)]
    s1['findings'] = []
    sj['statements'].append(s1)
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-field-del', 'artifact')
def _(d):
    a = in_art(d, 'T18.cli.mysql-plain-all-off')
    sj = json.loads(a['actual']['stdout']); del sj['summary']
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-stdout-key-add', 'artifact')
def _(d):
    a = in_art(d, 'T18.cli.mysql-plain-all-off')
    sj = json.loads(a['actual']['stdout']); sj['zz_extra'] = True
    a['actual']['stdout'] = json.dumps(sj)
@mut('R3-neg-artifact-parsed-finding-del', 'artifact')
def _(d):
    a = in_art(d, 'T18.cli.target-source-unvouched-current')
    a['actual']['parsed']['statements'][0]['findings'].pop(0)
@mut('R3-neg-artifact-parsed-stmt-cov', 'artifact')
def _(d):
    a = in_art(d, 'T18.cli.target-source-unvouched-current')
    a['actual']['parsed']['statements'][0]['coverage']['status'] = 'complete'
@mut('R3-neg-artifact-parsed-gapdel-stmt', 'artifact')
def _(d):
    a = in_art(d, 'T18.cli.target-source-unvouched-current')
    for s in a['actual']['parsed'].get('statements', []): s['evidence_gaps'] = []
@mut('R3-neg-matrix-field-missing', 'matrix')
def _(d): del in_matrix(d, CASE_CLI)['expected']['verdict']
@mut('R3-neg-artifact-inject-finding', 'artifact')
def _(d):
    a = in_art(d, 'T18.cli.mysql-plain-all-off')
    a['actual']['parsed']['statements'][0].setdefault('findings', []).append(
        {'rule_id': 'ddl.view.create.forbid', 'level': 'blocker',
         'statement_index': 0, 'location': {'line': 1, 'column': 1}})
@mut('R3-neg-delete-artifact', 'delete:artifact')
def _(d): pass
@mut('R3-neg-delete-matrix', 'delete:matrix')
def _(d): pass
@mut('R3-neg-delete-oracle', 'delete:oracle')
def _(d): pass
@mut('R3-neg-corrupt-artifact', 'corrupt:artifact')
def _(d): pass
@mut('R3-neg-corrupt-matrix', 'corrupt:matrix')
def _(d): pass
@mut('R3-neg-corrupt-oracle', 'corrupt:oracle')
def _(d): pass

FAMILY = {
    'verdict': 'verdict', 'coverage': 'coverage', 'stmt-indices': 'stmt_indices',
    'stmt-sql': 'stmt_sql', 'finding-rule': 'finding', 'finding-level': 'finding',
    'finding-index': 'finding', 'finding-dup': 'finding', 'location': 'finding_location',
    'metadata': 'finding_metadata', 'fail-on': 'fail_on', 'gap-facts': 'gap',
    'gap-entry': 'gap', 'unsup-entry': 'unsup',
    'unsupported': 'unsup', 'serialized': 'serialized', 'diag-count': 'diagnostics',
    'step-name': 'name', 'step-rc': 'rc', 'step-verify': 'verify', 'setup-rc': 'rc',
    'exec-verify': 'verify', 'sn-errorclass': 'error_class', 'actual-verdict': 'verdict',
    'actual-finding': 'finding', 'actual-location': 'finding_location',
    'required': 'required', 'executed': 'executed', 'status': 'status',
    'assertions-empty': 'assertions', 'assertions-ok': 'assertions',
    'dup-case': 'duplicate', 'stindex': 'statement_index',
    'gap-dual': 'gap', 'unsup-dual': 'unsup', 'diag-dual': 'diag',
    'stdout-': 'xrepr', 'parsed-': 'xrepr', 'missing': 'missing', 'inject-finding': 'finding',
    'diag-class': 'diag', 'oracle-verdict': 'expected',
    'delete': 'required input', 'corrupt': 'required input',
}

def family_for(name):
    for k, v in FAMILY.items():
        if k in name:
            return v
    return ''

def run_verify(a, m, o):
    return subprocess.run([sys.executable, VAL, '--artifact', a, '--matrix', m, '--oracle', o],
                          capture_output=True, text=True)

def main():
    out_jsonl = os.path.join(HERE, 'process_selftest_r3.jsonl')
    out_tsv = os.path.join(HERE, 'process_selftest_r3.tsv')
    results = []
    total = ok = 0
    for name, fn in MUTS:
        total += 1
        with tempfile.TemporaryDirectory(prefix='t18r3-') as td:
            fa, fm, fo = (os.path.join(td, x) for x in ('a.json', 'm.json', 'o.json'))
            for src, dst in ((ART, fa), (MAT, fm), (ORC, fo)):
                with open(src, 'rb') as r, open(dst, 'wb') as w:
                    w.write(r.read())
            inp_sha = {'artifact': sha(fa), 'matrix': sha(fm), 'oracle': sha(fo)}
            # baseline: unmutated copies must verify rc=0
            base = run_verify(fa, fm, fo)
            base_ok = base.returncode == 0
            # target file is encoded in the control name:
            #   ...-delete-X / ...-corrupt-X / ...-<artifact|matrix|oracle>-...
            if '-delete-' in name or '-corrupt-' in name:
                op, tgt = ('delete', name.rsplit('-', 1)[1]) if '-delete-' in name else ('corrupt', name.rsplit('-', 1)[1])
                fkey = f"{op}:{tgt}"
            else:
                fkey = next((t for t in ('artifact', 'matrix', 'oracle') if '-' + t in name), 'matrix')
            if fkey.startswith('delete:'):
                os.unlink({'artifact': fa, 'matrix': fm, 'oracle': fo}[fkey.split(':')[1]])
            elif fkey and fkey.startswith('corrupt:'):
                p = {'artifact': fa, 'matrix': fm, 'oracle': fo}[fkey.split(':')[1]]
                open(p, 'w').write('{not json')
            else:
                p = {'artifact': fa, 'matrix': fm, 'oracle': fo}[fkey or 'matrix']
                doc = json.load(open(p))
                fn(doc)
                json.dump(doc, open(p, 'w'))
            res = run_verify(fa, fm, fo)
            fam = family_for(name)
            mismatch_lines = [l for l in (res.stdout + res.stderr).splitlines() if 'MISMATCH' in l or 'required input' in l]
            fam_hit = any(fam in l for l in mismatch_lines)
            tb = 'Traceback' in res.stderr
            passed = base_ok and res.returncode == 1 and fam_hit and not tb
            ok += passed
            rec = {'control': name, 'baseline_rc': base.returncode, 'rc': res.returncode,
                   'family': fam, 'family_hit': fam_hit, 'traceback': tb,
                   'mismatches': len(mismatch_lines), 'input_sha': inp_sha,
                   'argv': f"{sys.executable} {VAL} --artifact a.json --matrix m.json --oracle o.json",
                   'stdout_tail': (res.stdout or '')[-400:], 'stderr_tail': (res.stderr or '')[-300:],
                   'ok': passed}
            results.append(rec)
            print(f"{name}\tbase_rc={base.returncode}\trc={res.returncode}\tfam={fam} hit={fam_hit}\ttb={tb}\tok={passed}")
            open(os.path.join(HERE, 'selftest-r3', f'stdout-{name}.txt'), 'w').write(res.stdout or '')
            open(os.path.join(HERE, 'selftest-r3', f'stderr-{name}.txt'), 'w').write(res.stderr or '')
            open(os.path.join(HERE, 'selftest-r3', f'baseline-{name}.txt'), 'w').write(base.stdout or '')
    # positive mutation controls: recorded mutation that MUST still verify rc=0
    # (multiset semantics — same-statement finding order is not significant;
    # JSON object key order is not significant)
    def _pos_keyorder(d):
        # P2: re-serialize stdout with reversed key order at every level.
        # Semantically identical JSON object — must stay rc=0.
        a = in_art(d, 'T18.cli.target-source-unvouched-current')
        sj = json.loads(a['actual']['stdout'])
        def rev(o):
            if isinstance(o, dict):
                return {k: rev(o[k]) for k in reversed(list(o))}
            if isinstance(o, list):
                return [rev(x) for x in o]
            return o
        a['actual']['stdout'] = json.dumps(rev(sj))
    POSMUTS = [
        ('R3-pos-findings-order-reversal', 'artifact',
         lambda d: in_art(d, 'T18.meta.mysql80-alter-source-absent')
                     ['actual']['parsed']['statements'][0]['findings'].reverse()),
        ('R3-pos-stdout-keyorder', 'artifact', _pos_keyorder),
    ]
    for name, tgt, fn in POSMUTS:
        with tempfile.TemporaryDirectory(prefix='t18r3-posm-') as td:
            fa, fm, fo = (os.path.join(td, x) for x in ('a.json', 'm.json', 'o.json'))
            for src, dst in ((ART, fa), (MAT, fm), (ORC, fo)):
                with open(src, 'rb') as r, open(dst, 'wb') as w:
                    w.write(r.read())
            base = run_verify(fa, fm, fo)
            p = {'artifact': fa, 'matrix': fm, 'oracle': fo}[tgt]
            doc = json.load(open(p))
            fn(doc)
            json.dump(doc, open(p, 'w'))
            res = run_verify(fa, fm, fo)
            pok = base.returncode == 0 and res.returncode == 0
            results.append({'control': name, 'baseline_rc': base.returncode, 'rc': res.returncode,
                            'expect_rc': 0, 'ok': pok,
                            'input_sha': {'artifact': sha(fa), 'matrix': sha(fm), 'oracle': sha(fo)},
                            'stdout_tail': (res.stdout or '')[-400:]})
            print(f"{name}\tbase_rc={base.returncode}\trc={res.returncode}\texpect=0\tok={pok}")
            open(os.path.join(HERE, 'selftest-r3', f'stdout-{name}.txt'), 'w').write(res.stdout or '')
    # positive control: unmutated baseline only
    with tempfile.TemporaryDirectory(prefix='t18r3-pos-') as td:
        fa, fm, fo = (os.path.join(td, x) for x in ('a.json', 'm.json', 'o.json'))
        for src, dst in ((ART, fa), (MAT, fm), (ORC, fo)):
            with open(src, 'rb') as r, open(dst, 'wb') as w:
                w.write(r.read())
        res = run_verify(fa, fm, fo)
        pos_ok = res.returncode == 0 and '0 mismatches' in res.stdout
        results.append({'control': 'R3-pos-baseline', 'rc': res.returncode, 'ok': pos_ok,
                        'input_sha': {'artifact': sha(fa), 'matrix': sha(fm), 'oracle': sha(fo)}})
        print(f"R3-pos-baseline\trc={res.returncode}\tok={pos_ok}")
    with open(out_jsonl, 'w') as f:
        for r in results:
            f.write(json.dumps(r, sort_keys=True) + '\n')
    with open(out_tsv, 'w') as f:
        for r in results:
            f.write(f"{r['control']}\t{r.get('rc')}\t{r.get('family','')}\t{r['ok']}\n")
    neg = [r for r in results if r['control'].startswith('R3-neg-')]
    pos = [r for r in results if r['control'].startswith('R3-pos-')]
    print(f"denominators: baseline-clean {sum(1 for r in neg if r.get('baseline_rc')==0)}/{len(neg)}; "
          f"negatives {sum(1 for r in neg if r['ok'])}/{len(neg)}; "
          f"positive-mutations {sum(1 for r in pos if r['ok'])}/{len(pos)}")
    sys.exit(0 if all(r['ok'] for r in results) else 1)

if __name__ == '__main__':
    os.makedirs(os.path.join(HERE, 'selftest-r3'), exist_ok=True)
    main()
