#!/usr/bin/env python3
"""T18-R2 process-level self-test .

Per directed tamper: isolated temp copies of artifact+matrix+oracle, mutate
via JSON path, invoke the REAL validator CLI as a subprocess, archive
argv/exit code/FULL stdout/FULL stderr. No stdout/stderr truncation.

ER3 additions: every test has a substantive expected field family (matched
against ALL mismatch lines, not just the first); ER2 multiset tests added:
  R1-pos-permutation  — same-statement reorder, matrix regenerated, rc=0
  R1-neg-dup-finding  — duplicate finding in one statement, rc!=0
  R1-neg-missing      — delete a finding, rc!=0
  (cross-stmt move / rule/level / stmt_index already covered by R2 set)

Denominators reported separately:
  expected-nonzero exits, correct field-family detections,
  positive transformations expected to exit 0.
"""
import json, os, sys, copy, subprocess, tempfile, shutil, importlib.util

HERE = os.path.dirname(os.path.abspath(__file__))
VAL = os.path.join(HERE, 'validate_t18_r2.py')
GOLD = os.path.join(HERE, '..', 'golden')
OUTDIR = os.path.join(HERE, 'selftest-r2')
OUT = os.path.join(HERE, 'process_selftest_r2.tsv')
JSONL = os.path.join(HERE, 'process_selftest_r2.jsonl')

spec = importlib.util.spec_from_file_location('v', VAL)
v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)


def load(p):
    with open(p) as f:
        return json.load(f)


def save(p, d):
    with open(p, 'w') as f:
        json.dump(d, f)


def case(art, cid_suffix):
    return next(c for c in art['cases'] if c['case_id'].endswith(cid_suffix))


def run_one(name, mutate, expect_field, expect_rc, mode=None):
    """mutate(art,mat,ora)->(target_desc,old,new). Full output archived.
    mode: 'regen' regenerates matrix post-mutation (sync tamper);
    'delete:<file>' / 'corrupt:<file>' operate on a single input path."""
    td = tempfile.mkdtemp(prefix='t18r2-')
    ap, mp, op = (os.path.join(td, x) for x in ('a.json', 'm.json', 'o.json'))
    art, mat, ora = (load(f'{GOLD}/artifact.json'), load(f'{GOLD}/matrix-t18.json'),
                     load(f'{GOLD}/T18.json'))
    desc = mutate(art, mat, ora)
    save(ap, art); save(mp, mat); save(op, ora)
    if expect_rc == 0 or mode == 'regen':  # matrix regenerated from artifact
        mat[:] = [v.derive_row(c) for c in art['cases']]
        save(mp, mat)
    if mode and mode.startswith('delete:'):
        os.remove({'a': ap, 'm': mp, 'o': op}[mode.split(':')[1]])
    if mode and mode.startswith('corrupt:'):
        with open({'a': ap, 'm': mp, 'o': op}[mode.split(':')[1]], 'w') as f:
            f.write('{malformed')
    argv = [sys.executable, VAL, '--artifact', ap, '--matrix', mp, '--oracle', op]
    r = subprocess.run(argv, capture_output=True, text=True)
    os.makedirs(OUTDIR, exist_ok=True)
    with open(os.path.join(OUTDIR, f'stdout-{name}.txt'), 'w') as f:
        f.write(r.stdout)
    with open(os.path.join(OUTDIR, f'stderr-{name}.txt'), 'w') as f:
        f.write(r.stderr)
    lines = [l for l in r.stdout.splitlines() if l.strip()
             and not l.startswith('verify:')]
    family_ok = any(expect_field in l for l in lines) if expect_rc != 0 else True
    rc_ok = (r.returncode != 0) if expect_rc != 0 else (r.returncode == 0)
    first = lines[0] if lines else ''
    shutil.rmtree(td)
    return {'test': name, 'target': desc, 'expect_field': expect_field,
            'expect_rc': expect_rc, 'rc': r.returncode, 'rc_ok': rc_ok,
            'family_ok': family_ok, 'first': first, 'argv': ' '.join(argv),
            'stdout_file': f'stdout-{name}.txt', 'stderr_file': f'stderr-{name}.txt'}


def main():
    rows = []

    # --- R2 finding tampers (retained) ---
    def t_rule(a, m, o):
        c = case(a, 'mysql80-source-drop-column'); st = c['actual']['parsed']['statements'][1]
        old = st['findings'][0]['rule_id']; st['findings'][0]['rule_id'] = 'x.tampered'
        return (f"{c['case_id']}.stmts[1].findings[0].rule_id", old, 'x.tampered')
    rows.append(('R2-finding-rule_id', t_rule, 'findings', 1))

    def t_level(a, m, o):
        c = case(a, 'mysql80-source-drop-column'); st = c['actual']['parsed']['statements'][1]
        old = st['findings'][0]['level']; st['findings'][0]['level'] = 'notice'
        return (f"{c['case_id']}.stmts[1].findings[0].level", old, 'notice')
    rows.append(('R2-finding-level', t_level, 'findings', 1))

    def t_ownidx(a, m, o):
        c = case(a, 'mysql80-source-drop-column')
        f = c['actual']['parsed']['statements'][1]['findings'][0]
        old = f['statement_index']; f['statement_index'] = 0
        return (f"{c['case_id']}.stmts[1].findings[0].statement_index", old, 0)
    rows.append(('R2-finding-stmt_index', t_ownidx, 'findings', 1))

    def t_move(a, m, o):
        c = case(a, 'mysql80-source-drop-column')
        sts = c['actual']['parsed']['statements']
        f = sts[1]['findings'].pop()
        sts[0].setdefault('findings', []).append(f)
        return (f"{c['case_id']} move finding stmt1->stmt0", 'index=1', 'index=0')
    rows.append(('R2-finding-move-stmt', t_move, 'findings', 1))

    def t_loc(a, m, o):
        c = case(a, 'mysql80-source-drop-column')
        f = c['actual']['parsed']['statements'][1]['findings'][0]
        old = dict(f['location']); f['location']['column'] = 999
        return (f"{c['case_id']}.stmts[1].findings[0].location.column", old['column'], 999)
    rows.append(('R2-finding-location', t_loc, 'finding_locations_a', 1))

    # --- R2 process families (retained; real expect_field now) ---
    def t_meta_rc(a, m, o):
        c = next(x for x in a['cases'] if x['kind'] == 'cli_metadata'
                 and x['actual'].get('execute'))
        s = c['actual']['execute'][0]
        old = s['rc']; s['rc'] = 99
        return (f"{c['case_id']}.execute[0].rc", old, 99)
    rows.append(('R2-meta-execute-rc', t_meta_rc, 'expect_rc', 1))

    def t_meta_vo(a, m, o):
        c = next(x for x in a['cases'] if x['kind'] == 'cli_metadata'
                 and x['actual'].get('execute') and x['actual']['execute'][0].get('verify'))
        vv = c['actual']['execute'][0]['verify'][0]
        old = vv.get('output'); vv['output'] = 'ZZZ'
        return (f"{c['case_id']}.execute[0].verify[0].output", old, 'ZZZ')
    rows.append(('R2-meta-verify-output', t_meta_vo, 'verify', 1))

    def t_meta_del(a, m, o):
        c = next(x for x in a['cases'] if x['kind'] == 'cli_metadata'
                 and x['actual'].get('execute'))
        old = len(c['actual']['execute']); c['actual']['execute'].pop()
        return (f"{c['case_id']}.execute len", old, old - 1)
    rows.append(('R2-meta-step-delete', t_meta_del, 'execute', 1))

    def t_unsup_del(a, m, o):
        c = next(x for x in a['cases'] if (x['actual'].get('parsed') or {}).get('unsupported'))
        old = len(c['actual']['parsed']['unsupported']); c['actual']['parsed']['unsupported'] = None
        return (f"{c['case_id']}.parsed.unsupported", old, None)
    rows.append(('R2-unsup-delete', t_unsup_del, 'unsupported', 1))

    def t_unsup_add(a, m, o):
        c = next(x for x in a['cases'] if x['kind'] == 'cli_audit')
        c['actual']['parsed'].setdefault('unsupported', []).append(
            {'feature': 'x', 'sql': 'y', 'reason': 'z', 'metadata': {}})
        return (f"{c['case_id']}.parsed.unsupported", 'len', '+1')
    rows.append(('R2-unsup-add', t_unsup_add, 'unsupported', 1))

    def t_db_verify(a, m, o):
        c = next(x for x in a['cases'] if x['kind'] == 'db_ddl'
                 and x['actual']['steps'][4].get('verify'))
        vv = c['actual']['steps'][4]['verify'][0]
        old = vv.get('output'); vv['output'] = '999'
        return (f"{c['case_id']}.steps[4].verify[0].output", old, '999')
    rows.append(('R2-db-verify', t_db_verify, 'verify', 1))

    def t_neg(a, m, o):
        c = next(x for x in a['cases'] if x['kind'] == 'db_syntax_negative')
        old = c['actual']['error_class']; c['actual']['error_class'] = '9999'
        return (f"{c['case_id']}.error_class", old, '9999')
    rows.append(('R2-neg-class', t_neg, 'error_class', 1))

    def t_req(a, m, o):
        old = list(o.get('required_case_ids') or [])
        o['required_case_ids'] = old[:-1] + ['T18.db.mysql57.nonexistent']
        return ('oracle.required_case_ids', old[-1], 'T18.db.mysql57.nonexistent')
    rows.append(('R2-required-ids', t_req, 'required', 1))

    def t_dup(a, m, o):
        before = len(a['cases'])
        a['cases'].append(copy.deepcopy(a['cases'][0]))
        return ('artifact.cases dup', before, len(a['cases']))
    rows.append(('R2-case-duplicate', t_dup, 'dup', 1))

    def t_status(a, m, o):
        c = a['cases'][0]
        old = c['status']; c['status'] = 'fail'
        return (f"{c['case_id']}.status", old, 'fail')
    rows.append(('R2-status-fail', t_status, 'status', 1))

    def t_assert(a, m, o):
        c = a['cases'][0]
        old = c['assertions'][0]['ok']; c['assertions'][0]['ok'] = False
        return (f"{c['case_id']}.assertions[0].ok", old, False)
    rows.append(('R2-assert-break', t_assert, 'assert', 1))

    def t_ora_expect(a, m, o):
        st = o['ddl_steps'][4]['verify'][0]
        old = st['expect']; st['expect'] = '777'
        return ('oracle.ddl_steps[4].verify[0].expect', old, '777')
    rows.append(('R2-oracle-verify-expect', t_ora_expect, 'verify', 1))

    # --- ER2 multiset semantics tests (R3 new) ---
    def t_perm(a, m, o):
        # add a second DISTINCT finding to stmt1 of mysql80-source-drop-column in
        # artifact+oracle+expected consistently, then permute actual order.
        c = case(a, 'mysql80-source-drop-column')
        st = c['actual']['parsed']['statements'][1]
        f0 = st['findings'][0]
        f2 = copy.deepcopy(f0)
        f2['rule_id'] = 'ddl.table.denylist.forbid.v2'
        ent = {'index': 1, 'rule_id': f2['rule_id'], 'level': f2['level']}
        c['expected'].setdefault('finding_entries', []).append(ent)
        if 'findings' in c['expected']:
            c['expected']['findings'] += 1
        oc = next(x for x in o['metadata_cases'] if x['id'].endswith('mysql80-source-drop-column'))
        oc['expect'].setdefault('finding_entries', []).append(dict(ent))
        if 'findings' in oc['expect']:
            oc['expect']['findings'] += 1
        st['findings'].append(f2)
        st['findings'].reverse()  # permuted order within same statement
        return (f"{c['case_id']} same-stmt permutation + regen matrix", 'order [0,1]', 'order [1,0]')
    rows.append(('R2-pos-permutation', t_perm, None, 0))

    def t_dupf(a, m, o):
        c = case(a, 'mysql80-source-drop-column')
        st = c['actual']['parsed']['statements'][1]
        st['findings'].append(copy.deepcopy(st['findings'][0]))
        return (f"{c['case_id']}.stmts[1].findings dup", 1, 2)
    rows.append(('R2-neg-dup-finding', t_dupf, 'findings', 1))

    def t_missing(a, m, o):
        c = case(a, 'mysql80-source-drop-column')
        old = len(c['actual']['parsed']['statements'][1]['findings'])
        c['actual']['parsed']['statements'][1]['findings'] = []
        return (f"{c['case_id']}.stmts[1].findings delete", old, 0)
    rows.append(('R2-neg-missing-finding', t_missing, 'findings', 1))

    # --- ER2-R2 required additions ---
    def t_locmove(a, m, o):
        # mutate finding location in actual; matrix regenerated in sync ->
        # must STILL be rejected by independent oracle location binding.
        c = next(x for x in a['cases'] if x['expected'].get('finding_locations'))
        f = c['actual']['parsed']['statements'][0]['findings'][-1]
        old = dict(f['location']); f['location']['column'] = old['column'] + 7
        return (f"{c['case_id']}.findings.location synced actual+matrix", old, f['location'])
    rows.append(('R2-neg-location-synced', t_locmove, 'finding_locations', 1, 'regen'))

    def t_ora_idx(a, m, o):
        oc = next(x for x in o['metadata_cases'] if x['expect'].get('statement_indices'))
        old = list(oc['expect']['statement_indices'])
        oc['expect']['statement_indices'] = [9]
        return ('oracle.statement_indices single-field', old, [9])
    rows.append(('R2-neg-oracle-field', t_ora_idx, 'expected.statement_indices', 1))

    def t_gap_facts(a, m, o):
        c = next(x for x in a['cases'] if x['expected'].get('evidence_gap_entries'))
        st = c['actual']['parsed']['statements'][0]
        g = st['evidence_gaps'][0]
        old = list(g['required_facts']); g['required_facts'] = ['tampered.fact']
        return (f"{c['case_id']}.gap.required_facts synced", old, ['tampered.fact'])
    rows.append(('R2-neg-gap-facts', t_gap_facts, 'evidence_gap_entries', 1, 'regen'))

    def t_unsup_meta(a, m, o):
        c = next(x for x in a['cases'] if x['expected'].get('unsupported_entries')
                 and any(u.get('metadata') for u in x['expected']['unsupported_entries']))
        u = c['actual']['parsed']['unsupported'][0]
        old = dict(u.get('metadata') or {}); u['metadata'] = {'aspect': 'tampered'}
        return (f"{c['case_id']}.unsup.metadata synced", old, {'aspect': 'tampered'})
    rows.append(('R2-neg-unsup-metadata', t_unsup_meta, 'unsup', 1, 'regen'))

    def t_stmtsql(a, m, o):
        c = next(x for x in a['cases'] if x['expected'].get('statement_sql'))
        st = c['actual']['parsed']['statements'][0]
        old = st['raw_sql']; st['raw_sql'] = 'DROP VIEW everything;'
        return (f"{c['case_id']}.stmt.raw_sql synced", old, 'DROP VIEW everything;')
    rows.append(('R2-neg-stmt-sql', t_stmtsql, 'stmt_sql', 1, 'regen'))

    def t_meta_tamper(a, m, o):
        c = next(x for x in a['cases'] if x['expected'].get('finding_metadata'))
        ent = c['expected']['finding_metadata'][0]
        st = c['actual']['parsed']['statements'][ent['index']]
        f = next(f for f in st['findings'] if f['rule_id'] == ent['rule_id'])
        old = dict(f['metadata']); f['metadata'] = {'role': 'forged'}
        return (f"{c['case_id']}.finding.metadata synced", old, {'role': 'forged'})
    rows.append(('R2-neg-finding-metadata', t_meta_tamper, 'finding_metadata', 1, 'regen'))

    rows.append(('R2-neg-delete-artifact', lambda a, m, o: ('artifact deleted', 'present', 'absent'), 'required input', 1, 'delete:a'))
    rows.append(('R2-neg-delete-matrix', lambda a, m, o: ('matrix deleted', 'present', 'absent'), 'required input', 1, 'delete:m'))
    rows.append(('R2-neg-delete-oracle', lambda a, m, o: ('oracle deleted', 'present', 'absent'), 'required input', 1, 'delete:o'))
    rows.append(('R2-neg-corrupt-artifact', lambda a, m, o: ('artifact malformed', 'json', '{malformed'), 'required input', 1, 'corrupt:a'))
    rows.append(('R2-neg-corrupt-matrix', lambda a, m, o: ('matrix malformed', 'json', '{malformed'), 'required input', 1, 'corrupt:m'))
    rows.append(('R2-neg-corrupt-oracle', lambda a, m, o: ('oracle malformed', 'json', '{malformed'), 'required input', 1, 'corrupt:o'))

    def t_req_shrink(a, m, o):
        old = len(a.get('required_case_ids') or [])
        a['required_case_ids'] = (a.get('required_case_ids') or [])[:-1]
        return ('artifact.required_case_ids shrink', old, old - 1)
    rows.append(('R2-neg-required-shrink', t_req_shrink, 'required', 1))

    reports = []
    for row in rows:
        name, fn, fam, erc = row[0], row[1], row[2], row[3]
        rep = run_one(name, fn, fam, erc, mode=(row[4] if len(row) > 4 else None))
        reports.append(rep)
        print(f"{rep['test']}\trc={rep['rc']}\trc_ok={rep['rc_ok']}\tfamily_ok={rep['family_ok']}\t{rep['first'][:100]}")

    with open(JSONL, 'w') as f:
        for r in reports:
            f.write(json.dumps(r) + '\n')
    with open(OUT, 'w') as f:
        f.write('test\ttarget(old->new)\texpect_field\texpect_rc\trc\trc_ok\tfamily_ok\tfirst_mismatch\targv\tstdout_file\tstderr_file\n')
        for r in reports:
            f.write(f"{r['test']}\t{r['target']}\t{r['expect_field']}\t{r['expect_rc']}\t{r['rc']}\t{r['rc_ok']}\t{r['family_ok']}\t{r['first']}\t{r['argv']}\t{r['stdout_file']}\t{r['stderr_file']}\n")

    neg = [r for r in reports if r['expect_rc'] != 0]
    pos = [r for r in reports if r['expect_rc'] == 0]
    nz = sum(1 for r in neg if r['rc_ok'])
    famok = sum(1 for r in neg if r['family_ok'])
    poz = sum(1 for r in pos if r['rc_ok'])
    print(f"denominators: expected-nonzero {nz}/{len(neg)}; "
          f"field-family {famok}/{len(neg)}; positive-exit-zero {poz}/{len(pos)}")
    return 0 if (nz == len(neg) and famok == len(neg) and poz == len(pos)) else 1


if __name__ == '__main__':
    sys.exit(main())
