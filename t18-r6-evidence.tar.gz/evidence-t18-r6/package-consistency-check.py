#!/usr/bin/env python3
"""T18-R4 sealed-package consistency check (fail-closed).

Fails rc=1 when any required member is absent, or when manifest.txt /
payload-index.txt exists but fails to list/bind a required member.
Paths resolve relative to this file's directory.

Self-exclusion design (documented, R4): manifest.txt covers ALL members
except itself (payload members + payload-index.txt + this checker).
payload-index.txt covers ALL payload members including this checker —
only manifest.txt and payload-index.txt itself are excluded. Neither
bookkeeping file hashes itself, so no self-referential hash cycle exists;
the checker's own integrity is carried by both lists.
"""
import hashlib, os, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
CASES = ["dual", "unsup", "parseerr", "disabled", "dual2"]
TASKS = ["T08","T09","T10","T11","T12","T13","T14","T15","T16","T17"]
TAMPER = ["pos-key-order","pos-findings-order","neg-owner-move","neg-rule",
          "neg-level","neg-location","neg-verdict","neg-unsup-metadata",
          "neg-diag","neg-stmt-index"]

REQUIRED = [
    "README.md", "manifest.txt", "payload-index.txt", "privacy-scan.txt",
    "reuse-ledger.txt", "package-consistency-check.py",
    "identity/commit.txt", "identity/payload-shas.txt",
    "source/commit-diffstat.txt", "source/commit-files.txt",
    "source/tracked-diff-after-commit.txt", "source/tracked-diff-count.txt",
    "source/frozen-identity.txt", "source/source-contract-map.md",
    "standards/review.txt",
    "inventory/t18-catalog-rows.json", "inventory/inventory.log",
    "golden/artifact.json", "golden/matrix-t18.json", "golden/T18.json",
    "oracle/case-index.txt", "oracle/matrix-v2.json",
    "oracle/reproducibility-proof.txt",
    "oracle/matrix-v3.json", "oracle/gen_oracle_matrix.py",
    "validator/validate_t18_r2.py", "validator/process_selftest_t18_r2.py",
    "validator/process_selftest_r2.jsonl", "validator/process_selftest_r2.tsv",
    "validator/verify-r2.txt", "validator/validate_t18_r3.py",
    "validator/process_selftest_t18_r3.py",
    "validator/process_selftest_r3.jsonl", "validator/process_selftest_r3.tsv",
    "required-members-ledger.txt", "member-isolation-deletion.txt",
    "native/mysql57-probes.txt", "native/mysql80-probes.txt",
    "native/mysql84-probes.txt", "native/tidb85-probes.txt",
    "native/definer-privilege.txt", "native/restrict-cascade.txt",
    "native/tidb85-checkoption-forms.txt", "native/anchor-execution.txt",
    "native/cascade-dependency.txt", "native/definer-grants.txt",
    "source-first/source-first-matrix.jsonl",
    "source-first/source-contract-map.md",
    "performance/perf-samples.json", "performance/perf.py",
    "performance/perf-single.sql", "performance/perf-batch.sql",
    "noleak/noleak-record.txt", "noleak/cli-out.json", "noleak/cli-err.txt",
    "noleak/http-out.json", "noleak/server.log", "noleak/mcp-out.jsonl",
    "noleak/mcp-err.log", "noleak/sdk-out.json", "noleak/sdk-err.log",
    "noleak/server.yaml", "noleak/connections.yaml",
    "parity/compare.py", "parity/binary-shas.txt",
    "parity/case-dual.sql", "parity/case-unsup.sql",
    "parity/case-parseerr.sql", "parity/case-dual2.sql",
    "parity/policy-t18.yaml", "parity/policy-t18-disabled.yaml",
    "parity/tamper/mutate.py", "parity/tamper/gate.txt",
    "parity/tamper/run-t18-controls.sh",
    "parity/tamper/baseline-compare-stdout.txt",
    "parity/tamper/baseline-compare-stderr.txt",
    "gates/corpus.log", "gates/go-vet.log", "gates/inventory.log",
    "gates/make-test.log", "gates/pg-gates.log", "gates/focused-tests.txt",
    "regressions/summary.txt", "performance/golden-run.txt",
]
for c in CASES:
    REQUIRED += [f"parity/cli/out-{c}.json", f"parity/cli/err-{c}.txt",
                 f"parity/sdk/out-{c}.json", f"parity/sdk/err-{c}.txt",
                 f"parity/http/request-body-{c}.json",
                 f"parity/http/response-{c}.json",
                 f"parity/mcp/{c}/structured.json",
                 f"parity/mcp/{c}/sent-call.json",
                 f"parity/mcp/{c}/recv-call.json",
                 f"parity/mcp/{c}/exit.txt"]
REQUIRED += ["parity/sdk/main.go",
             "parity/http/server-default.log",
             "parity/http/server-disabled.log"]
for t in TASKS:
    REQUIRED += [f"regressions/{t}/artifact.json", f"regressions/{t}.log"]
for t in TAMPER:
    REQUIRED += [f"parity/tamper/{t}/compare-stdout.txt",
                 f"parity/tamper/{t}/compare-stderr.txt",
                 f"parity/tamper/{t}/mutate-stderr.txt"]

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

fails = []
present = {}
for base, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d != '__pycache__']
    for fn in files:
        if fn.endswith('.pyc') or fn.startswith('._'):
            fails.append(f"forbidden member: {os.path.join(base, fn)}")
            continue
        rel = os.path.relpath(os.path.join(base, fn), ROOT)
        present[rel] = (os.path.getsize(os.path.join(base, fn)), sha(os.path.join(base, fn)))

missing = [r for r in REQUIRED if r not in present]
if missing:
    fails.append(f"missing required: {missing}")

# Payload Index scope: every member EXCEPT the two bookkeeping files.
# The checker itself IS a payload member — its sha256+size are bound by both
# manifest.txt and payload-index.txt (no self-referential hash cycle, since
# neither file hashes itself).
BOOKKEEP = {"manifest.txt", "payload-index.txt"}
payload = {r for r in present if r not in BOOKKEEP}

if os.path.exists(os.path.join(ROOT, 'payload-index.txt')):
    idx = {}
    for ln in open(os.path.join(ROOT, 'payload-index.txt')):
        ln = ln.strip()
        if not ln:
            continue
        h, s, p = ln.split(None, 2)
        idx[p] = (h, int(s))
    req_in_idx = [r for r in REQUIRED if r not in BOOKKEEP and r not in idx]
    idx_missing = sorted(payload - set(idx))
    idx_extra = sorted(set(idx) - payload)
    idx_bad = [p for p, (h, s) in idx.items() if p in present and (h != present[p][1] or s != present[p][0])]
    if idx_missing or idx_extra or idx_bad or req_in_idx:
        fails.append(f"index drift missing={idx_missing[:5]} extra={idx_extra[:5]} bad={idx_bad[:5]} req_not_in_idx={req_in_idx[:5]}")

if os.path.exists(os.path.join(ROOT, 'manifest.txt')):
    man = {}
    for ln in open(os.path.join(ROOT, 'manifest.txt')):
        ln = ln.strip()
        if not ln:
            continue
        h, s, p = ln.split(None, 2)
        man[p] = (h, int(s))
    man_scope = set(present) - {"manifest.txt"}
    man_missing = sorted(man_scope - set(man))
    man_extra = sorted(set(man) - man_scope)
    man_bad = [p for p, (h, s) in man.items() if p in present and (h != present[p][1] or s != present[p][0])]
    req_in_man = [r for r in REQUIRED if r != "manifest.txt" and r not in man]
    if man_missing or man_extra or man_bad or req_in_man:
        fails.append(f"manifest drift missing={man_missing[:5]} extra={man_extra[:5]} bad={man_bad[:5]} req_not_in_man={req_in_man[:5]}")

print(f"required: {len(REQUIRED)} present; members: {len(present)}; failures: {len(fails)}")
for f in fails:
    print("FAIL", f)
sys.exit(1 if fails else 0)
