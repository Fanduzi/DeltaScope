import json, subprocess, time, statistics, hashlib, platform, os
CLI="/tmp/t18-parity/bin/deltascope"
WARM=15; N=60
def run(sqlfile):
    t0=time.perf_counter_ns()
    p=subprocess.run([CLI,"audit","--file",sqlfile,"--dialect","mysql","--format","json"],capture_output=True)
    return (time.perf_counter_ns()-t0)/1e6, p.returncode
def bench(sqlfile,label):
    for _ in range(WARM): run(sqlfile)
    xs=[]
    for _ in range(N):
        ms,rc=run(sqlfile); xs.append(round(ms,3)); assert rc in (0,1), (label,rc)
    xs2=sorted(xs)
    return {"label":label,"file":sqlfile,"warmup":WARM,"n":N,
      "min_ms":xs2[0],"p50_ms":xs2[len(xs2)//2],
      "p95_ms":xs2[int(len(xs2)*0.95)],"max_ms":xs2[-1],
      "mean_ms":round(statistics.mean(xs),3),"stdev_ms":round(statistics.stdev(xs),3),
      "samples_ms":xs}
out={"task":"T18-R2 perf samples","head":"48e6de5135d551be4fb986ba9139a652c7b562b4",
 "binary_sha256":hashlib.sha256(open(CLI,'rb').read()).hexdigest(),
 "binary":CLI,"argv":"audit --file <sql> --dialect mysql --format json (default policy)",
 "env":{"host":platform.node(),"platform":platform.platform(),"python":platform.python_version()},
 "method":"subprocess wall-clock ms; warmup then N reps; per-rep samples raw","runs":[]}
for f,l in (("/tmp/t18-r2/perf-single.sql","single-view-security"),("/tmp/t18-r2/perf-batch.sql","batch-11stmts-lifecycle")):
    out["runs"].append(bench(f,l))
print(json.dumps(out,indent=1))
open("/tmp/t18-r2/performance/perf-samples.json","w").write(json.dumps(out,indent=1))
