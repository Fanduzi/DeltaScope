# T18 R6 Evidence Package — 视图生命周期与安全属性

Round: T18-R6-STDOUT-PARSED-SEMANTIC-BINDING-CORRECTION-01
Product HEAD: 48e6de5135d551be4fb986ba9139a652c7b562b4 (unchanged since R1; R6 adds evidence/tooling only, zero product commits)
Parent: 36e616f8a75246cb56e7872823720c109f20b3a6
Prior archives: R1 52c8f685… / R2 ef8dc886… / R3 0afc1a24… / R4 f9068c45… / R5 6e038a0e… (delivered; preserved, none re-executed)

## R5-blocker closeout map
- ER1 (complete stdout↔parsed semantic binding, ownership-preserving):
  diagnostics_contract now binds EVERY structured-parsed CLI case —
  stdout must be a valid JSON OBJECT; top-level key SETS identical;
  every shared non-'statements' field compared (lists as exact serialized
  multisets, scalars/dicts deep-equal); per-statement (index,raw_sql)
  identity + per-statement key-set parity + per-field equality with the
  same multiset rule. findings/evidence_gaps/diagnostics are compared
  PER OWNING STATEMENT — never flattened across statements (the R5
  implementation flattened gap/diag pools; the generic per-statement
  binding replaces it). Verified on all 142 dual-serialized cases:
  zero serialization differences, so deep equality is the binding.
  Non-semantic differences explicitly registered: JSON object key order
  (dict comparison), same-statement findings order (multiset).
- ER2 (process-level controls, work-order N1–N9 + P1/P2):
  N1 stdout-only finding delete (T18.cli.target-source-unvouched-current —
  reviewer miss reproduced); N2 finding multiplicity (dup append); N3
  rule_id/level; N4 location/suggestion; N5 cross-statement finding move
  (T18.meta.mysql80-alter-dependencies — reviewer miss reproduced);
  N6 statement coverage (T18.cli.mysql-plain-all-off — reviewer miss
  reproduced); N7 summary counts; N8 statement kind identity; N9a
  unsupported ownership (sql field); N9b gap cross-statement relocation —
  DERIVED probe (sealed corpus has no multi-statement gap case, verified;
  stmt[1] appended in stdout only — not a Golden case). Plus stdout-only
  field-delete/key-add and parsed-side mutations. Every control:
  baseline rc=0 → single recorded mutation → rc=1 with family-attributed
  mismatch, no traceback. P1 findings order reversal rc=0; P2 JSON key
  order reversal rc=0. Selftest: 78/78 negatives + 3/3 positives.
  argv/rc/stdout/stderr/input-SHA sealed in process_selftest_r3.{jsonl,tsv}
  + selftest-r3/.
- ER3 (historical count errata): reviewer-received R3 archive =
  SHA 0afc1a24 / 11,890,281 B / 1,419 entries. Worker's local record
  (11,910,958 B / 1,421 entries) is a HISTORICAL UNVERIFIED record —
  it is NOT bound to that SHA (no other file's SHA was obtained).
  R3 original archive itself is unchanged.
- ER4: R5-passed evidence preserved byte-identical (B2 isolation control
  transcript + 374 records, TiDB supplement, Golden, regressions, parity,
  gates, performance, noleak) — not re-executed, not relabeled.
- ER5: fresh t18-r6-evidence.tar.gz sealed with same hash-binding design.

## Prior-round closeout map (preserved, R5 work order)
- B1 (stdout↔parsed output consistency, bidirectional fail-closed):
  validate_t18_r3.py diagnostics_contract now runs unconditionally whenever
  parsed output is a structured dict — stdout must be a valid JSON OBJECT;
  verdict/coverage compared; statement (index, raw_sql) identity compared;
  diagnostics/evidence_gaps/unsupported flattened and compared as exact
  serialized multisets in BOTH directions. Empty stdout-side collections can
  no longer bypass (previously skipped when parsed side was empty).
  New negative controls (all baseline-rc0 -> single mutation -> rc=1, family
  attributed): invalid-JSON stdout on diagnostic case; invalid-JSON stdout on
  clean/pass case; {} stdout on clean/pass; delete diagnostics collection
  from stdout; delete evidence_gaps collection; delete unsupported
  collection; delete single diagnostic entry; synced parsed+stdout field
  mutation for gap/unsup/diag. Selftest at R5 delivery: 63/63 negatives +
  2/2 positives (findings-order reversal accepted rc=0, multiset semantics).
- B2 (strict member-isolation deletion control):
  member-isolation-deletion.txt = v2 transcript — per-member FRESH tempdir
  copy of the FINAL tree -> baseline checker rc=0 -> member physically moved
  OUT of the checked tree (external temp stash, no rename/stash residue) ->
  same checker rc=1 naming exactly that member -> delta_missing=={member}
  and delta_extra==[] proven by tree snapshots -> FULL stdout+stderr per
  member under validator/isolation-records/ (374 files) -> checker SHA
  f10632c8… recorded per line. 186 semantic rc=1 cases; checker
  self-deletion = structural rc=2 documented separately (excluded from the
  semantic denominator). Records were written OUTSIDE the checked tree
  during execution and merged in only after completion (fixes R4's
  in-tree record pollution that dirtied baselines).
- B3 (bookkeeping errata): R3 archive SHA corrected to
  0afc1a24536f6093e098cfc89cbe63b49f53087a8bc50e9da8de77ee4c04d324;
  manifest/index line counts are no longer hardcoded here — exact counts
  are measured against the sealed archive in the round receipt; the
  "transport re-encoding" claim was removed. See ER3 above for the final
  wording on R3 byte/entry counts (reviewer-received 11,890,281/1,419 is
  bound to that SHA; worker's 11,910,958/1,421 is an unverified record).

## Prior-round closeout map (preserved, R4 work order)
- B1/H1 (TiDB CHECK OPTION four forms, original execution binding):
  native/tidb85-checkoption-forms.txt — complete probe: image digest
  pingcap/tidb@sha256:490861bd…, client argv, SELECT VERSION()=8.0.11-TiDB-v8.5.0,
  setup SQL, per-form full SQL + rc + stderr, pre/post INFORMATION_SCHEMA.VIEWS
  (CHECK_OPTION=LOCAL/CASCADED, IS_UPDATABLE=NO, SECURITY_TYPE=DEFINER),
  INSERT proofs (violating AND conforming rows → ERROR 1105; TiDB views
  non-updatable → declaration-compatible, not executable), teardown.
  native/tidb85-checkoption-forms-supplement.txt (R5): raw setup/teardown
  SQL + conforming INSERT exact SQL + residual checks (empty-set proof).
- B2/H2 (validator independence + fail-closed):
  * C1 matrix reproducibility: oracle/gen_oracle_matrix.py now copies the oracle
    `expect` block verbatim (no field whitelist) + reads syntax_negative.expect;
    oracle/reproducibility-proof.txt records byte-identical regen vs sealed
    matrix-v3.json (generator SHA e41f37d9…, output SHA afd900a4…, argv/rc).
  * C2 independent bindings: declared evidence_gap_entries field-level multiset
    (index/rule_id/reason_code/required_facts); unsupported_entries field-level
    (index↔statements[i].raw_sql + feature/reason/metadata + count equality);
    finding.statement_index == enclosing statement index; declared statements/
    findings counts; declared version fields; diagnostics declared count +
    source-enum classification + audited=false + dialect==oracle + same-class
    (reason,action_hint) template consistency.
  * C3 fail-closed: assertions逐条 ok=true; duplicate case_id rejected even
    after executed_count sync; artifact.required_case_ids list==oracle list;
    stdout unparseable while parsed carries content → rc=1 (no silent pass).
  * selftest at R4 delivery: 57/57 negatives + 2/2 positives incl. 9 new C3 controls —
    assertion-ok flip, duplicate case id (count-synced), statement_index
    tamper, gap/unsup/diag synced parsed+stdout dual-write, stdout invalid
    JSON, expected-field deletion, zero-finding injection; positive control:
    same-statement findings order reversal → rc=0 (multiset semantics).
- B3/H3 (seal integrity):
  * payload-index.txt now includes package-consistency-check.py — checker
    sha+size bound by BOTH manifest and index; manifest covers all except
    itself; no file hashes itself (no cycle).
  * required-members-ledger.txt recomputed from each SEALED checker source:
    R1=147 / R2=47 / R3=186 / R4=187 with per-member keep/replace/demote/add.
  * member-isolation-deletion.txt = v2 true-isolation transcript: per-member
    FRESH tempdir copy -> baseline rc=0 -> member REMOVED from tree (no stash
    residue) -> rc=1 naming the member; FULL stdout/stderr per member under
    validator/isolation-records/; checker self-deletion = structural rc=2
    (documented, excluded from semantic denominator).
- H4 kept REUSED (R3 scoped pass): cascade-dependency + definer-grants.

## Layout
golden/     artifact.json + T18.json oracle + matrix-t18.json (R1 derived, historical)
oracle/     matrix-v3.json (oracle-derived, byte-reproducible) + gen_oracle_matrix.py +
            reproducibility-proof.txt + matrix-v2.json (R2 projection, labeled) + case-index
validator/  validate_t18_r3.py + process_selftest_t18_r3.py + selftest-r3/ + R2 files (historical)
parity/     five-case four-surface IDENTICAL + tamper controls (REUSED @48e6de51)
native/     per-version probes + checkoption-forms (+R5 supplement) + cascade-dependency +
            definer-grants + restrict-cascade + definer-privilege + anchor-execution
gates/      unit/vet/corpus/inventory/decision gates (REUSED @48e6de51)
regressions/ T08–T17 serial chain 10/10 (REUSED @48e6de51)
source/     frozen identity + commit scope + source-contract-map.md
source-first/ 13-col matrix (31 rows, TiDB CHECK OPTION corrected per-form) + contract-map
performance/ R2 samples n=60 (REUSED byte-identical) + golden-run.txt (R1, REUSED)
noleak/     ER5 four-surface scans 0 hits + vacuity guard (REUSED byte-identical)
identity/   commit + payload shas
manifest.txt / payload-index.txt / package-consistency-check.py / privacy-scan.txt /
reuse-ledger.txt / required-members-ledger.txt / member-isolation-deletion.txt

## Self-exclusion design (documented, R5)
manifest.txt covers ALL members except itself.
payload-index.txt covers ALL payload members including the checker — only
manifest.txt and payload-index.txt itself are excluded.
Neither bookkeeping file hashes itself → no self-referential cycle; checker
integrity is carried by both lists. Exact line counts are stated in the
round receipt and post-seal transcript, measured against the final archive.
