#!/usr/bin/env python3
"""Generate the independent expected matrix from T18.json oracle declarations.

Source of truth: oracle `expect`/`ddl_steps`/`syntax_negative` blocks ONLY.
artifact.actual is never read — this is what makes the matrix an independent
expectation rather than an actual-derived projection.
"""
import json, sys

def oracle_case_map(oracle):
    m = {}
    for c in oracle.get('cli_cases') or []:
        m['T18.cli.' + c['id']] = ('cli_audit', c)
    for c in oracle.get('metadata_cases') or []:
        m['T18.meta.' + c['id']] = ('cli_metadata', c)
    for anchor in (oracle.get('anchors') or {}):
        m[f'T18.db.{anchor}.ddl'] = ('db_ddl',
                                     {'steps': oracle.get('ddl_steps') or [],
                                      'anchor': anchor})
        m[f'T18.db.{anchor}.syntax_negative'] = ('db_syntax_negative',
                                                 dict(oracle.get('syntax_negative') or {},
                                                      anchor=anchor))
    return m

def steps_e(steps):
    return [{'name': s.get('name'),
             'expect_rc': s.get('expect_rc'),
             'sql': s.get('sql'),
             'verify': [{'assert': v.get('assert'), 'expect': v.get('expect'),
                         'sql': v.get('sql')}
                        for v in s.get('verify') or []]}
            for s in steps or []]

def main(oracle_path, out_path):
    oracle = json.load(open(oracle_path))
    omap = oracle_case_map(oracle)
    matrix = []
    for cid in sorted(omap):
        kind, oc = omap[cid]
        e = oc.get('expect') or {}
        row = {'case_id': cid, 'kind': kind}
        if 'anchor' in oc:
            row['anchor'] = oc['anchor']
        if 'sql' in oc:
            row['input_sql'] = oc['sql']
        if oc.get('args'):
            row['args'] = oc['args']
        if oc.get('dialect'):
            row['dialect'] = oc['dialect']
        if kind == 'db_ddl':
            row['steps'] = steps_e(oc.get('steps'))
        elif kind == 'db_syntax_negative':
            se = oc.get('expect') or {}
            for f in ('error_class', 'rc_nonzero', 'forbidden_markers'):
                if f in oc:
                    row[f] = oc[f]
                elif f in se:
                    row[f] = se[f]
        else:
            # Copy the oracle `expect` block VERBATIM — every declared field is
            # an independent expectation. A field whitelist would silently drop
            # declarations added later (R3 review caught exactly that drift).
            exp = dict(e)
            if kind == 'cli_metadata':
                for ph in ('setup', 'structure', 'execute', 'post_verify', 'teardown'):
                    if ph in oc:
                        exp[ph] = steps_e(oc[ph])
            row['expected'] = exp
        matrix.append(row)
    json.dump(matrix, open(out_path, 'w'), indent=1, sort_keys=True)
    print(f"oracle-derived matrix: {len(matrix)} cases -> {out_path}")

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
