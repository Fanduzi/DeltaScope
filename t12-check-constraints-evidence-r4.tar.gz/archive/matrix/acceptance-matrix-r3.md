# T12 R3 acceptance matrix (expected=oracle T12.json blob 3449107b, actual=artifact-r2.json)

case_id|kind|anchor|dialect|version|mode|schema|meta_src|policy|input_sql|exp_verdict|exp_cov|exp_find|exp_gaps|exp_exit|act_verdict|act_cov|act_find|act_gaps|act_exit|assert|status|raw
T12.db.mysql57.ddl|db_ddl|mysql57|mysql|5.7.44|native-steps|golden|live-db|N/A|CREATE TABLE t12g (id INT, v INT, CONSTRAINT chk_id CHECK (id > 0), CONSTRAINT chk_v CHECK (v > 0)) ;; ALTER TABLE t12g ADD COLUMN w INT ;; INSERT INTO t12g VALUES (1, 1, 1) ;; DROP TABLE t12g|N/A|N/A|N/A|N/A|N/A|step-log|step-log|N/A|N/A|N/A|12|True|golden/artifact-r2.json#cases/T12.db.mysql57.ddl
T12.db.mysql57.syntax_negative|db_syntax_negative|mysql57|N/A|N/A|native-steps|golden|live-db|N/A|ALTER TABLE golden_t ALTER CHECK x (|N/A|N/A|N/A|N/A|N/A|step-log|step-log|N/A|N/A|N/A|3|True|golden/artifact-r2.json#cases/T12.db.mysql57.syntax_negative
T12.db.mysql80.ddl|db_ddl|mysql80|mysql|8.0.46|native-steps|golden|live-db|N/A|CREATE TABLE t12g (id INT, v INT, CONSTRAINT chk_id CHECK (id > 0), CONSTRAINT chk_v CHECK (v > 0)) ;; ALTER TABLE t12g ADD COLUMN w INT ;; INSERT INTO t12g VALUES (1, 1, 1) ;; DROP TABLE t12g|N/A|N/A|N/A|N/A|N/A|step-log|step-log|N/A|N/A|N/A|12|True|golden/artifact-r2.json#cases/T12.db.mysql80.ddl
T12.db.mysql80.syntax_negative|db_syntax_negative|mysql80|N/A|N/A|native-steps|golden|live-db|N/A|ALTER TABLE golden_t ALTER CHECK x (|N/A|N/A|N/A|N/A|N/A|step-log|step-log|N/A|N/A|N/A|3|True|golden/artifact-r2.json#cases/T12.db.mysql80.syntax_negative
T12.db.mysql84.ddl|db_ddl|mysql84|mysql|8.4.10|native-steps|golden|live-db|N/A|CREATE TABLE t12g (id INT, v INT, CONSTRAINT chk_id CHECK (id > 0), CONSTRAINT chk_v CHECK (v > 0)) ;; ALTER TABLE t12g ADD COLUMN w INT ;; INSERT INTO t12g VALUES (1, 1, 1) ;; DROP TABLE t12g|N/A|N/A|N/A|N/A|N/A|step-log|step-log|N/A|N/A|N/A|12|True|golden/artifact-r2.json#cases/T12.db.mysql84.ddl
T12.db.mysql84.syntax_negative|db_syntax_negative|mysql84|N/A|N/A|native-steps|golden|live-db|N/A|ALTER TABLE golden_t ALTER CHECK x (|N/A|N/A|N/A|N/A|N/A|step-log|step-log|N/A|N/A|N/A|3|True|golden/artifact-r2.json#cases/T12.db.mysql84.syntax_negative
T12.db.tidb85.ddl|db_ddl|tidb85|tidb|8.0.11-TiDB-v8.5.0|native-steps|golden|live-db|N/A|CREATE TABLE t12g (id INT, v INT, CONSTRAINT chk_id CHECK (id > 0), CONSTRAINT chk_v CHECK (v > 0)) ;; ALTER TABLE t12g ADD COLUMN w INT ;; INSERT INTO t12g VALUES (1, 1, 1) ;; DROP TABLE t12g|N/A|N/A|N/A|N/A|N/A|step-log|step-log|N/A|N/A|N/A|13|True|golden/artifact-r2.json#cases/T12.db.tidb85.ddl
T12.db.tidb85.syntax_negative|db_syntax_negative|tidb85|N/A|N/A|native-steps|golden|live-db|N/A|ALTER TABLE golden_t ALTER CHECK x (|N/A|N/A|N/A|N/A|N/A|step-log|step-log|N/A|N/A|N/A|3|True|golden/artifact-r2.json#cases/T12.db.tidb85.syntax_negative
T12.cli.t12-cli-alter-check-offline-gap|cli_audit|offline|mysql|N/A|offline|N/A|N/A|t12-all|ALTER TABLE t ALTER CHECK chk_id NOT ENFORCED;|review|unverified|0|[["ddl.constraint.check.not_enforced.notice","missing_target_version"],["ddl.alter.alter_check.exists.require","missing_target_version"],["ddl.alter.alter_check.version.require","missing_target_version"]]|0|review|unverified|[]|[["ddl.constraint.check.not_enforced.notice","missing_target_version"],["ddl.alter.alter_check.exists.require","missing_target_version"],["ddl.alter.alter_check.version.require","missing_target_version"]]|0|15|True|golden/artifact-r2.json#cases/T12.cli.t12-cli-alter-check-offline-gap
T12.cli.t12-cli-alter-check-enforced-offline|cli_audit|offline|mysql|N/A|offline|N/A|N/A|t12-all|ALTER TABLE t ALTER CHECK chk_id ENFORCED;|review|unverified|0|[["ddl.alter.alter_check.exists.require","missing_target_version"],["ddl.alter.alter_check.version.require","missing_target_version"]]|0|review|unverified|[]|[["ddl.alter.alter_check.exists.require","missing_target_version"],["ddl.alter.alter_check.version.require","missing_target_version"]]|0|12|True|golden/artifact-r2.json#cases/T12.cli.t12-cli-alter-check-enforced-offline
T12.cli.t12-cli-drop-check-offline-gap|cli_audit|offline|mysql|N/A|offline|N/A|N/A|t12-all|ALTER TABLE t DROP CHECK chk_id;|review|unverified|0|[["ddl.alter.drop_check.exists.require","missing_target_version"],["ddl.alter.alter_check.version.require","missing_target_version"]]|0|review|unverified|[]|[["ddl.alter.drop_check.exists.require","missing_target_version"],["ddl.alter.alter_check.version.require","missing_target_version"]]|0|12|True|golden/artifact-r2.json#cases/T12.cli.t12-cli-drop-check-offline-gap
T12.cli.t12-cli-alter-constraint-alias-offline|cli_audit|offline|mysql|N/A|offline|N/A|N/A|t12-all|ALTER TABLE t ALTER CONSTRAINT chk_id NOT ENFORCED;|review|unverified|0|3|0|review|unverified|[]|[["ddl.constraint.check.not_enforced.notice","missing_target_version"],["ddl.alter.alter_check.exists.require","missing_target_version"],["ddl.alter.alter_check.version.require","missing_target_version"]]|0|8|True|golden/artifact-r2.json#cases/T12.cli.t12-cli-alter-constraint-alias-offline
T12.cli.t12-cli-alter-check-tidb-offline-gap|cli_audit|offline|tidb|N/A|offline|N/A|N/A|t12-all|ALTER TABLE t ALTER CHECK chk_id NOT ENFORCED;|review|unverified|0|[["ddl.constraint.check.not_enforced.notice","missing_instance_fact"],["ddl.alter.alter_check.exists.require","missing_instance_fact"]]|0|review|unverified|[]|[["ddl.constraint.check.not_enforced.notice","missing_instance_fact"],["ddl.alter.alter_check.exists.require","missing_instance_fact"]]|0|12|True|golden/artifact-r2.json#cases/T12.cli.t12-cli-alter-check-tidb-offline-gap
T12.cli.t12-cli-create-notenforced-offline-gap|cli_audit|offline|mysql|N/A|offline|N/A|N/A|t12-all|CREATE TABLE t (id INT, CONSTRAINT chk_a CHECK (id > 0) NOT ENFORCED);|review|unverified|0|[["ddl.alter.alter_check.version.require","missing_target_version"],["ddl.constraint.check.not_enforced.notice","missing_target_version"],["ddl.constraint.check.ignored.notice","missing_target_version"]]|0|review|unverified|[]|[["ddl.constraint.check.not_enforced.notice","missing_target_version"],["ddl.constraint.check.ignored.notice","missing_target_version"],["ddl.alter.alter_check.version.require","missing_target_version"]]|0|13|True|golden/artifact-r2.json#cases/T12.cli.t12-cli-create-notenforced-offline-gap
T12.cli.t12-cli-add-check-declared-offline-gap|cli_audit|offline|mysql|N/A|offline|N/A|N/A|t12-all|ALTER TABLE t ADD CONSTRAINT chk2 CHECK (id < 100) NOT ENFORCED;|review|unverified|0|[["ddl.alter.alter_check.version.require","missing_target_version"],["ddl.constraint.check.not_enforced.notice","missing_target_version"],["ddl.constraint.check.ignored.notice","missing_target_version"]]|0|review|unverified|[]|[["ddl.constraint.check.not_enforced.notice","missing_target_version"],["ddl.constraint.check.ignored.notice","missing_target_version"],["ddl.alter.alter_check.version.require","missing_target_version"]]|0|13|True|golden/artifact-r2.json#cases/T12.cli.t12-cli-add-check-declared-offline-gap
T12.cli.t12-cli-addcol-control|cli_audit|offline|mysql|N/A|offline|N/A|N/A|t12-all|ALTER TABLE t ADD COLUMN w INT;|pass|complete|0|N/A|0|pass|complete|[]|[]|0|7|True|golden/artifact-r2.json#cases/T12.cli.t12-cli-addcol-control
T12.cli.t12-cli-alter-check-off|cli_audit|offline|mysql|N/A|offline|N/A|N/A|all-rules-disabled|ALTER TABLE t ALTER CHECK chk_id NOT ENFORCED;|pass|complete|0|N/A|0|pass|complete|[]|[]|0|7|True|golden/artifact-r2.json#cases/T12.cli.t12-cli-alter-check-off
T12.meta.t12-mysql80-golden|cli_metadata|mysql80|mysql|8.0.46|metadata-aware|golden|N/A|t12-all|ALTER TABLE t12g ALTER CHECK chk_id NOT ENFORCED;|reject|complete|[[0,"ddl.constraint.check.not_enforced.notice","blocker"]]|0|1|reject|complete|[["ddl.constraint.check.not_enforced.notice","blocker"]]|[]|1|19|True|golden/artifact-r2.json#cases/T12.meta.t12-mysql80-golden
T12.meta.t12-mysql84-golden|cli_metadata|mysql84|mysql|8.4.10|metadata-aware|golden|N/A|t12-all|ALTER TABLE t12g ALTER CONSTRAINT chk_id NOT ENFORCED;|reject|complete|[[0,"ddl.constraint.check.not_enforced.notice","blocker"]]|0|1|reject|complete|[["ddl.constraint.check.not_enforced.notice","blocker"]]|[]|1|16|True|golden/artifact-r2.json#cases/T12.meta.t12-mysql84-golden
T12.meta.t12-mysql80-alter-missing|cli_metadata|mysql80|mysql|8.0.46|metadata-aware|golden|N/A|t12-all|ALTER TABLE t12g ALTER CHECK missing_x NOT ENFORCED;|reject|complete|[[0,"ddl.alter.alter_check.exists.require","blocker"]]|0|1|reject|complete|[["ddl.alter.alter_check.exists.require","blocker"]]|[]|1|15|True|golden/artifact-r2.json#cases/T12.meta.t12-mysql80-alter-missing
T12.meta.t12-mysql80-drop-present|cli_metadata|mysql80|mysql|8.0.46|metadata-aware|golden|N/A|t12-all|ALTER TABLE t12g DROP CHECK chk_id;|pass|complete|0|0|0|pass|complete|[]|[]|0|13|True|golden/artifact-r2.json#cases/T12.meta.t12-mysql80-drop-present
T12.meta.t12-mysql57-ignored|cli_metadata|mysql57|mysql|5.7.44|metadata-aware|golden|N/A|t12-all|CREATE TABLE t57 (id INT, CONSTRAINT chk_ign CHECK (id > 0));|review|complete|[[0,"ddl.constraint.check.ignored.notice","warning"]]|0|0|review|complete|[["ddl.constraint.check.ignored.notice","warning"]]|[]|0|16|True|golden/artifact-r2.json#cases/T12.meta.t12-mysql57-ignored
T12.meta.t12-mysql57-version-refusal|cli_metadata|mysql57|mysql|5.7.44|metadata-aware|golden|N/A|t12-all|ALTER TABLE t57 ALTER CHECK x NOT ENFORCED;|reject|complete|[[0,"ddl.alter.alter_check.version.require","blocker"]]|0|1|reject|complete|[["ddl.alter.alter_check.version.require","blocker"]]|[]|1|14|True|golden/artifact-r2.json#cases/T12.meta.t12-mysql57-version-refusal
T12.meta.t12-tidb85-golden|cli_metadata|tidb85|tidb|8.5.0|metadata-aware|golden|N/A|t12-all|ALTER TABLE t12g ALTER CHECK chk_id NOT ENFORCED;|reject|complete|[[0,"ddl.constraint.check.not_enforced.notice","blocker"]]|0|1|reject|complete|[["ddl.constraint.check.not_enforced.notice","blocker"]]|[]|1|21|True|golden/artifact-r2.json#cases/T12.meta.t12-tidb85-golden
T12.meta.t12-tidb85-flag-off-ignored|cli_metadata|tidb85|tidb|8.5.0|metadata-aware|golden|N/A|t12-all|CREATE TABLE t_off (id INT, CONSTRAINT chk_ign CHECK (id > 0));|review|complete|[[0,"ddl.constraint.check.ignored.notice","warning"]]|0|0|review|complete|[["ddl.constraint.check.ignored.notice","warning"]]|[]|0|20|True|golden/artifact-r2.json#cases/T12.meta.t12-tidb85-flag-off-ignored

## db-step details

{
 "T12.db.mysql57.ddl": [
  [
   "database reachable with expected version",
   true,
   "SELECT VERSION() rc=0 version='5.7.44' expected_contains='5.7.44'"
  ],
  [
   "create-check-table return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "create-check-table: fixture table lands on every anchor arm",
   true,
   "rc=0 output='1' expected='1'"
  ],
  [
   "add-plain-column return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "add-plain-column: column lands",
   true,
   "rc=0 output='3' expected='3'"
  ],
  [
   "insert-clean-row return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "insert-clean-row: clean row lands under every arm",
   true,
   "rc=0 output='1' expected='1'"
  ],
  [
   "drop-fixture return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "drop-fixture: fixture dropped",
   true,
   "rc=0 output='0' expected='0'"
  ],
  [
   "image digest matches locked baseline",
   true,
   "locked='mysql@sha256:4bc6bc963e6d8443453676cae56536f4b8156d78bae03c0145cbe47c2aad73bb' resolved=['mysql@sha256:4bc6bc963e6d8443453676cae56536f4b8156d7"
  ],
  [
   "running container image identity",
   true,
   "container='sha256:4bc6bc963e6d8443453676cae56536f4b8156d78bae03c0145cbe47c2aad73bb' image_id='sha256:4bc6bc963e6d8443453676cae56536f4b8156d78bae03c014"
  ],
  [
   "platform recorded and matches baseline",
   true,
   "platform='linux/amd64' locked='linux/amd64'"
  ]
 ],
 "T12.db.mysql57.syntax_negative": [
  [
   "nonzero syntax failure",
   true,
   "rc=1"
  ],
  [
   "expected error class",
   true,
   "error_class='1064' expected='1064'"
  ],
  [
   "no permission/connection/object-conflict markers",
   true,
   "forbidden markers found: []"
  ]
 ],
 "T12.db.mysql80.ddl": [
  [
   "database reachable with expected version",
   true,
   "SELECT VERSION() rc=0 version='8.0.46' expected_contains='8.0.46'"
  ],
  [
   "create-check-table return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "create-check-table: fixture table lands on every anchor arm",
   true,
   "rc=0 output='1' expected='1'"
  ],
  [
   "add-plain-column return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "add-plain-column: column lands",
   true,
   "rc=0 output='3' expected='3'"
  ],
  [
   "insert-clean-row return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "insert-clean-row: clean row lands under every arm",
   true,
   "rc=0 output='1' expected='1'"
  ],
  [
   "drop-fixture return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "drop-fixture: fixture dropped",
   true,
   "rc=0 output='0' expected='0'"
  ],
  [
   "image digest matches locked baseline",
   true,
   "locked='mysql@sha256:7dcddc01f13bab2f15cde676d44d01f61fc9f99fe7785e86196dfc07d358ae2b' resolved=['mysql@sha256:7dcddc01f13bab2f15cde676d44d01f61fc9f99"
  ],
  [
   "running container image identity",
   true,
   "container='sha256:7dcddc01f13bab2f15cde676d44d01f61fc9f99fe7785e86196dfc07d358ae2b' image_id='sha256:7dcddc01f13bab2f15cde676d44d01f61fc9f99fe7785e861"
  ],
  [
   "platform recorded and matches baseline",
   true,
   "platform='linux/arm64' locked='linux/arm64'"
  ]
 ],
 "T12.db.mysql80.syntax_negative": [
  [
   "nonzero syntax failure",
   true,
   "rc=1"
  ],
  [
   "expected error class",
   true,
   "error_class='1064' expected='1064'"
  ],
  [
   "no permission/connection/object-conflict markers",
   true,
   "forbidden markers found: []"
  ]
 ],
 "T12.db.mysql84.ddl": [
  [
   "database reachable with expected version",
   true,
   "SELECT VERSION() rc=0 version='8.4.10' expected_contains='8.4.10'"
  ],
  [
   "create-check-table return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "create-check-table: fixture table lands on every anchor arm",
   true,
   "rc=0 output='1' expected='1'"
  ],
  [
   "add-plain-column return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "add-plain-column: column lands",
   true,
   "rc=0 output='3' expected='3'"
  ],
  [
   "insert-clean-row return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "insert-clean-row: clean row lands under every arm",
   true,
   "rc=0 output='1' expected='1'"
  ],
  [
   "drop-fixture return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "drop-fixture: fixture dropped",
   true,
   "rc=0 output='0' expected='0'"
  ],
  [
   "image digest matches locked baseline",
   true,
   "locked='mysql@sha256:8dbcf531a03aade657e181b9cf2f1d1803ce621a1d55610cb44cb531ab7d7db6' resolved=['mysql@sha256:8dbcf531a03aade657e181b9cf2f1d1803ce621"
  ],
  [
   "running container image identity",
   true,
   "container='sha256:8dbcf531a03aade657e181b9cf2f1d1803ce621a1d55610cb44cb531ab7d7db6' image_id='sha256:8dbcf531a03aade657e181b9cf2f1d1803ce621a1d55610cb"
  ],
  [
   "platform recorded and matches baseline",
   true,
   "platform='linux/arm64' locked='linux/arm64'"
  ]
 ],
 "T12.db.mysql84.syntax_negative": [
  [
   "nonzero syntax failure",
   true,
   "rc=1"
  ],
  [
   "expected error class",
   true,
   "error_class='1064' expected='1064'"
  ],
  [
   "no permission/connection/object-conflict markers",
   true,
   "forbidden markers found: []"
  ]
 ],
 "T12.db.tidb85.ddl": [
  [
   "database reachable with expected version",
   true,
   "SELECT VERSION() rc=0 version='8.0.11-TiDB-v8.5.0' expected_contains='v8.5.0'"
  ],
  [
   "fixture database created",
   true,
   "CREATE DATABASE rc=0 stderr=''"
  ],
  [
   "create-check-table return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "create-check-table: fixture table lands on every anchor arm",
   true,
   "rc=0 output='1' expected='1'"
  ],
  [
   "add-plain-column return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "add-plain-column: column lands",
   true,
   "rc=0 output='3' expected='3'"
  ],
  [
   "insert-clean-row return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "insert-clean-row: clean row lands under every arm",
   true,
   "rc=0 output='1' expected='1'"
  ],
  [
   "drop-fixture return code",
   true,
   "rc=0 expected=0 stderr=''"
  ],
  [
   "drop-fixture: fixture dropped",
   true,
   "rc=0 output='0' expected='0'"
  ],
  [
   "image digest matches locked baseline",
   true,
   "locked='pingcap/tidb@sha256:490861bd4a2fa643dbe76b77ffecafcad66e6a42774e580b82f4ec2429a80e57' resolved=['pingcap/tidb@sha256:490861bd4a2fa643dbe76b77f"
  ],
  [
   "running container image identity",
   true,
   "container='sha256:490861bd4a2fa643dbe76b77ffecafcad66e6a42774e580b82f4ec2429a80e57' image_id='sha256:490861bd4a2fa643dbe76b77ffecafcad66e6a42774e580b8"
  ],
  [
   "platform recorded and matches baseline",
   true,
   "platform='linux/arm64' locked='linux/arm64'"
  ]
 ],
 "T12.db.tidb85.syntax_negative": [
  [
   "nonzero syntax failure",
   true,
   "rc=1"
  ],
  [
   "expected error class",
   true,
   "error_class='1064' expected='1064'"
  ],
  [
   "no permission/connection/object-conflict markers",
   true,
   "forbidden markers found: []"
  ]
 ]
}