# T12 CHECK constraints & enforcement-state — R4 evidence archive (final docs closeout)

Frozen HEAD: 9d2c439c46f6faed434e91c8b54ebc82abbf0787 (unchanged)
Issue: Fanduzi/DeltaScope#91 — work order T12-R4-DOCS-CLOSEOUT-01

## Authoritative index
- **review/standards-review-r4.md** — FINAL standards conclusion. 8.0.15/8.0.16 natively
  verified (digests, VERSION, SQL/rc, SHOW CREATE, IS, teardown bound). Supersedes R2
  "tags unavailable / boundary OPEN" wording (retained as history only).
- **spec/spec-review-r4.md** — FINAL spec conclusion. Boundary clause now VERIFIED PASS;
  default-policy evidence points at parity/offline-default-*; column-level CHECK proven
  by named Go tests (Golden db fixtures are table-level only — corrected).
- R1/R2/R3 documents retained unchanged as evidence history; older wording that conflicts
  with the R4 files above is superseded, not deleted.

## Archive layers (byte-preserved)
- R1: 5c329e8da68e70377c046a6c80e4ae4e2bab18fa5943da761dc786d4513c901a
- R2: 00fa595506b1c7f5170ff9388c50564b4747e44b8d912f096d0b2d81aae0ea65
- R3: 107b0340553b7120f515c330d1778aff5cb758ebfc467c782b0b51d428eda790

## This round (docs-only)
NEW: review/standards-review-r4.md, spec/spec-review-r4.md, this README, receipt.
No product, Oracle, or test modification (zero tracked-file diffs).
No Golden / gates / native / perf / parity re-run required — evidence-only correction.
