# T12 inventory binding

File: testdata/ddl-inventory/inventory.yaml
Blob SHA (frozen HEAD): 3cb068e166ec608984b8e3487f60dd182a3bb2db
Row: `mysql.alter-table.check-constraints` — lines 1372–1404, owner: T12 (L1404)
  - id at L1372; status: semantically_checked; parser_status: recognized; audit_status: audited
  - applicability anchors mysql80 (8.0) + mysql84 (8.4), both audited, evidence → T12.json + corpus files
  - status_evidence L1399 records T12 delivery: ADD/DROP CHECK|CONSTRAINT + ALTER CHECK|CONSTRAINT [NOT] ENFORCED on 8.0/8.4, not_enforced/ignored notices, 3821-class exists blockers, ENFORCED data-conditional unvouch, 5.7 accept-ignore + 1064 refusal
  - acceptance refs L1403 → testdata/ddl-golden/T12.json + check_lifecycle.sql + check_ignored_57.sql
T12 task declaration: line 81 `T12: {issue: 91, title: "CHECK constraints and enforcement state"}`
Golden oracle: testdata/ddl-golden/T12.json blob 3449107b9493cda4b5c3465d3d04d1b4fb6a6d4f
Corpus: testdata/sql-corpus/mysql/ddl/metadata/check_lifecycle.sql, check_ignored_57.sql
