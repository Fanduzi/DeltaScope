#!/usr/bin/env python3
"""Deterministic T12 CHECK-heavy audit fixture generator (R3).
Seed fixed; output is byte-identical across runs."""
import hashlib
stmts = []
for i in range(300):
    stmts.append(f"CREATE TABLE perf_t{i} (id INT, CONSTRAINT chk_{i} CHECK (id > {i % 50}));")
    if i % 3 == 0:
        stmts.append(f"ALTER TABLE perf_t{i} ALTER CHECK chk_{i} NOT ENFORCED;")
    if i % 5 == 0:
        stmts.append(f"ALTER TABLE perf_t{i} DROP CHECK chk_{i};")
data = "\n".join(stmts) + "\n"
with open("fixture.sql", "w") as f:
    f.write(data)
print(len(stmts), hashlib.sha256(data.encode()).hexdigest())
