# ER4 — T12 perf re-measurement (R3 supplemental, replaces invalid R2 samples)

R2 evidence kept unchanged (perf/samples.txt contains the failed `/usr/bin/time -f` output —
platform-incompatible flag; samples-ms.txt numbers listed but mislabeled p95).
These R3 numbers are a NEW measurement, not a rewrite of R2 history.

- generator: perf/generate_fixture.py (deterministic, no RNG needed — pure loop)
- fixture: perf/fixture.sql, 460 statements, SHA-256 99bf4d5ad7bdf2afaea32754c9f8296b32c09f8017fe2f13b16dcc1b602880d7
- byte-identity proof: generator re-run reproduces the same SHA (see generate_fixture output line)
- binary: bin/deltascope SHA-256 1fffdd765ef3055940ba7a77789d84a9acc7274204c5665e0ae3058a2a5bdd48,
  vcs.revision=9d2c439c46f6 (frozen HEAD), built `CGO_ENABLED=1 go build -tags postgresql`
- timing: python3 time.time_ns() deltas around each invocation (platform-compatible)
- per-sample argv/rc/ms: perf/samples-r3.txt (13 rows: 1 cold + 12 warm, all rc=1 = reject verdicts as expected)
- anchor: disposable mysql:8.0.46 at 127.0.0.1:19980 schema golden
- scope: audit-path latency only — NOT database DDL execution time

Results:
- cold: 199 ms
- warm n=12: 143,147,142,135,134,134,135,139,135,139,139,139 ms
- median 139.0, min 134, max 147
- p95 nearest-rank = 147 ms; p95 linear-interpolation = 144.8 ms (method stated)
R2 samples (163..216) are marked superseded; their correct stats were median 170,
p95-lin 202.95 / p95-nr 216 — the R2 claim of 187 was wrong and is withdrawn.
