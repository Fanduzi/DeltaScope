# T12 spec review R3 — #91 acceptance clauses, truthful evidence mapping

Every clause binds to (a) a real golden case_id in artifact-r2.json (25 cases, required==executed==matrix), or (b) a real Go test name from `-run T12 -v` raw log (review/focused-t12.log, 89 RUN lines, all PASS), or (c) OPEN when unproven. No invented case IDs.

## CREATE TABLE
| clause | evidence |
| column-level CHECK | Test TestT12R1InColumnCheckNameGoverned, TestT12AddColumnInColumnCheckLands (audit pkg); golden T12.db.mysql8{0,4}.ddl fixture includes column+table CHECK |
| table-level CHECK explicit name | T12.db.*.ddl (CONSTRAINT chk_id/chk_v), T12.meta.*-golden setup |
| automatic name | covered by rules' auto-name path; focused tests TestT12AlterAddCheckNameJudged/TestT12BareAddCheckNameUnknown |
| multi-column dependency | TestT12R1MultiColumnCheckBlocksDropColumn, TestT12R2MySQLInColumnCrossColumnRefRefused, TestT12R2TiDBMultiActionChangeDropsMultiColCheck |
| ENFORCED declared | TestT12R1ExplicitEnforcedCreateOn57Refuses / …DeclOn57Refuses (5.7 clause refusal); golden meta golden cases (ENFORCED=YES fixture) |
| NOT ENFORCED declared | T12.cli.t12-cli-create-notenforced-offline-gap; TestT12AddCheckNotEnforcedDeclaresDisabled |
| 5.7 accepted-ignored | T12.meta.t12-mysql57-ignored (native: accepted, no member); TestT12MySQL57CheckDeclarationIgnoredReveal, TestT12R1BareDeclOn57StillIgnored |
| TiDB flag ON/OFF | T12.meta.t12-tidb85-golden (ON), T12.meta.t12-tidb85-flag-off-ignored (OFF, stores-no-member assertion); TestT12TiDBFlag{On,Off,Unobserved}, TestT12TiDBSequenceArms, TestT12R2TiDBOffExplicitClauseStillIgnored |
| invalid/inapplicable syntax | T12.db.*.syntax_negative (all four anchors, error_class 1064) |

## ALTER TABLE
| ADD CHECK / ADD CONSTRAINT CHECK | T12.cli.t12-cli-add-check-declared-offline-gap; TestT12AlterAddCheckNameJudged, TestT12AddCheckDuplicateNameRefuses |
| DROP CHECK | T12.meta.t12-mysql80-drop-present (pass + member gone); T12.cli.t12-cli-drop-check-offline-gap |
| DROP CONSTRAINT (generic) | TestT12R1CheckSpellingDropsCheckKeepsUnique, TestT12R1DropCheckOnSecondaryIndexRefuses, TestT12R1GenericDropSameNameAmbiguityRefused |
| ALTER CHECK [NOT] ENFORCED | T12.meta.t12-mysql{80,84}-golden; T12.cli.t12-cli-alter-check-off / -enforced-offline; TestT12AlterCheckEnforcedReverseDoesNotFire (ENFORCED does NOT fire disable finding), TestT12AlterCheckNotEnforcedGoldenPath |
| ALTER CONSTRAINT alias | T12.cli.t12-cli-alter-constraint-alias-offline; meta mysql84 golden verifies alias flip ENFORCED=NO; TestT12AlterConstraintAlias; spelling floors: TestT12R1AlterCheckCheckSpellingOn8017Executes / TestT12R1AlterConstraintSpellingOn8017Refused |

## Naming / dependency
| valid/invalid name, collision | TestT12AddCheckDuplicateNameRefuses, TestT12R1InColumnDuplicateNameRefusesAtomically, TestT12R1TiDBInColumnDuplicateLandsColumn, TestT12R2CommentedCommaKeepsSpellingOn8017 |
| missing target (3821-class) | T12.meta.t12-mysql80-alter-missing (native stderr 3821); TestT12AlterCheckMissingNameExistsFinding |
| wrong constraint kind | TestT12AlterCheckNonCheckNameExistsFinding (non-CHECK name = proven refusal), TestT12R1CheckSpellingDropsCheckKeepsUnique, TestT12R2UnknownKindSameNameLeavesCheckUnvouched |
| dependency-column changes | TestT12ChangeColumnCheckReference{CascadeTiDB,RefusedMySQL}, TestT12DropColumnCheckCascade (silent cascade vs unvouched unsafe), TestT12R1MultiColumnCheckBlocksDropColumn |
| rename-table/rename-column effects | TestT12RenameColumnCheckReference{Refused,RefusedTiDB,UnvouchedUnsafe}, TestT12R2Tail2UnprovenSiblingDropWithholdsSuccessor (RENAME_COLUMN + DROP same-statement matrix) |
| unknown vs proven state | TestT12CreateTableCheckArmSplit/unobserved_version_unvouches_the_collection, TestT12R2TailGenericDropUnvouchesPK, TestT12R2GenericPrimaryBindsPKUnknown |

## Batch / prospective state
| ADD→ALTER | TestT12AddThenAlterSequence |
| ALTER→DROP / ADD→DROP | TestT12AddThenDropSequence + /CHECK /CONSTRAINT subtests; T12.db.*.ddl ordered native steps |
| NOT ENFORCED→ENFORCED | TestT12AlterCheckEnforcedReverseDoesNotFire |
| drop→reference / identity succession | TestT12R2TailSameStmtDropCheckUnblocksIdentity, TestT12R2TailUnrelatedDropCheckKeepsIdentityRefusal, TestT12R2Tail2* series |
| dependency-column modification | TestT12ChangeColumnCarryingCheckTombstones |
| CHECK/FK/INDEX mixed | TestT12R2GenericDropPrimaryRespectsFKDependency; T11 golden re-run (40/518) guards DROP CONSTRAINT/FK boundary incl. TiDB warned-noop |
| blocker doesn't erase hypothetical post-state | batch_state design; TestT12AddThenAlterSequence verifies ordered overlay after finding |

## Transport / gaps
| offline evidence-gap honesty | T12.cli.*-offline-gap cases (unverified + required_facts, exit 0 review, no silent pass) |
| four-surface parity | transports/r2/{cli,sdk,http}.json + mcp.jsonl — identical reject/complete/blocker (R2 parity-root-cause.md) |
| default policy no-metadata | transports/r2/offline-default.* raw argv/stdout/stderr/rc |

## OPEN items (not claimed)
| MySQL 8.0.15/8.0.16 native boundary | docker pull blocked by credential-helper failure (native/r3 pull logs, correct classification ER5) — product models the gate via ResolveCheckArm + per-spelling floors (TestT12R1*8017* tests); native direct-probe remains OPEN |
