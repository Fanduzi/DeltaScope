# T12 standards review — CHECK constraints & enforcement state

## Official documentation consulted
- MySQL 5.7 Reference Manual: https://dev.mysql.com/doc/refman/5.7/en/ — 5.7 has no enforced CHECK; the clause is parsed in CREATE TABLE (accepted, ignored) but ALTER CHECK/DROP CHECK/ALTER TABLE CHECK lifecycle verbs do not exist. ALTER TABLE CHECK CONSTRAINT ... [NOT] ENFORCED does not exist.
- MySQL 8.0: https://dev.mysql.com/doc/refman/8.0/en/create-table-check-constraints.html — CHECK enforced since 8.0.16; ENFORCED/NOT ENFORCED; ALTER TABLE ... ALTER CHECK / DROP CHECK / ALTER CONSTRAINT [NOT] ENFORCED; missing target → ERROR 3821.
- MySQL 8.4: https://dev.mysql.com/doc/refman/8.4/en/create-table-check-constraints.html and https://dev.mysql.com/doc/refman/8.4/en/alter-table.html — same semantics as 8.0.
- TiDB 8.5 (PingCAP release-8.5 docs): CHECK constraints gated behind `tidb_enable_check_constraint` (default OFF); when OFF the clause is stored/ignored, when ON enforcement applies; TABLE_CONSTRAINTS lacks the ENFORCED column (schema difference vs MySQL).

## Native observations (isolated disposable databases; raw logs in archive/native/)
| Anchor | Image digest | VERSION() | Observation |
|---|---|---|---|
| mysql 5.7.44 | mysql@sha256:4bc6bc96...aad73bb | 5.7.44 | CHECK decl parses but ignored; ALTER/DROP CHECK → ERROR 1064; no ENFORCED column |
| mysql 8.0.46 | mysql@sha256:7dcddc01...358ae2b | 8.0.46 | violating INSERT → ERROR 3819; ALTER CHECK NOT ENFORCED ok, ENFORCED=NO; re-ENFORCE on dirty data → 3819; missing check → 3821 |
| mysql 8.4.10 | mysql@sha256:8dbcf531...b7d7db6 | 8.4.10 | same as 8.0 |
| tidb v8.5.0 | pingcap/tidb@sha256:490861bd...0a80e57 | 8.0.11-TiDB-v8.5.0 | tidb_enable_check_constraint exists, default OFF; OFF → decl lands, inserts pass; ON → ERROR 3819; TABLE_CONSTRAINTS.ENFORCED → ERROR 1054 (column absent) |

## Product verdict (per rule family, frozen HEAD)
- `ddl.constraint.check.not_enforced.notice` — fires on declared ENFORCED→NOT ENFORCED transitions (audit-level risk notice, elevated to blocker under t12-all policy).
- `ddl.alter.alter_check.exists.require` — blocker when the target CHECK is proven absent (matches native 3821).
- `ddl.alter.drop_check.exists.require` — same for DROP CHECK.
- `ddl.alter.alter_check.version.require` — blocker for CHECK lifecycle verbs on versions that lack them (5.7 → 1064 native).
- `ddl.constraint.check.ignored.notice` — warning when the engine accepts-but-ignores the declaration (5.7; TiDB with flag OFF).

## 8.0.16 boundary
Pre-8.0.16 MySQL parses but ignores CHECK. The four anchors do not include an 8.0.x<16 instance; product treats <8.0.16 via the same ignored/version gates as 5.7 (version.require rule). Flagged as a documented boundary, not a claimed all-version guarantee.
