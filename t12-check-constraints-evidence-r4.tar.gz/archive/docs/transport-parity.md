# T12 transport parity — R1 NEW RUN

Identical inputs on all four surfaces:
- SQL: `ALTER TABLE t12g ALTER CHECK chk_id NOT ENFORCED;`
- Policy: /tmp/ddl-golden/T12/T12/golden-policy-t12-all.yaml
- Anchor: disposable mysql:8.0.46 container, schema `golden`, fixture `t12g(id INT, CONSTRAINT chk_id CHECK (id>0))` ENFORCED=YES
- Connection: 127.0.0.1:19980 root / password via env `DS_T12_PARITY_PW` (ephemeral)

| Surface | Call | verdict | coverage | findings | error |
|---|---|---|---|---|---|
| CLI | `deltascope audit --sql ... -H/-P/-u/--password-env/-D --config` | reject | complete | 1 blocker ddl.constraint.check.not_enforced.notice | exit 1 |
| SDK | `deltascope.Audit` w/ metadata provider + same policy | reject | complete | same blocker | none |
| HTTP | POST /v1/audit {connection_id:t12-mysql80} | reject | complete | same blocker | HTTP 200 |
| MCP | tools/call audit_sql w/ connection + config_path | reject | complete | same blocker | isError absent |

Default-policy / no-metadata probe (CLI offline, no version):
verdict review, coverage unverified, 0 findings, 4 evidence gaps
(target_table.existence; target.version ×3) — honest gaps, no silent pass.
Raw outputs in archive/transports/.
