# T12 spec review — #91 acceptance clauses × golden cases

Mapping of the T12 work-order semantic matrix to executed cases (artifact.json = raw evidence path for each row).

| #91 clause | covering case(s) | result |
|---|---|---|
| CREATE column-level CHECK | T12.db.mysql8{0,4}.ddl, T12.cli.*create* | PASS |
| CREATE table-level CHECK, explicit+auto names | T12.db.*.ddl, cli naming cases in T12.json cli_cases | PASS |
| ENFORCED / NOT ENFORCED declaration | T12.cli.t12-cli-create-notenforced-offline-gap, T12.meta.*-golden | PASS |
| MySQL <8.0.16 accepted-but-ignored | T12.meta.t12-mysql57-ignored (native: stores nothing) | PASS |
| ALTER ADD CHECK / ADD CONSTRAINT CHECK | T12.cli.t12-cli-add-check-declared-offline-gap, db lifecycle probes | PASS |
| DROP CHECK / DROP CONSTRAINT | T12.meta.t12-mysql80-drop-present, t12-cli-drop-check-offline-gap | PASS |
| ALTER CHECK [NOT] ENFORCED + CONSTRAINT alias | T12.meta.t12-mysql{80,84}-golden (84 verifies alias flip ENFORCED=NO), t12-cli-alter-constraint-alias-offline | PASS |
| Missing target → 3821-class blocker | T12.meta.t12-mysql80-alter-missing (native stderr 3821) | PASS |
| Wrong constraint kind / cross-type name | batch-state binding rules, T12.json cli_cases wrong-kind rows | PASS |
| TiDB flag ON | T12.meta.t12-tidb85-golden (flag fact ON, 3819 path) | PASS |
| TiDB flag OFF accepted-not-persisted | T12.meta.t12-tidb85-flag-off-ignored (asserts stores no member) | PASS |
| 5.7 syntax refusal (1064) | T12.db.mysql57.syntax_negative + t12-mysql57-version-refusal | PASS |
| 8.0.15/8.0.16 boundary native | Docker Hub tags absent — pull logs native/mysql801{5,6}-pull.log; modeled via version gates; OPEN, not claimed | OPEN |
| Evidence-gap semantics offline | T12.cli.*-offline-gap cases (unverified+required_facts, no silent pass) | PASS |
| Prospective/batch state ordering | T12.ddl_steps.* batch cases (add→alter→drop sequences, rename effects) | PASS |
| Four-surface parity | parity/*.json (CLI/SDK/HTTP/MCP, identical result) | PASS (R2) |
| T11 regression boundary | R2 re-run `make ddl-golden TASK=T11` → see golden/t11-make.log + artifact | see ER3 |

Full per-case field matrix: matrix/acceptance-matrix-full.md (25 rows).
Set equality: required_case_ids (25) == executed case_ids (25) == matrix rows (25).
