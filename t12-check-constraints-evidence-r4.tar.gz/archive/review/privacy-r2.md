# ER7 privacy probe — sensitive literal leakage check

Probe: ALTER TABLE t12g ADD CONSTRAINT chk2 CHECK (salary < 'topsecret-value-123') NOT ENFORCED;
Same parity anchor + t12-all policy. Output: parity/privacy-probe.json (+ second run).

Result:
- Finding emitted: ddl.constraint.check.not_enforced.notice.
- finding.message: `check constraint "chk2" on table "t12g" is declared NOT ENFORCED` — names only.
- finding.metadata: {action? no: constraint=chk2, enforced=not_enforced, table=t12g} — names only.
- The literal 'topsecret-value-123' occurs exactly once in the whole result: inside raw_sql/normalized_sql (input echo, expected) — never inside findings, diagnostics, messages, suggestions, or metadata.
- Evidence gaps reference fact names only (target_table.existence, target.version) — no SQL content.

Verdict: derived fields do not propagate expression literals. No leak class found.
