# ER1 — R2 archive accounting erratum

R2 receipt claimed NEW=54 / REUSED=110. Correct accounting (byte-level vs R1 manifest):
- R1 payload = 110
- R2 payload = 164
- R1→R2 unchanged (REUSED) = 108
- R1→R2 content-changed = 2 (README.md, receipt/receipt.md) → these count as NEW
- R2 brand-new paths = 54
- **R2 correct split: NEW=56 / REUSED=108**

Root cause: ledger classification keyed on "path exists in R1 manifest" but README.md and
receipt.md were rewritten for R2 with different bytes — a same-path/different-content case
that should have been NEW. R3 reuse-ledger below classifies by SHA against R1+R2 manifests
with changed-content paths explicitly marked NEW.
