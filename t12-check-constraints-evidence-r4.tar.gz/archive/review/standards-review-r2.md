# T12 standards review R2 — CHECK constraints & enforcement state

Distinguishes four fact classes: official docs / native observed / product model / golden coverage.
"accepted" (parses, rc=0) ≠ "persisted" (member stored) ≠ "enforced" (DML rejected).

## MySQL 5.7.44 (anchor: mysql@sha256:4bc6bc96…aad73bb, VERSION()=5.7.44)
Official: 5.7 Reference Manual — CHECK clause is parsed in CREATE TABLE but always ignored; no ALTER/DROP CHECK verbs.
Native (archive/native/57-*.txt):
- CREATE TABLE ... CHECK → rc=0 accepted; no member in TABLE_CONSTRAINTS; violating INSERT lands (ignored).
- ALTER TABLE ... ALTER/DROP CHECK, NOT ENFORCED, ALTER CONSTRAINT → ERROR 1064 (syntax refusal).
- TABLE_CONSTRAINTS has no ENFORCED column (1054).
Product: ddl.constraint.check.ignored.notice (warning) on accepted-but-ignored declarations; ddl.alter.alter_check.version.require blocker on lifecycle verbs (matches 1064); ddl.alter.drop_check.exists.require same.
Golden: T12.db.mysql57.*, T12.meta.t12-mysql57-ignored, t12-mysql57-version-refusal.

## MySQL <8.0.16 boundary
Official: CHECK enforcement introduced 8.0.16 (8.0 manual, "Prior to MySQL 8.0.16, ... parsed but ignored"). ALTER TABLE ... CHECK → ENFORCED requires ≥8.0.16; ALTER CONSTRAINT spelling ≥8.0.19.
Native attempt (R2): docker pull mysql:8.0.15 and mysql:8.0.16 — see native/mysql8015-pull.log / mysql8016-pull.log (tags unavailable on Docker Hub → boundary probed indirectly).
Product: spec.ResolveCheckArm splits MySQL ≥8.0.16 enforced / <8.0.16 ignored / unknown→gaps; generic-spelling gate ≥8.0.19 probed on the 8.0.17-band anchor in unit tests. Direct 8.0.15/8.0.16 native confirmation remains an explicitly open row (env limit, documented not claimed).

## MySQL 8.0.46 (mysql@sha256:7dcddc01…358ae2b, VERSION()=8.0.46)
Native (80-*.txt): violating INSERT → 3819; ALTER CHECK NOT ENFORCED rc=0 (TC.ENFORCED=NO); re-ENFORCE on dirty data → 3819; missing name → 3821; DROP CHECK rc=0 (member gone); ALTER CONSTRAINT spelling accepted.
Product: not_enforced.notice on declared flip; exists.require (3821-class) blockers; version.require never fires at ≥8.0.16.
Golden: T12.meta.t12-mysql80-golden / alter-missing / drop-present.

## MySQL 8.4.10 (mysql@sha256:8dbcf531…b7d7db6, VERSION()=8.4.10)
Same semantics as 8.0 (native 84-*.txt; golden t12-mysql84-golden incl. ALTER CONSTRAINT alias flip landing ENFORCED=NO).

## TiDB v8.5.0 (pingcap/tidb@sha256:490861bd…0a80e57, VERSION()=8.0.11-TiDB-v8.5.0)
Official (PingCAP release-8.5 docs): CHECK gated by system variable tidb_enable_check_constraint (default OFF).
Native (tidb-*.txt):
- Variable exists; SHOW VARIABLES default OFF; scope global/session.
- flag OFF: CREATE ... CHECK rc=0 (accepted) but SHOW CREATE omits the clause and CHECK_CONSTRAINTS has no member (NOT persisted); violating INSERT lands. **Corrected wording — accepted, not persisted.** (see tidb-off-erratum.md)
- flag ON: CHECK persisted (SHOW CREATE shows clause, CHECK_CONSTRAINTS row present); violating INSERT → 3819; ALTER CHECK NOT ENFORCED rc=0.
- TABLE_CONSTRAINTS.ENFORCED → ERROR 1054 (column absent — real schema difference; provider reads TiDB-specific sources instead).
- Flag restored + teardown logged (r12-teardown.log).
Product: arm resolver reads tidb_enable_check_constraint → enforced/ignored; ignored.notice fires when OFF.
Golden: T12.meta.t12-tidb85-golden (ON), t12-tidb85-flag-off-ignored (OFF, asserts "stores no member").

## Product verdict
All versioned behaviors match native observations; no standards conflict found. R1 wording error ("stored" under TiDB OFF) corrected; semantics unchanged.
