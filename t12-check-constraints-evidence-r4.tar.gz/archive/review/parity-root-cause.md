# ER1 — SDK parity root cause (R1 unverified → R2 complete)

## R1 artifact reproduction
R1 transports/sdk.txt: verdict reject, coverage **unverified**, finding not_enforced.notice blocker.
R2 reproduction with the R1 probe (Schema field absent):
  go run tmp-probes/t12_sdk_full.go <policy> ""  → sdk-noschema.json: verdict reject / coverage unverified / context absent.

## Root cause — Category A (probe config divergence, NOT product defect)
The R1 probe set Request.MetadataProvider+ConfigPath but left Request.Schema="".
The CLI sets schema golden (from -D); HTTP resolves schema via connection registry;
MCP resolves via connection.database. With empty Schema the SDK request could not
scope table-snapshot existence → target_table.existence stayed unproven →
coverage=unverified. The rule finding itself fired identically (declared-transition
rule does not depend on existence).

Fix: set Request.Schema="golden" (parity/sdk.json) → reject / complete / same blocker.
No product change; class A per the work order's taxonomy.

## Four-surface reconciliation (identical SQL/policy/metadata/version)
SQL: ALTER TABLE t12g ALTER CHECK chk_id NOT ENFORCED;
Policy: golden-policy-t12-all.yaml SHA in archive; anchor mysql:8.0.46 schema golden, chk_id ENFORCED=YES.

| surface | call | verdict | coverage | findings | gaps | exit/status |
| CLI    | bin/deltascope audit --sql ... -H -P -u --password-env -D --config --format json | reject | complete | 1×ddl.constraint.check.not_enforced.notice blocker | 0 | exit 1 |
| SDK    | deltascope.Audit{SQL,Schema:golden,MetadataProvider,ConfigPath} | reject | complete | same | 0 | nil error |
| HTTP   | POST /v1/audit {sql, connection_id:t12-mysql80} | reject | complete | same | 0 | HTTP 200 |
| MCP    | tools/call audit_sql {connection{host,port,user,password_env,database}, config_path} | reject | complete | same | 0 | isError absent |

## Binary identity (rebuilt from frozen HEAD for R2)
All three binaries rebuilt via make build-cli/server/mcp at HEAD 9d2c439c46f6faed434e91c8b54ebc82abbf0787;
`go version -m` reports vcs.revision=9d2c439c46f6… on all three (parity/binary-sha.txt has SHA-256s).
"+dirty" in serverInfo is the Go VCS stamp for untracked files in the module dir
(tmp-probes/, artifacts/) at build time — tracked files were unchanged
(git diff --exit-code clean); it does not mark committed code drift.
R1 note: R1's deltascope-server was an older build (vcs.revision=ce7cda29…, a frozen-HEAD
ancestor); R2 re-measured HTTP parity with the frozen-HEAD build — result identical.

## Default-policy / no-metadata probe (real argv + raw)
argv: bin/deltascope audit --sql "ALTER TABLE t12g ALTER CHECK chk_id NOT ENFORCED;" --dialect mysql --format json
stdout/stderr/rc preserved (parity/offline-default.*): verdict review / coverage unverified /
0 findings / 4 evidence gaps (target_table.existence; target.version ×3 for the three
version/enforcement-gated rules). rc=1.
