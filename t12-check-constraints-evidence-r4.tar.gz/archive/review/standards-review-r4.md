# T12 standards review R4 — FINAL authoritative standards conclusion

This document is the final standards verdict for #91. R2's "tags unavailable / boundary OPEN"
wording is SUPERSEDED by R3 native evidence. R2 files are retained unchanged as history.

Fact classes: official docs / native observed / product model / golden coverage.
"accepted" (rc=0) ≠ "persisted" (member stored) ≠ "enforced" (DML rejected).

## MySQL 5.7.44 (anchor mysql@sha256:4bc6bc96…aad73bb, VERSION()=5.7.44)
Official: CHECK clause parsed but always ignored; no ALTER/DROP CHECK verbs.
Native (native/57-*.txt): CREATE...CHECK rc=0, no TABLE_CONSTRAINTS member, violating INSERT
lands; ALTER/DROP CHECK, NOT ENFORCED, ALTER CONSTRAINT → ERROR 1064; ENFORCED column → 1054.
Product: check.ignored.notice warning; alter_check/drop_check version.require blockers.
Golden: T12.db.mysql57.*, T12.meta.t12-mysql57-ignored, t12-mysql57-version-refusal.

## MySQL 8.0.15 (mysql:8.0.15 — EXECUTED R3, boundary CLOSED)
Image: mysql:8.0.15, image digest sha256:a7cf659a764732a27963429a87eccc8457e6d4af0ee9d5140a3b56e74986eed7,
platform linux/amd64, VERSION()=8.0.15.
Native (native/t12-8015.log, t12-8015b-tc.log, t12-8015-detail.log; pull records t12-r3-8015*.log):
- CREATE TABLE ... CONSTRAINT ck CHECK (id>0) → rc=0 ACCEPTED.
- SHOW CREATE TABLE → no CHECK clause; TABLE_CONSTRAINTS → no member (NOT persisted).
- ENFORCED column query → ERROR 1054 (column absent).
- Violating INSERT (-1) → rc=0 lands; second insert lands (COUNT=2) — NOT enforced.
- ALTER CHECK NOT ENFORCED / DROP CHECK / ALTER CONSTRAINT → all ERROR 1064.
- Teardown: container removed (r12 teardown verified; no residue).
Matches product arm model: MySQL <8.0.16 = parsed-but-ignored; per-spelling verb floors.
Go tests: TestT12R1*8017* per-spelling floors, ResolveCheckArm split.

## MySQL 8.0.16 (mysql:8.0.16 — EXECUTED R3, boundary CLOSED)
Image: mysql:8.0.16, image digest sha256:5d11283aee9b73509b737785e0ad79a2d9abf51f4abf3f221702a8add0e36bf2,
platform linux/amd64, VERSION()=8.0.16.
Native (native/t12-8016.log, t12-8016-detail.log; pull records t12-r3-8016*.log):
- CREATE CHECK → rc=0; SHOW CREATE shows `CONSTRAINT `ck` CHECK ((`id` > 0))` (persisted).
- Violating INSERT → ERROR 3819 (enforced).
- ALTER CHECK ck NOT ENFORCED → rc=0 (flip lands).
- DROP CHECK ck → rc=0 (member gone).
- ALTER CONSTRAINT ck NOT ENFORCED → ERROR 1064 (generic spelling requires ≥8.0.19 —
  matches product per-spelling floor: CHECK spelling ≥8.0.16, generic ≥8.0.19).
- Teardown: container removed.
Enforcement boundary confirmed exactly at 8.0.16, as modeled by ResolveCheckArm and
TestT12R1AlterCheckCheckSpellingOn8017Executes / TestT12R1AlterConstraintSpellingOn8017Refused.

## Environment-error attribution (corrected)
R2 failure was a Docker credential-helper (osxkeychain/desktop) timeout
(`error getting credentials - err: signal: terminated`, rc=124) — NOT missing tags.
R3 fix: anonymous DOCKER_CONFIG + `--platform linux/amd64` (tags exist; only amd64
manifests published for these old tags). Classification fixed in
native/boundary-8015-8016.md; pull logs native/t12-r3-801{5,6}{,b,c}.log.

## MySQL 8.0.46 / 8.4.10 / TiDB v8.5.0 — unchanged from R2 review
8.0.46 (digest sha256:7dcddc01…358ae2b): INSERT→3819, ALTER CHECK NE rc=0 (ENFORCED=NO),
re-ENFORCE on dirty data→3819, missing→3821, DROP CHECK rc=0, ALTER CONSTRAINT accepted.
8.4.10 (digest sha256:8dbcf531…b7d7db6): same semantics incl. ALTER CONSTRAINT alias flip.
TiDB v8.5.0 (digest sha256:490861bd…0a80e57): tidb_enable_check_constraint gates
persistence+enforcement; OFF = accepted/not persisted/not enforced (see tidb-off-erratum.md);
ON = persisted + 3819 + ALTER CHECK NE lands; TC.ENFORCED column absent (1054) by design.

## Final product verdict
Every versioned arm — 5.7 ignored, 8.0.15 ignored (verified), 8.0.16 enforced (verified,
exact boundary), 8.0.46/8.4.10 enforced, TiDB flag-gated — matches native observation.
No standards conflict remains. No OPEN boundary items.
