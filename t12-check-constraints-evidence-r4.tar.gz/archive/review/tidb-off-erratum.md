# ER2 — TiDB flag-OFF fact correction

R1 wording ("OFF 時宣言は保存されるが挿入は受理" / "declaration stored") was wrong.

Native evidence reconciliation:
- native/tidb-create-check.txt: CREATE TABLE with CHECK → rc=0 (DDL ACCEPTED).
- native/tidb-showcreate.txt: SHOW CREATE TABLE output contains NO CHECK clause (not persisted into the table definition).
- native/tidb-check-cc.txt: information_schema.CHECK_CONSTRAINTS has no row (no member persisted).
- Golden T12.meta.t12-tidb85-flag-off-ignored: assertion "flag OFF stores no member" (expected 0 rows) PASS.

Correct fact set:
- DDL accepted: YES (rc=0)
- CHECK clause persisted in SHOW CREATE: NO
- CHECK_CONSTRAINTS member persisted: NO
- INSERT enforcement: NO (violating rows land)
- Product modeling: ddl.constraint.check.ignored.notice (warning) — treats the declaration as accepted-but-ignored, matching native.

R1 standards-review.md corrected in review/standards-review-r2.md (this file supersedes the wording).
