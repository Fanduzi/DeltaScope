# T12 focused-test reconciliation — R2 NEW RUN (corrected)

Exact argv: `go test ./internal/application/audit ./internal/domain/rule/ddl -run T12 -v -count=1`
cwd: /Users/fan/GolangProjects/DeltaScope, tested HEAD: 9d2c439c46f6faed434e91c8b54ebc82abbf0787

Counting method: `=== RUN` lines (top-level + subtests).
- internal/application/audit: **89**
- internal/domain/rule/ddl: **0** ([no tests to run] — no test names match "T12"; CHECK tests use "Check" naming)
- **total: 89** — both packages PASS. Full raw log: /tmp/t12-r2/focused-t12.log (89 RUN lines, all PASS)

Supplementary pattern `go test ... -run 'T12|Check' -v`:
- audit: 164 RUN lines; rule/ddl: 19 RUN lines; both ok.
(Rule/ddl CHECK tests are named Test*Check*, not T12-prefixed.)

Erratum on the R1 receipt: the earlier figure "155" cannot be reproduced by any
exact -run pattern — the honest count for the exact command is 89, and the
wider Check-family pattern is 183. No test regressed; the R1 number was a
counting-method error, not a product failure.
