# T12 downstream impact — shared code touched by later commits

Scope: files changed by T12 product commits that later tasks (T13+) also touch.
Method: git log 9d2c439c46f6 -- <paths> after the last T12 commit; verified via ledger.csv.

- internal/domain/rule/ddl/check_constraint_rules.go — T12-owned; no later-task modifications after dcf250ea (last touching commit is T12's own).
- internal/application/audit/batch_state_check.go — T12-owned file; T13+ commits in local history do not modify it (ledger diff-tree scan).
- internal/application/audit/batch_state.go — shared state core; later tasks extended it but T12's checkArm hook points (checkArmFor/applyAlterCheck/applyAddCheck call sites) are stable — T11 golden 40/518 re-run in this round is the regression control.
- internal/domain/spec/metadata.go FindCheckConstraint/HasUnprovenCheckName/CheckNameSpaceUnvouched — consumed by T12 rules only.
- internal/infrastructure/parser/tidb/extractor.go extractConstraint — shared with T11/T13+ constraint extraction; T11 golden regression verifies no drift.
- Transports: shared AuditSQL entry unchanged by T12 (T12 adds rules, not transport code).
Conclusion: no later-task commit altered T12 semantics between the last T12 commit and frozen HEAD.
