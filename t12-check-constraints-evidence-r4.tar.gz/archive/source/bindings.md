# T12 effective source bindings @ frozen HEAD 9d2c439c46f6

Each entry: file | blob SHA | function | lines | test | golden case | later-task impact.

1. CHECK extraction & spelling forms
   internal/infrastructure/parser/tidb/extractor.go blob ceafd4cd…
   - extractConstraint L3304–3420 → excerpt extractor-extractConstraint-L3304.txt
   - checkSpellingForClause L4219 → excerpt extractor-checkSpellingForClause-L4219.txt
   - createCheckExplicitFlags L4411 → excerpt extractor-createCheckExplicitFlags-L4411.txt
   tests: extractor*_test.go (parser pkg); golden: all T12.db.* + T12.cli.* cases
   later-task impact: shared with T11/T13+ extraction — T11 golden re-run is regression control.

2. Model & finders
   internal/domain/spec/metadata.go blob 759a59ba…
   - FindCheckConstraint L646, HasUnprovenCheckName L666, CheckNameSpaceUnvouched L692 → spec-check-finders-L624.txt
   internal/domain/spec/version.go blob (see file) ResolveCheckArm L312 / CheckExplicitClauseRefused L365 → spec-ResolveCheckArm-L292.txt
   tests: spec package tests; golden: all meta cases exercising arms.

3. Rules (5 families)
   internal/domain/rule/ddl/check_constraint_rules.go blob e785b02b…
   - checkArm L42 / checkArmGap L54 / declaredNotEnforcedChecks L75 / alterCheckActions L101
   - checkNotEnforcedNoticeRule L113–191 (not_enforced.notice)
   - checkActionOutcome L210, checkDropTargetBinding L249, checkAlterTargetBinding L253, checkBindingGapFacts L265
   - alterCheckExistsRule L193–390 (alter_check.exists.require, 3821-class)
   - dropCheckExistsRule L392–491 (drop_check.exists.require)
   - checkIgnoredNoticeRule L493–578 (ignored.notice: 5.7 & TiDB-OFF arms)
   - alterCheckVersionRule L611–718 (version.require: per-spelling MySQL floors)
   tests: rule/ddl tests via Check-named tests (19 in -run 'Check'); golden: every T12 case.

4. Metadata provider
   internal/infrastructure/metadata/mysql/provider.go blob 2d0250c4…
   - loadCheckConstraints L1545 (TABLE_CONSTRAINTS.ENFORCED + CHECK_CONSTRAINTS clause facts)
   - loadTiDBCheckConstraints L1619, tidbCheckConstraintsTableExists L1680, checkEnforcementName L1699, tableConstraintsHasEnforced L1715 (MySQL ENFORCED column detect; TiDB lacks it → schema-branch)
   tests: provider_test.go; golden: T12.meta.* cases (observed ENFORCED=YES/NO, TiDB flag fact).

5. Prospective state
   internal/application/audit/batch_state_check.go blob 0a954ffe…
   - checkArmFor L16, firstAlterCheckAlter L24, applyAlterCheck L50, applyAddCheck L155
   - inColumnChecksOutcome L233, applyInColumnChecks L322, dropColumnCascadedChecks L370, dropIdentityCascadedChecks L394, checkMemberReferences L413, checkColumnIdentityOutcome L459
   internal/application/audit/batch_state.go cloneConstraint L3925
   tests: application/audit T12 tests (89 in -run T12); golden: T12.ddl_steps.* batch cases.

6. Transports (shared, unchanged by T12)
   pkg/deltascope/audit.go blob 4cfb78d6… Audit L297
   internal/interfaces/cli/audit.go blob b613e964… newAuditCmd L54
   internal/interfaces/http/handler.go blob 1e6e581c… handleAudit L554
   internal/interfaces/mcp/audit_tool.go blob e0cb1fba… newAuditSQLTool L38 / auditSQLWithMetadata L112

7. T11 boundary
   internal/application/audit/batch_state_fk.go foreignKeyReferActionPremise — unchanged;
   DROP CONSTRAINT dispatch keeps T11's check-vs-FK separation; TiDB DROP CONSTRAINT fk warned-noop preserved (T11 golden re-run).
