# T12 decision-record binding

- docs/decisions/2026-10-30-ddl-check-constraint-enforcement-state.md — primary T12 decision (enforcement-state semantics, arm model, version gates)
- docs/decisions/2026-10-25-ddl-unified-constraint-checks.md — blob 169ed214fe24ab958247828ed16ffb11f5a92870 — T11/T12 shared constraint model (also records T12 safety/P2-2 remediation evidence per ledger commits a7c3cbb6, 56b04308)
- docs/decisions/2026-11-13-ddl-golden-credential-privacy.md — blob bb40bfb617b2ef43f05b3adeb45e8f768e16f1ab — golden credential-privacy contract governing this evidence
- docs/decisions/2026-11-18-ddl-inventory-status-model-v2.md — inventory status model used by t12-inventory-binding.md
Bound as existing records; no new decision record was required for an evidence-only round.
