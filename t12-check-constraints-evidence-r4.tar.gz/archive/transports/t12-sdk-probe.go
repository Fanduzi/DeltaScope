package main

import (
	"context"
	"database/sql"
	"fmt"
	"os"

	"github.com/Fanduzi/DeltaScope/internal/domain/spec"
	metamysql "github.com/Fanduzi/DeltaScope/internal/infrastructure/metadata/mysql"
	"github.com/Fanduzi/DeltaScope/pkg/deltascope"
	_ "github.com/go-sql-driver/mysql"
)

type providerAdapter struct{ p *metamysql.Provider }

func (a providerAdapter) LoadInstanceFacts(ctx context.Context, d deltascope.Dialect, s string) (*deltascope.InstanceFacts, error) {
	return a.p.LoadInstanceFacts(ctx, spec.Dialect(d), s)
}
func (a providerAdapter) LoadTableSnapshot(ctx context.Context, d deltascope.Dialect, s string, t string) (*deltascope.TableSnapshot, error) {
	return a.p.LoadTableSnapshot(ctx, spec.Dialect(d), s, t)
}

func main() {
	dsn := fmt.Sprintf("root:%s@tcp(127.0.0.1:19980)/golden?timeout=5s", os.Getenv("DS_T12_PARITY_PW"))
	db, err := sql.Open("mysql", dsn)
	if err != nil { fmt.Println("open:", err); os.Exit(2) }
	defer db.Close()
	res, err := deltascope.Audit(context.Background(), deltascope.Request{
		SQL:              "ALTER TABLE t12g ALTER CHECK chk_id NOT ENFORCED;",
		Schema:           "golden",
		MetadataProvider: providerAdapter{metamysql.NewProvider(db)},
		ConfigPath:       os.Args[1],
	})
	if err != nil { fmt.Println("err:", err); os.Exit(3) }
	fmt.Println("verdict:", res.Verdict)
	fmt.Println("coverage:", res.Coverage.Status)
	for _, s := range res.Statements {
		for _, f := range s.Findings { fmt.Println("finding:", f.RuleID, f.Level) }
	}
}
