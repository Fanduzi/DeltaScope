import json
A=json.load(open('/tmp/t13-r2-archive/archive/golden/artifact-r1.json'))
def esc(s):
    return s.replace('\\','\\\\').replace('|','\\|').replace('\r\n','\\n').replace('\n','\\n').replace('\r','\\n')
def sqlcell(v):
    if isinstance(v,list): return '['+', '.join(repr(esc(x)) for x in v)+']'
    return esc(v)
def fl(entries): return '['+', '.join(repr(e['rule_id']+'/'+e['level']) for e in entries)+']'
def afindings(p):
    out=[]
    for st in p.get('statements',[]):
        for f in st.get('findings',[]): out.append({'rule_id':f['rule_id'],'level':f['level']})
    return out
def agaps(p): return sum(len(st.get('evidence_gaps',[])) for st in p.get('statements',[]))
MODE={'db_ddl':'db','db_syntax_negative':'db','cli_metadata':'metadata-aware','cli_audit':'offline'}
rows=[]
for c in A['cases']:
    k=c['kind'];p=c['actual'].get('parsed');e=c['expected'];db=k.startswith('db_')
    schema='golden' if k=='cli_metadata' else '-'
    policy=c.get('policy_profile','-') if not db else '-'
    sql=sqlcell(c['input_sql'])
    ve=f"{e.get('verdict','N/A')}/{(p or {}).get('verdict','N/A')}"
    ce=f"{e.get('coverage','N/A')}/{(p or {}).get('coverage',{}).get('status','N/A')}"
    fe=fl(e.get('finding_entries',[])) if not db else '[]'
    fa=fl(afindings(p)) if p else '[]'
    ge=e.get('evidence_gaps','N/A') if not db else 0
    ga=agaps(p) if p else 'N/A'
    xe=f"{e.get('exit','N/A')}/{c['actual'].get('exit','N/A')}"
    rows.append([c['case_id'],k,c.get('anchor',c.get('dialect','')),MODE[k],schema,policy,sql,ve,ce,fe,fa,f'{ge}/{ga}',xe,str(len(c['assertions'])),'artifact-r1.json#'+c['case_id'],c['status']])
lines=['# T13 acceptance matrix R3 — actuals from artifact `actual.parsed`/`actual` real fields (never copied from expected)',
 'required==executed==matrix: 47==47==47 | assertions=709 | duplicates=0 missing=0 extra=0',
 'SQL cells: literal `\\n` marks statement-breaking newlines (order preserved); `\\|` escapes pipes.',
 '| case_id | kind | anchor/dialect | mode | schema | policy | SQL | verdict_e/a | cov_e/a | findings_e | findings_a | gaps_e/a | exit_e/a | asserts | raw | status |']
for r in rows: lines.append('| '+' | '.join(r)+' |')
open('/tmp/t13-r3-archive/archive/matrix/acceptance-matrix-r3.md','w').write('\n'.join(lines)+'\n')
print('rows',len(rows),'asserts_total',sum(len(c['assertions']) for c in A['cases']))
