# T13 acceptance matrix R2 — actuals from artifact `actual.parsed`/`actual` real fields (never copied from expected)
required==executed==matrix: 47==47==47 | assertions=709 | duplicates=0 missing=0 extra=0
| case_id | kind | anchor/dialect | mode | schema | policy | SQL | verdict_e/a | cov_e/a | findings_e | findings_a | gaps_e/a | exit_e/a | asserts | raw | status |
| T13.db.mysql57.ddl | db_ddl | mysql57 | db | - | - | ['CREATE TABLE t13g (id INT, c INT) PARTITION BY RANGE (id) (PARTITION p0 VALUES | N/A/N/A | N/A/N/A | [] | [] | 0/N/A | N/A/N/A | 23 | artifact-r1.json#T13.db.mysql57.ddl | pass |
| T13.db.mysql57.syntax_negative | db_syntax_negative | mysql57 | db | - | - | ALTER TABLE t13g DROP PARTITION ( | N/A/N/A | N/A/N/A | [] | [] | 0/N/A | N/A/N/A | 3 | artifact-r1.json#T13.db.mysql57.syntax_negative | pass |
| T13.db.mysql80.ddl | db_ddl | mysql80 | db | - | - | ['CREATE TABLE t13g (id INT, c INT) PARTITION BY RANGE (id) (PARTITION p0 VALUES | N/A/N/A | N/A/N/A | [] | [] | 0/N/A | N/A/N/A | 23 | artifact-r1.json#T13.db.mysql80.ddl | pass |
| T13.db.mysql80.syntax_negative | db_syntax_negative | mysql80 | db | - | - | ALTER TABLE t13g DROP PARTITION ( | N/A/N/A | N/A/N/A | [] | [] | 0/N/A | N/A/N/A | 3 | artifact-r1.json#T13.db.mysql80.syntax_negative | pass |
| T13.db.mysql84.ddl | db_ddl | mysql84 | db | - | - | ['CREATE TABLE t13g (id INT, c INT) PARTITION BY RANGE (id) (PARTITION p0 VALUES | N/A/N/A | N/A/N/A | [] | [] | 0/N/A | N/A/N/A | 23 | artifact-r1.json#T13.db.mysql84.ddl | pass |
| T13.db.mysql84.syntax_negative | db_syntax_negative | mysql84 | db | - | - | ALTER TABLE t13g DROP PARTITION ( | N/A/N/A | N/A/N/A | [] | [] | 0/N/A | N/A/N/A | 3 | artifact-r1.json#T13.db.mysql84.syntax_negative | pass |
| T13.db.tidb85.ddl | db_ddl | tidb85 | db | - | - | ['CREATE TABLE t13g (id INT, c INT) PARTITION BY RANGE (id) (PARTITION p0 VALUES | N/A/N/A | N/A/N/A | [] | [] | 0/N/A | N/A/N/A | 24 | artifact-r1.json#T13.db.tidb85.ddl | pass |
| T13.db.tidb85.syntax_negative | db_syntax_negative | tidb85 | db | - | - | ALTER TABLE t13g DROP PARTITION ( | N/A/N/A | N/A/N/A | [] | [] | 0/N/A | N/A/N/A | 3 | artifact-r1.json#T13.db.tidb85.syntax_negative | pass |
| T13.cli.t13-cli-drop-partition-blocker | cli_audit | mysql | offline | - | t13-drop | ALTER TABLE t DROP PARTITION p0; | reject/reject | complete/complete | ['ddl.alter.drop_partition.forbid/blocker'] | ['ddl.alter.drop_partition.forbid/blocker'] | 0/0 | 1/1 | 12 | artifact-r1.json#T13.cli.t13-cli-drop-partition-blocker | pass |
| T13.cli.t13-cli-drop-partition-tidb-blocker | cli_audit | tidb | offline | - | t13-drop | ALTER TABLE t DROP PARTITION p0; | reject/reject | complete/complete | ['ddl.alter.drop_partition.forbid/blocker'] | ['ddl.alter.drop_partition.forbid/blocker'] | 0/0 | 1/1 | 12 | artifact-r1.json#T13.cli.t13-cli-drop-partition-tidb-blocker | pass |
| T13.cli.t13-cli-drop-partition-multi | cli_audit | mysql | offline | - | t13-drop | ALTER TABLE t DROP PARTITION p0, p1; | reject/reject | complete/complete | ['ddl.alter.drop_partition.forbid/blocker', 'ddl.alter.drop_partition.forbid/blocker'] | ['ddl.alter.drop_partition.forbid/blocker', 'ddl.alter.drop_partition.forbid/blocker'] | 0/0 | 1/1 | 11 | artifact-r1.json#T13.cli.t13-cli-drop-partition-multi | pass |
| T13.cli.t13-cli-drop-partition-off | cli_audit | mysql | offline | - | all-rules-disabled | ALTER TABLE t DROP PARTITION p0; | pass/pass | complete/complete | [] | [] | 0/0 | 0/0 | 8 | artifact-r1.json#T13.cli.t13-cli-drop-partition-off | pass |
| T13.cli.t13-cli-truncate-partition-blocker | cli_audit | mysql | offline | - | t13-truncate | ALTER TABLE t TRUNCATE PARTITION p0; | reject/reject | complete/complete | ['ddl.alter.truncate_partition.forbid/blocker'] | ['ddl.alter.truncate_partition.forbid/blocker'] | 0/0 | 1/1 | 11 | artifact-r1.json#T13.cli.t13-cli-truncate-partition-blocker | pass |
| T13.cli.t13-cli-truncate-partition-all | cli_audit | tidb | offline | - | t13-truncate | ALTER TABLE t TRUNCATE PARTITION ALL; | reject/reject | complete/complete | ['ddl.alter.truncate_partition.forbid/blocker'] | ['ddl.alter.truncate_partition.forbid/blocker'] | 0/0 | 1/1 | 11 | artifact-r1.json#T13.cli.t13-cli-truncate-partition-all | pass |
| T13.cli.t13-cli-exchange-warn | cli_audit | mysql | offline | - | t13-exchange | ALTER TABLE t EXCHANGE PARTITION p0 WITH TABLE t2; | review/review | complete/complete | ['ddl.alter.exchange_partition.warn/warning'] | ['ddl.alter.exchange_partition.warn/warning'] | 0/0 | 0/0 | 11 | artifact-r1.json#T13.cli.t13-cli-exchange-warn | pass |
| T13.cli.t13-cli-exchange-noval-fail-on-warning | cli_audit | tidb | offline | - | t13-exchange | ALTER TABLE t EXCHANGE PARTITION p0 WITH TABLE t2 WITHOUT VALIDATION; | review/review | complete/complete | ['ddl.alter.exchange_partition.warn/warning'] | ['ddl.alter.exchange_partition.warn/warning'] | 0/0 | 1/1 | 12 | artifact-r1.json#T13.cli.t13-cli-exchange-noval-fail-on-warning | pass |
| T13.cli.t13-cli-exchange-qualified | cli_audit | mysql | offline | - | t13-exchange | ALTER TABLE t EXCHANGE PARTITION p0 WITH TABLE s2.t2; | review/review | complete/complete | [] | ['ddl.alter.exchange_partition.warn/warning'] | 0/0 | 0/0 | 9 | artifact-r1.json#T13.cli.t13-cli-exchange-qualified | pass |
| T13.cli.t13-cli-exchange-protected-other-side | cli_audit | mysql | offline | - | t13-deny-x | ALTER TABLE t EXCHANGE PARTITION p0 WITH TABLE t13x; | reject/reject | complete/complete | ['ddl.table.denylist.forbid/blocker'] | ['ddl.table.denylist.forbid/blocker'] | 0/0 | 1/1 | 11 | artifact-r1.json#T13.cli.t13-cli-exchange-protected-other-side | pass |
| T13.cli.t13-cli-exchange-protected-left | cli_audit | mysql | offline | - | t13-deny-t | ALTER TABLE t EXCHANGE PARTITION p0 WITH TABLE t13x; | reject/reject | complete/complete | ['ddl.table.denylist.forbid/blocker'] | ['ddl.table.denylist.forbid/blocker'] | 0/0 | 1/1 | 11 | artifact-r1.json#T13.cli.t13-cli-exchange-protected-left | pass |
| T13.cli.t13-cli-addcol-control | cli_audit | mysql | offline | - | t13-drop | ALTER TABLE t ADD COLUMN c INT; | pass/pass | complete/complete | [] | [] | 0/0 | 0/0 | 9 | artifact-r1.json#T13.cli.t13-cli-addcol-control | pass |
| T13.cli.t13-cli-mixed-refusal | cli_audit | mysql | offline | - | t13-drop | ALTER TABLE t ADD COLUMN x INT, DROP PARTITION p0; | reject/reject | complete/complete | ['ddl.alter.drop_partition.forbid/blocker'] | ['ddl.alter.drop_partition.forbid/blocker'] | 0/0 | 1/1 | 10 | artifact-r1.json#T13.cli.t13-cli-mixed-refusal | pass |
| T13.cli.t13r1-cli-drop-applicability-gap | cli_audit | mysql | offline | - | t13r1-drop-applicability | ALTER TABLE t DROP PARTITION p0; | review/review | unverified/unverified | [] | [] | 1/1 | 0/0 | 13 | artifact-r1.json#T13.cli.t13r1-cli-drop-applicability-gap | pass |
| T13.cli.t13r1-cli-drop-applicability-gap-tidb | cli_audit | tidb | offline | - | t13r1-drop-applicability | ALTER TABLE t DROP PARTITION p0; | review/review | unverified/unverified | [] | [] | 1/1 | 0/0 | 13 | artifact-r1.json#T13.cli.t13r1-cli-drop-applicability-gap-tidb | pass |
| T13.cli.t13r1-cli-exchange-counterpart-gap | cli_audit | mysql | offline | - | t13r1-exchange-counterpart | ALTER TABLE t EXCHANGE PARTITION p0 WITH TABLE t2; | review/review | unverified/unverified | [] | [] | 1/1 | 0/0 | 13 | artifact-r1.json#T13.cli.t13r1-cli-exchange-counterpart-gap | pass |
| T13.cli.t13r2-cli-inplace-drop-noversion-unsupported | cli_audit | mysql | offline | - | t13r1-drop-target | ALTER TABLE t ALGORITHM=INPLACE, DROP PARTITION p0; | review/review | incomplete/incomplete | [] | [] | 1/1 | 1/1 | 16 | artifact-r1.json#T13.cli.t13r2-cli-inplace-drop-noversion-unsupported | pass |
| T13.meta.t13-mysql80-golden | cli_metadata | mysql80 | metadata-aware | golden | t13-drop | ALTER TABLE t13g DROP PARTITION p0; | reject/reject | complete/complete | ['ddl.alter.drop_partition.forbid/blocker'] | ['ddl.alter.drop_partition.forbid/blocker'] | 0/0 | 1/1 | 20 | artifact-r1.json#T13.meta.t13-mysql80-golden | pass |
| T13.meta.t13-tidb85-golden | cli_metadata | tidb85 | metadata-aware | golden | t13-drop | ALTER TABLE t13g DROP PARTITION p0; | reject/reject | complete/complete | ['ddl.alter.drop_partition.forbid/blocker'] | ['ddl.alter.drop_partition.forbid/blocker'] | 0/0 | 1/1 | 20 | artifact-r1.json#T13.meta.t13-tidb85-golden | pass |
| T13.meta.t13-mysql80-exchange-protected-other-side | cli_metadata | mysql80 | metadata-aware | golden | t13-deny-x | ALTER TABLE t13g EXCHANGE PARTITION p1 WITH TABLE t13x; | reject/reject | complete/complete | ['ddl.table.denylist.forbid/blocker'] | ['ddl.table.denylist.forbid/blocker'] | 0/0 | 1/1 | 18 | artifact-r1.json#T13.meta.t13-mysql80-exchange-protected-other-side | pass |
| T13.meta.t13r1-mysql80-drop-nonpartitioned | cli_metadata | mysql80 | metadata-aware | golden | t13r1-drop-applicability | ALTER TABLE t13np DROP PARTITION p0; | reject/reject | complete/complete | ['ddl.alter.drop_partition.applicability/blocker'] | ['ddl.alter.drop_partition.applicability/blocker'] | 0/0 | 1/1 | 19 | artifact-r1.json#T13.meta.t13r1-mysql80-drop-nonpartitioned | pass |
| T13.meta.t13r1-tidb85-drop-hash | cli_metadata | tidb85 | metadata-aware | golden | t13r1-drop-applicability | ALTER TABLE t13h DROP PARTITION p0; | reject/reject | complete/complete | ['ddl.alter.drop_partition.applicability/blocker'] | ['ddl.alter.drop_partition.applicability/blocker'] | 0/0 | 1/1 | 19 | artifact-r1.json#T13.meta.t13r1-tidb85-drop-hash | pass |
| T13.meta.t13r1-mysql80-drop-partition-absent | cli_metadata | mysql80 | metadata-aware | golden | t13r1-drop-target | ALTER TABLE t13r DROP PARTITION p99; | reject/reject | complete/complete | ['ddl.alter.drop_partition.target/blocker'] | ['ddl.alter.drop_partition.target/blocker'] | 0/0 | 1/1 | 19 | artifact-r1.json#T13.meta.t13r1-mysql80-drop-partition-absent | pass |
| T13.meta.t13r1-tidb85-truncate-partition-absent | cli_metadata | tidb85 | metadata-aware | golden | t13r1-truncate-target | ALTER TABLE t13r TRUNCATE PARTITION p99; | reject/reject | complete/complete | ['ddl.alter.truncate_partition.target/blocker'] | ['ddl.alter.truncate_partition.target/blocker'] | 0/0 | 1/1 | 19 | artifact-r1.json#T13.meta.t13r1-tidb85-truncate-partition-absent | pass |
| T13.meta.t13r1-mysql80-exchange-counterpart-absent | cli_metadata | mysql80 | metadata-aware | golden | t13r1-exchange-counterpart | ALTER TABLE t13e EXCHANGE PARTITION p0 WITH TABLE t13miss; | reject/reject | complete/complete | ['ddl.alter.exchange_partition.counterpart/blocker'] | ['ddl.alter.exchange_partition.counterpart/blocker'] | 0/0 | 1/1 | 19 | artifact-r1.json#T13.meta.t13r1-mysql80-exchange-counterpart-absent | pass |
| T13.meta.t13r1-mysql80-exchange-counterpart-partitioned | cli_metadata | mysql80 | metadata-aware | golden | t13r1-exchange-counterpart | ALTER TABLE t13e EXCHANGE PARTITION p0 WITH TABLE t13cp; | reject/reject | complete/complete | ['ddl.alter.exchange_partition.counterpart/blocker'] | ['ddl.alter.exchange_partition.counterpart/blocker'] | 0/0 | 1/1 | 19 | artifact-r1.json#T13.meta.t13r1-mysql80-exchange-counterpart-partitioned | pass |
| T13.meta.t13r1-mysql80-exchange-def-mismatch | cli_metadata | mysql80 | metadata-aware | golden | t13r1-exchange-counterpart | ALTER TABLE t13e EXCHANGE PARTITION p0 WITH TABLE t13m; | reject/reject | complete/complete | ['ddl.alter.exchange_partition.counterpart/blocker'] | ['ddl.alter.exchange_partition.counterpart/blocker'] | 0/0 | 1/1 | 19 | artifact-r1.json#T13.meta.t13r1-mysql80-exchange-def-mismatch | pass |
| T13.meta.t13r1-mysql80-exchange-clears-counterpart-stats | cli_metadata | mysql80 | metadata-aware | golden | t13r1-truncate-rows | ALTER TABLE t13e EXCHANGE PARTITION p0 WITH TABLE t13c WITHOUT VALIDATION; TRUNC | pass/pass | complete/complete | [] | [] | 0/0 | 0/0 | 20 | artifact-r1.json#T13.meta.t13r1-mysql80-exchange-clears-counterpart-stats | pass |
| T13.meta.t13r1-mysql80-truncate-rows-control | cli_metadata | mysql80 | metadata-aware | golden | t13r1-truncate-rows | TRUNCATE TABLE t13c; | reject/reject | complete/complete | ['ddl.table.truncate.rows.max_count/blocker'] | ['ddl.table.truncate.rows.max_count/blocker'] | 0/0 | 1/1 | 18 | artifact-r1.json#T13.meta.t13r1-mysql80-truncate-rows-control | pass |
| T13.meta.t13r1-mysql57-algorithm-drop-refused | cli_metadata | mysql57 | metadata-aware | golden | t13r1-truncate-rows | ALTER TABLE t13a ALGORITHM=INPLACE, DROP PARTITION p0; TRUNCATE TABLE t13a; | reject/reject | complete/complete | ['ddl.table.truncate.rows.max_count/blocker'] | ['ddl.table.truncate.rows.max_count/blocker'] | 0/0 | 1/1 | 21 | artifact-r1.json#T13.meta.t13r1-mysql57-algorithm-drop-refused | pass |
| T13.meta.t13r1-mysql80-algorithm-drop-executes | cli_metadata | mysql80 | metadata-aware | golden | t13r1-truncate-rows | ALTER TABLE t13a ALGORITHM=INPLACE, DROP PARTITION p0; TRUNCATE TABLE t13a; | pass/pass | complete/complete | [] | [] | 0/0 | 0/0 | 18 | artifact-r1.json#T13.meta.t13r1-mysql80-algorithm-drop-executes | pass |
| T13.meta.t13r2-mysql80-exchange-engine-mismatch | cli_metadata | mysql80 | metadata-aware | golden | t13r1-exchange-counterpart | ALTER TABLE t13e EXCHANGE PARTITION p0 WITH TABLE t13g; | reject/reject | complete/complete | ['ddl.alter.exchange_partition.counterpart/blocker'] | ['ddl.alter.exchange_partition.counterpart/blocker'] | 0/0 | 1/1 | 19 | artifact-r1.json#T13.meta.t13r2-mysql80-exchange-engine-mismatch | pass |
| T13.meta.t13r2-tidb85-exchange-engine-normalized | cli_metadata | tidb85 | metadata-aware | golden | t13r1-exchange-counterpart | ALTER TABLE t13e EXCHANGE PARTITION p0 WITH TABLE t13g; | pass/pass | complete/complete | [] | [] | 0/0 | 0/0 | 17 | artifact-r1.json#T13.meta.t13r2-tidb85-exchange-engine-normalized | pass |
| T13.meta.t13r2-mysql80-drop-then-truncate-absent | cli_metadata | mysql80 | metadata-aware | golden | t13r1-truncate-target | ALTER TABLE t13e DROP PARTITION p0;
ALTER TABLE t13e TRUNCATE PARTITION p0; | reject/reject | complete/complete | ['ddl.alter.truncate_partition.target/blocker'] | ['ddl.alter.truncate_partition.target/blocker'] | 0/0 | 1/1 | 19 | artifact-r1.json#T13.meta.t13r2-mysql80-drop-then-truncate-absent | pass |
| T13.meta.t13r2-mysql80-drop-then-truncate-survives | cli_metadata | mysql80 | metadata-aware | golden | t13r1-truncate-target | ALTER TABLE t13e DROP PARTITION p0;
ALTER TABLE t13e TRUNCATE PARTITION p1; | pass/pass | complete/complete | [] | [] | 0/0 | 0/0 | 18 | artifact-r1.json#T13.meta.t13r2-mysql80-drop-then-truncate-survives | pass |
| T13.meta.t13r2-mysql80-exchange-subpartition-leaf-gap | cli_metadata | mysql80 | metadata-aware | golden | t13r1-exchange-target | ALTER TABLE t13sp EXCHANGE PARTITION p0sp0 WITH TABLE t13spx; | review/review | unverified/unverified | [] | [] | 1/1 | 0/0 | 19 | artifact-r1.json#T13.meta.t13r2-mysql80-exchange-subpartition-leaf-gap | pass |
| T13.meta.t13r2-tidb85-interval-generated-member | cli_metadata | tidb85 | metadata-aware | golden | t13r1-truncate-target | ALTER TABLE t13i TRUNCATE PARTITION p_lt_10; | pass/pass | complete/complete | [] | [] | 0/0 | 0/0 | 16 | artifact-r1.json#T13.meta.t13r2-tidb85-interval-generated-member | pass |
| T13.meta.t13r3-mysql80-hash-drop-keeps-directory | cli_metadata | mysql80 | metadata-aware | golden | t13r1-truncate-target | ALTER TABLE t13h DROP PARTITION p0;
ALTER TABLE t13h TRUNCATE PARTITION p0; | pass/pass | complete/complete | [] | [] | 0/0 | 0/0 | 19 | artifact-r1.json#T13.meta.t13r3-mysql80-hash-drop-keeps-directory | pass |
| T13.meta.t13r3-mysql80-exchange-decimal-effective | cli_metadata | mysql80 | metadata-aware | golden | t13r1-exchange-counterpart | ALTER TABLE t13d EXCHANGE PARTITION p0 WITH TABLE t13x; | pass/pass | complete/complete | [] | [] | 0/0 | 0/0 | 16 | artifact-r1.json#T13.meta.t13r3-mysql80-exchange-decimal-effective | pass |

## db_* case native-step detail (rc/stdout/results per anchor)

### T13.db.mysql57.ddl (verdict N/A — db case asserts native steps, not audit output)
- step0: `CREATE TABLE t13g (id INT, c INT) PARTITION BY RANGE (id) (PARTITION p0 VALUES LESS THAN (100), PARTITION p1 VALUES LESS THAN (200))`
- step1: `INSERT INTO t13g VALUES (10, 1), (150, 2)`
- step2: `ALTER TABLE t13g DROP PARTITION p0`
- step3: `ALTER TABLE t13g TRUNCATE PARTITION p1`
- step4: `CREATE TABLE t13x (id INT, c INT)`
- step5: `INSERT INTO t13x VALUES (160, 9)`
- step6: `ALTER TABLE t13g EXCHANGE PARTITION p1 WITH TABLE t13x WITHOUT VALIDATION`
- step7: `DROP TABLE t13g, t13x`
  - [ok] database reachable with expected version: SELECT VERSION() rc=0 version='5.7.44' expected_contains='5.7.44'
  - [ok] create-partitioned-fixture return code: rc=0 expected=0 stderr=''
  - [ok] create-partitioned-fixture: range fixture lands with two named partitions on every anchor: rc=0 output='2' expected='2'
  - [ok] seed-partition-rows return code: rc=0 expected=0 stderr=''
  - [ok] seed-partition-rows: the p1-range row lands: rc=0 output='1' expected='1'
  - [ok] drop-partition-p0 return code: rc=0 expected=0 stderr=''
  - [ok] drop-partition-p0: p0 definition is gone after DROP PARTITION: rc=0 output='0' expected='0'
  - [ok] drop-partition-p0: p1's row survives the drop: rc=0 output='1' expected='1'
  - [ok] truncate-partition-p1 return code: rc=0 expected=0 stderr=''
  - [ok] truncate-partition-p1: p1 definition survives TRUNCATE while its rows are gone: rc=0 output='1' expected='1'
  - [ok] truncate-partition-p1: no rows remain in the table after both partitions emptied: rc=0 output='0' expected='0'
  - [ok] create-exchange-counterpart return code: rc=0 expected=0 stderr=''
  - [ok] create-exchange-counterpart: exchange counterpart is a plain non-partitioned table: rc=0 output='0' expected='0'
  - [ok] seed-exchange-row return code: rc=0 expected=0 stderr=''
  - [ok] seed-exchange-row: counterpart row lands inside p1 range (100 <= 160 < 200): rc=0 output='1' expected='1'
  - [ok] exchange-partition-p1 return code: rc=0 expected=0 stderr=''
  - [ok] exchange-partition-p1: the counterpart row moved into the partitioned table: rc=0 output='1' expected='1'
  - [ok] exchange-partition-p1: the counterpart is empty after the swap: rc=0 output='0' expected='0'
  - [ok] cleanup return code: rc=0 expected=0 stderr=''
  - [ok] cleanup: fixtures removed: rc=0 output='0' expected='0'
  - [ok] image digest matches locked baseline: locked='mysql@sha256:4bc6bc963e6d8443453676cae56536f4b8156d78bae03c0145cbe47c2aad73bb' resolved=['mysql@sha256:4bc6bc963e6d8443453676cae5653
  - [ok] running container image identity: container='sha256:4bc6bc963e6d8443453676cae56536f4b8156d78bae03c0145cbe47c2aad73bb' image_id='sha256:4bc6bc963e6d8443453676cae56536f4b8156d7
  - [ok] platform recorded and matches baseline: platform='linux/amd64' locked='linux/amd64'

### T13.db.mysql57.syntax_negative (verdict N/A — db case asserts native steps, not audit output)
- step0: `ALTER TABLE t13g DROP PARTITION (`
  - [ok] nonzero syntax failure: rc=1
  - [ok] expected error class: error_class='1064' expected='1064'
  - [ok] no permission/connection/object-conflict markers: forbidden markers found: []

### T13.db.mysql80.ddl (verdict N/A — db case asserts native steps, not audit output)
- step0: `CREATE TABLE t13g (id INT, c INT) PARTITION BY RANGE (id) (PARTITION p0 VALUES LESS THAN (100), PARTITION p1 VALUES LESS THAN (200))`
- step1: `INSERT INTO t13g VALUES (10, 1), (150, 2)`
- step2: `ALTER TABLE t13g DROP PARTITION p0`
- step3: `ALTER TABLE t13g TRUNCATE PARTITION p1`
- step4: `CREATE TABLE t13x (id INT, c INT)`
- step5: `INSERT INTO t13x VALUES (160, 9)`
- step6: `ALTER TABLE t13g EXCHANGE PARTITION p1 WITH TABLE t13x WITHOUT VALIDATION`
- step7: `DROP TABLE t13g, t13x`
  - [ok] database reachable with expected version: SELECT VERSION() rc=0 version='8.0.46' expected_contains='8.0.46'
  - [ok] create-partitioned-fixture return code: rc=0 expected=0 stderr=''
  - [ok] create-partitioned-fixture: range fixture lands with two named partitions on every anchor: rc=0 output='2' expected='2'
  - [ok] seed-partition-rows return code: rc=0 expected=0 stderr=''
  - [ok] seed-partition-rows: the p1-range row lands: rc=0 output='1' expected='1'
  - [ok] drop-partition-p0 return code: rc=0 expected=0 stderr=''
  - [ok] drop-partition-p0: p0 definition is gone after DROP PARTITION: rc=0 output='0' expected='0'
  - [ok] drop-partition-p0: p1's row survives the drop: rc=0 output='1' expected='1'
  - [ok] truncate-partition-p1 return code: rc=0 expected=0 stderr=''
  - [ok] truncate-partition-p1: p1 definition survives TRUNCATE while its rows are gone: rc=0 output='1' expected='1'
  - [ok] truncate-partition-p1: no rows remain in the table after both partitions emptied: rc=0 output='0' expected='0'
  - [ok] create-exchange-counterpart return code: rc=0 expected=0 stderr=''
  - [ok] create-exchange-counterpart: exchange counterpart is a plain non-partitioned table: rc=0 output='0' expected='0'
  - [ok] seed-exchange-row return code: rc=0 expected=0 stderr=''
  - [ok] seed-exchange-row: counterpart row lands inside p1 range (100 <= 160 < 200): rc=0 output='1' expected='1'
  - [ok] exchange-partition-p1 return code: rc=0 expected=0 stderr=''
  - [ok] exchange-partition-p1: the counterpart row moved into the partitioned table: rc=0 output='1' expected='1'
  - [ok] exchange-partition-p1: the counterpart is empty after the swap: rc=0 output='0' expected='0'
  - [ok] cleanup return code: rc=0 expected=0 stderr=''
  - [ok] cleanup: fixtures removed: rc=0 output='0' expected='0'
  - [ok] image digest matches locked baseline: locked='mysql@sha256:7dcddc01f13bab2f15cde676d44d01f61fc9f99fe7785e86196dfc07d358ae2b' resolved=['mysql@sha256:7dcddc01f13bab2f15cde676d44d0
  - [ok] running container image identity: container='sha256:7dcddc01f13bab2f15cde676d44d01f61fc9f99fe7785e86196dfc07d358ae2b' image_id='sha256:7dcddc01f13bab2f15cde676d44d01f61fc9f99
  - [ok] platform recorded and matches baseline: platform='linux/arm64' locked='linux/arm64'

### T13.db.mysql80.syntax_negative (verdict N/A — db case asserts native steps, not audit output)
- step0: `ALTER TABLE t13g DROP PARTITION (`
  - [ok] nonzero syntax failure: rc=1
  - [ok] expected error class: error_class='1064' expected='1064'
  - [ok] no permission/connection/object-conflict markers: forbidden markers found: []

### T13.db.mysql84.ddl (verdict N/A — db case asserts native steps, not audit output)
- step0: `CREATE TABLE t13g (id INT, c INT) PARTITION BY RANGE (id) (PARTITION p0 VALUES LESS THAN (100), PARTITION p1 VALUES LESS THAN (200))`
- step1: `INSERT INTO t13g VALUES (10, 1), (150, 2)`
- step2: `ALTER TABLE t13g DROP PARTITION p0`
- step3: `ALTER TABLE t13g TRUNCATE PARTITION p1`
- step4: `CREATE TABLE t13x (id INT, c INT)`
- step5: `INSERT INTO t13x VALUES (160, 9)`
- step6: `ALTER TABLE t13g EXCHANGE PARTITION p1 WITH TABLE t13x WITHOUT VALIDATION`
- step7: `DROP TABLE t13g, t13x`
  - [ok] database reachable with expected version: SELECT VERSION() rc=0 version='8.4.10' expected_contains='8.4.10'
  - [ok] create-partitioned-fixture return code: rc=0 expected=0 stderr=''
  - [ok] create-partitioned-fixture: range fixture lands with two named partitions on every anchor: rc=0 output='2' expected='2'
  - [ok] seed-partition-rows return code: rc=0 expected=0 stderr=''
  - [ok] seed-partition-rows: the p1-range row lands: rc=0 output='1' expected='1'
  - [ok] drop-partition-p0 return code: rc=0 expected=0 stderr=''
  - [ok] drop-partition-p0: p0 definition is gone after DROP PARTITION: rc=0 output='0' expected='0'
  - [ok] drop-partition-p0: p1's row survives the drop: rc=0 output='1' expected='1'
  - [ok] truncate-partition-p1 return code: rc=0 expected=0 stderr=''
  - [ok] truncate-partition-p1: p1 definition survives TRUNCATE while its rows are gone: rc=0 output='1' expected='1'
  - [ok] truncate-partition-p1: no rows remain in the table after both partitions emptied: rc=0 output='0' expected='0'
  - [ok] create-exchange-counterpart return code: rc=0 expected=0 stderr=''
  - [ok] create-exchange-counterpart: exchange counterpart is a plain non-partitioned table: rc=0 output='0' expected='0'
  - [ok] seed-exchange-row return code: rc=0 expected=0 stderr=''
  - [ok] seed-exchange-row: counterpart row lands inside p1 range (100 <= 160 < 200): rc=0 output='1' expected='1'
  - [ok] exchange-partition-p1 return code: rc=0 expected=0 stderr=''
  - [ok] exchange-partition-p1: the counterpart row moved into the partitioned table: rc=0 output='1' expected='1'
  - [ok] exchange-partition-p1: the counterpart is empty after the swap: rc=0 output='0' expected='0'
  - [ok] cleanup return code: rc=0 expected=0 stderr=''
  - [ok] cleanup: fixtures removed: rc=0 output='0' expected='0'
  - [ok] image digest matches locked baseline: locked='mysql@sha256:8dbcf531a03aade657e181b9cf2f1d1803ce621a1d55610cb44cb531ab7d7db6' resolved=['mysql@sha256:8dbcf531a03aade657e181b9cf2f1
  - [ok] running container image identity: container='sha256:8dbcf531a03aade657e181b9cf2f1d1803ce621a1d55610cb44cb531ab7d7db6' image_id='sha256:8dbcf531a03aade657e181b9cf2f1d1803ce621
  - [ok] platform recorded and matches baseline: platform='linux/arm64' locked='linux/arm64'

### T13.db.mysql84.syntax_negative (verdict N/A — db case asserts native steps, not audit output)
- step0: `ALTER TABLE t13g DROP PARTITION (`
  - [ok] nonzero syntax failure: rc=1
  - [ok] expected error class: error_class='1064' expected='1064'
  - [ok] no permission/connection/object-conflict markers: forbidden markers found: []

### T13.db.tidb85.ddl (verdict N/A — db case asserts native steps, not audit output)
- step0: `CREATE TABLE t13g (id INT, c INT) PARTITION BY RANGE (id) (PARTITION p0 VALUES LESS THAN (100), PARTITION p1 VALUES LESS THAN (200))`
- step1: `INSERT INTO t13g VALUES (10, 1), (150, 2)`
- step2: `ALTER TABLE t13g DROP PARTITION p0`
- step3: `ALTER TABLE t13g TRUNCATE PARTITION p1`
- step4: `CREATE TABLE t13x (id INT, c INT)`
- step5: `INSERT INTO t13x VALUES (160, 9)`
- step6: `ALTER TABLE t13g EXCHANGE PARTITION p1 WITH TABLE t13x WITHOUT VALIDATION`
- step7: `DROP TABLE t13g, t13x`
  - [ok] database reachable with expected version: SELECT VERSION() rc=0 version='8.0.11-TiDB-v8.5.0' expected_contains='v8.5.0'
  - [ok] fixture database created: CREATE DATABASE rc=0 stderr=''
  - [ok] create-partitioned-fixture return code: rc=0 expected=0 stderr=''
  - [ok] create-partitioned-fixture: range fixture lands with two named partitions on every anchor: rc=0 output='2' expected='2'
  - [ok] seed-partition-rows return code: rc=0 expected=0 stderr=''
  - [ok] seed-partition-rows: the p1-range row lands: rc=0 output='1' expected='1'
  - [ok] drop-partition-p0 return code: rc=0 expected=0 stderr=''
  - [ok] drop-partition-p0: p0 definition is gone after DROP PARTITION: rc=0 output='0' expected='0'
  - [ok] drop-partition-p0: p1's row survives the drop: rc=0 output='1' expected='1'
  - [ok] truncate-partition-p1 return code: rc=0 expected=0 stderr=''
  - [ok] truncate-partition-p1: p1 definition survives TRUNCATE while its rows are gone: rc=0 output='1' expected='1'
  - [ok] truncate-partition-p1: no rows remain in the table after both partitions emptied: rc=0 output='0' expected='0'
  - [ok] create-exchange-counterpart return code: rc=0 expected=0 stderr=''
  - [ok] create-exchange-counterpart: exchange counterpart is a plain non-partitioned table: rc=0 output='0' expected='0'
  - [ok] seed-exchange-row return code: rc=0 expected=0 stderr=''
  - [ok] seed-exchange-row: counterpart row lands inside p1 range (100 <= 160 < 200): rc=0 output='1' expected='1'
  - [ok] exchange-partition-p1 return code: rc=0 expected=0 stderr=''
  - [ok] exchange-partition-p1: the counterpart row moved into the partitioned table: rc=0 output='1' expected='1'
  - [ok] exchange-partition-p1: the counterpart is empty after the swap: rc=0 output='0' expected='0'
  - [ok] cleanup return code: rc=0 expected=0 stderr=''
  - [ok] cleanup: fixtures removed: rc=0 output='0' expected='0'
  - [ok] image digest matches locked baseline: locked='pingcap/tidb@sha256:490861bd4a2fa643dbe76b77ffecafcad66e6a42774e580b82f4ec2429a80e57' resolved=['pingcap/tidb@sha256:490861bd4a2fa64
  - [ok] running container image identity: container='sha256:490861bd4a2fa643dbe76b77ffecafcad66e6a42774e580b82f4ec2429a80e57' image_id='sha256:490861bd4a2fa643dbe76b77ffecafcad66e6a4
  - [ok] platform recorded and matches baseline: platform='linux/arm64' locked='linux/arm64'

### T13.db.tidb85.syntax_negative (verdict N/A — db case asserts native steps, not audit output)
- step0: `ALTER TABLE t13g DROP PARTITION (`
  - [ok] nonzero syntax failure: rc=1
  - [ok] expected error class: error_class='1064' expected='1064'
  - [ok] no permission/connection/object-conflict markers: forbidden markers found: []
