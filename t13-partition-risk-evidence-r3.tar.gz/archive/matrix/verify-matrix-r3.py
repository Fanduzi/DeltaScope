import json,re,sys
md=open('/tmp/t13-r3-archive/archive/matrix/acceptance-matrix-r3.md').read().splitlines()
data=[l for l in md if l.startswith('| T13.')]
A=json.load(open('/tmp/t13-r2-archive/archive/golden/artifact-r1.json'))
errs=[]
if len(data)!=47: errs.append(f'data_rows={len(data)}!=47')
ids=[];colcounts=set();asserts=0
for l in data:
    cells=[c.strip() for c in re.sub(r'\\\|','PIPE_ESC',l).split('|')[1:-1]]
    colcounts.add(len(cells))
    ids.append(cells[0]);asserts+=int(cells[13])
    if '\\n' not in cells[6] and '\n' in cells[6]: errs.append('raw newline in '+cells[0])
if colcounts!={16}: errs.append(f'colcounts={colcounts}')
if len(set(ids))!=47: errs.append('dup case_id')
req=set(A['required_case_ids'])
if set(ids)!=req: errs.append(f'missing={req-set(ids)} extra={set(ids)-req}')
if asserts!=709: errs.append(f'asserts={asserts}!=709')
# actual field spot-verify: every row verdict/coverage/findings vs artifact parsed
am={c['case_id']:c for c in A['cases']}
for l in data:
    cells=[c.strip() for c in re.sub(r'\\\|','PIPE_ESC',l).split('|')[1:-1]]
    c=am[cells[0]];p=c['actual'].get('parsed')
    if p:
        av=cells[7].split('/')[-1]
        if av!=p['verdict']: errs.append(f"{cells[0]} verdict_a={av}!={p['verdict']}")
        ac=cells[8].split('/')[-1]
        if ac!=p['coverage']['status']: errs.append(f"{cells[0]} cov_a={ac}")
        nfa=len(re.findall(r"'ddl\.",cells[10]))
        nga=sum(len(s.get('evidence_gaps',[])) for s in p['statements'])
        af=sum(len(s.get('findings',[])) for s in p['statements'])
        if nfa!=af: errs.append(f"{cells[0]} findings_a count {nfa}!={af}")
        if cells[11].split('/')[-1]!=str(nga): errs.append(f"{cells[0]} gaps_a")
        if cells[13]!=str(len(c['assertions'])): errs.append(f"{cells[0]} asserts")
        if cells[12].split('/')[-1]!=str(c['actual']['exit']): errs.append(f"{cells[0]} exit_a")
stray=[l for l in md if l.startswith('ALTER ') or l.startswith('CREATE ')]
print('rows=47:',len(data)==47,'| colcounts:',colcounts,'| dup:',len(ids)-len(set(ids)),'| asserts:',asserts,'| stray_lines:',len(stray))
print('ERRORS:',errs if errs else 'none')
sys.exit(1 if errs else 0)
