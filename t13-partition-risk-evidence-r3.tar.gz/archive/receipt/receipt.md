# T13/#92 R3 receipt — T13-R3-FINAL-EVIDENCE-CORRECTION-01 (internal copy; A–K in chat delivery)

ER1 matrix: 47 rows / 16 cols / 0 dup / 709 asserts / actual==parsed — PASS.
ER2 transports: MCP req↔resp frames (id2, config_path), SDK full JSON, policy SHA f4547f39…,
  vcs.revision=9d2c439c… all 3 binaries, field parity reject/complete/1blocker/0gaps/0unsup — PASS.
ER3 native: HASH/KEY row-identity via PARTITION-select, 3 anchors, digest-unbound marked — PASS.
ER4 source: per-condition reachability table; T13-reachable branches only; equivalence proven — PASS.
ER5 errata: 73/102/175 denominators; per-sample stdout gap admitted + bound newrun; gate times unrecorded — PASS.
Archive: NEW/REUSED ledger, no-product-change (0 tracked diffs), credential scan clean.
