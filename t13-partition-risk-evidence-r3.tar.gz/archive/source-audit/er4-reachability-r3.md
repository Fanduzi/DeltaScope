# ER4 — T13 reachability through T14-modified shared functions (frozen HEAD 9d2c439c)

Correction: R2 said "T14 changes only fire for T14 action names" — too strong. The T14 commits
(b5b2ac70/c29ebc38/ce9a73dc) DID modify shared admission code: `fullyAuditedStatement` was relaxed,
`partitionStateAdmissible` was added, and a new earlier dispatch branch was inserted for single
partition actions. This document proves the per-condition reachability of T13
DROP/TRUNCATE/EXCHANGE through those shared functions at frozen HEAD — and that the resulting
semantics for T13 inputs are unchanged.

## 1. Effective call path at HEAD (single T13 action, e.g. `ALTER TABLE t DROP PARTITION p0`)

```
applyAlterTable (batch_state.go)
  └─ L1949: len(ddl.Alter)==1 && len(targets)>0 && isPartitionAlterAction(action)          [T14-added branch]
        && partitionStateAdmissible(dialect, statement)          ← T13 REACHES (gate)
        └─ true → applyPartitionOperation(targets,&ddl.Alter[0],statement)                 [signature gained `statement`]
                    └─ applyPartitionAction (partition_transitions.go L358)
                         ├─ "drop_partition"      → transitionDropPartition (L389)
                         └─ "truncate_partition","exchange_partition" → clone+clear stats (L362-365)
  └─ L1957: !fullyAuditedStatement || len!=1 || targets==0 → invalidateAll (tombstone)      [fallback when inadmissible]
```

`isPartitionAlterAction` → `spec.IsPartitionAlterAction` — T13 actions (drop_partition,
truncate_partition, exchange_partition) are members; T14 action names were appended additively.

## 2. `partitionStateAdmissible` — T13 per-condition reachability

blob: batch_state.go `0c8ae529cea877c24e6ca77bad8fd5af92e7d378`, function L803-824.

| condition | T13 reachable? | evidence |
|---|---|---|
| `statement.Unsupported != nil` → false | unreachable in practice | parse-unsupported statements never reach applyAlterTable; T13 grammar parses cleanly (47/47 golden) |
| aspect=action & vendor-boundary & refused-list → continue | unreachable | `tidbVendorRefusedAlterActions` = six maintenance ops + force + import/discard_tablespace (coverage.go L89-101, blob b8b64554); drop/truncate/exchange_partition not in set |
| aspect=action & vendor-boundary & not-refused → return false | unreachable | action aspects are only emitted for non-audited actions (`unauditedActionVendor`); all three T13 actions are in `auditedAlterActions{MySQL,TiDB}` |
| `aspect == "partition_bound"` → continue | unreachable | partition_bound aspects emit only for `alter.PartitionDefs`/`PartitionScheme.Defs` bound declarations (coverage.go L749-766) — ADD/REORGANIZE/PARTITION BY shapes. T13 actions name existing members via `alter.Partitions` and never declare defs |
| other aspect → return false | unreachable for T13 grammar | remaining aspect kinds are column_position (needs Column+position), partition_expression (needs PartitionScheme), option (needs UnextractedOptions) — none emitted by DROP/TRUNCATE/EXCHANGE PARTITION syntax |
| zero aspects → return true | **T13 path** | every T13 single-action statement: admissible → applyPartitionOperation |

## 3. `fullyAuditedStatement` — T13 per-condition reachability

blob: batch_state.go `0c8ae529…`, function L751-791. T13 reaches it only when
`partitionStateAdmissible` returned false (same dispatch site, L1957 fallback).

| exemption → continue | T13 reachable? |
|---|---|
| vendor-refused action aspect (tidbVendorRefusedAlterActions) | unreachable (as above) |
| `action == "placement_policy"` MySQL vendor refusal | unreachable — placement_policy is not a T13 action and cannot co-occur (len(ddl.Alter)==1 gate) |
| `aspect == "option"` vendor-boundary | unreachable — T13 partition syntax carries no UnextractedOptions |
| `aspect == "temporary"` vendor-boundary | unreachable — T13 statements carry no temporary clause |
| `aspect == "ttl"` vendor-boundary | unreachable — no TTL clause on partition actions |
| fallthrough → return false / return true | T13 single actions always have zero aspects → `true` when evaluated; false only via targets==0 handled at dispatch |

## 4. Pre-T14 vs HEAD for T13 inputs — semantic equivalence

| element | pre-T14 (b5b2ac70^) | HEAD | T13-visible delta |
|---|---|---|---|
| admission | `fullyAuditedStatement` strict (Unsupported==nil && 0 aspects) → invalidateAll | partitionStateAdmissible admits refused-action/partition_bound aspects, else same gate | none — T13 cannot emit the newly-admitted aspect kinds |
| DROP transition | inline in batch_state.go L1408 (members/applicability identical) | partition_transitions.go transitionDropPartition — same provable/applicability structure | adds `survivingPartitionDefs`/`survivingPartitionDescriptions` for two snapshot fields T13 never populated; nil-safe (`defs==nil→nil`) |
| TRUNCATE/EXCHANGE transition | clone + clearMutationStats + clearModifyAffectedStats | same (L362-365) | none |
| applyPartitionOperation signature | (targets, alter) | (targets, alter, statement) — publishes placement mutation outcome | additive, no T13 verdict change |

Actual diffs: `source-audit/t14-shared-diffs-r3.diff`; pre-T14 source: `excerpts/preT14-applyPartitionOperation_L1408-1440.txt`.

## 5. Covering tests / cases per branch

| branch | coverage |
|---|---|
| admissible → applyPartitionOperation → T13 transitions | 22 metadata_cases (e.g. T13.meta.t13r2-mysql80-drop-then-truncate-absent/-survives, t13r3-mysql80-hash-drop-keeps-directory) + Go: TestT13PartitionSingleActionPostState, TestT13ExchangePostStateClearsBothSides, TestT13R2DropPostStateSuccessorTargets/-SurvivorAndModifier |
| drop refused keeps exact pre-state (absent member 1735/1507, whole-set 1508, method 1512) | TestT13R1ApplicabilityHashDropBlocks + golden t13r3-mysql80-hash-drop-keeps-directory, t13r2-drop-then-truncate-absent |
| unproven method → unvouch directory | TestT13R1ApplicabilityUnknownHoldsGap + golden t13r2-mysql80-exchange-subpartition-leaf-gap |
| multi-action partition dispatch (partitionMixedOutcome) | golden t13r1-mysql57-algorithm-drop-refused / -mysql80-algorithm-drop-executes; Go: TestT13R1AlgorithmDropPartition(Executes|VersionGate) |
| T14-only admission (partition_bound continue, refused maintenance continue) | batch_state_t14r1_test.go / batch_state_t14r2_test.go (not T13-reachable, proven above) |

## 6. Verdict

T14 changed the shared admission surface but only widened it for aspect kinds T13 statements
cannot emit; for every T13-reachable condition the pre/post-T14 outcomes are identical.
47/47 golden + 175-RUN focused tests + T12 25/25 regression all executed at frozen HEAD cover
the post-T14 code paths directly. No T13-affecting defect found — no DEFECT-STOP.
