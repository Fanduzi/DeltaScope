# ER5 — effective-source + downstream-impact analysis (R2)

## Key branches @9d2c439c (excerpts in source-audit/excerpts/)
- partition_rules.go L27-72: partitionForbidRule fires per authored action; DROP/TRUNCATE
  forbid rules emit one finding per named partition (multi-name = multi-finding).
- partition_applicability_rules.go L48-57+L114-124: ONLY drop_partition type-gated
  (range|list). L106-113 non-partitioned → 1505. Target rule L262-292 member-name
  existence (1507 drop / 1735 truncate+exchange). Counterpart rule L371-417 binds
  exchange_table existence(1146)/partitioned(1732)/compat(1736)/engine(1497 mysql-only).
- partition_transitions.go: applyPartitionAction L358 dispatch —
  drop_partition→transitionDropPartition L389 (member removed + data facts dropped);
  truncate/exchange L362 (member kept, row/stat facts invalidated);
  unvouchPartitionMembers L60 / unvouchPartitioning L69 = honest unknown post-state.
- auditmeta/targets.go: ExchangeTable enters TableTargets — denylist sees BOTH sides.
- Shared entry: all four transports delegate to appaudit.AuditSQL (parity proven R2 raw).

## Post-state semantics verified
- DROP: member deleted from snapshot.PartitionNames (L389+); data-derived stats dropped.
- TRUNCATE: member names preserved; row-count/stat facts invalidated.
- EXCHANGE: both table identities preserved; counterpart snapshot resolved via preState.
- Denylist: exchange-protected-left / -other-side golden cases prove no bypass.
- Unproven post-state → unvouch → successor gaps, never invented certainty.

## T14 downstream diffs (source-audit/t14-downstream-diffs.txt, 242 lines)
- b5b2ac70: EXTENDS isPartitionAlterAction to include T14 actions; T13's three cases
  remain in the same switch — no T13 branch rewritten, T13 golden 47/47 at HEAD = proof.
  Adds PartitionDefs/Subpartitioned to derivedCreateShape snapshot (new fields, additive).
- c29ebc38: T14-R1 remediation — additive T14 aspects + tests, batch_state additions only.
- ce9a73dc: T14-R2 — bounded state admission for T14 verbs; same additive pattern.
Reachability: T14 changes only fire for T14 action names (add/reorganize/coalesce/…),
which cannot appear in T13 statements — T13-vs-T14 interaction covered by T13 golden +
batch_state_t13*_test.go (175 RUN green) and T12 regression golden 25/25.
