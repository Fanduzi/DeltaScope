# t13-partition-risk-evidence-r3.tar.gz

T13/#92 partition risk auditing — R3 FINAL EVIDENCE CORRECTION round.
Frozen HEAD 9d2c439c46f6faed434e91c8b54ebc82abbf0787 (tree bcec2a29…, parent d6af1241…).
Issue #92 OPEN, #79 OPEN, #93/T14 not started, milestone remote unchanged.

## What R3 corrects (per T13-R3-FINAL-EVIDENCE-CORRECTION-01)
1. **matrix/acceptance-matrix-r3.md** — the 3 multi-statement rows that embedded raw newlines
   are regenerated with `\n`-escaped SQL cells; validator verify-matrix-r3.py + .out prove
   47 complete rows, 16 consistent columns, 0 dup, 709 assertions, actual==artifact.
   (R2/R1 matrices retained as historical payloads.)
2. **transports/r3/** — MCP request+response frame chain (request id=2 tools/call audit_sql
   with config_path ↔ response id=2, isError absent); SDK full marshaled Result JSON; policy
   YAML payload with SHA f4547f39…; full unfiltered `go version -m` (vcs.revision=9d2c439c…)
   for all three binaries; field-by-field four-surface comparison.
3. **native/er3-r3/** — HASH/KEY TRUNCATE row-identity proof via real `SELECT … PARTITION(pN)`
   on 8.0.46/8.4.10/TiDB-8.5.0; TABLE_ROWS estimate limitation documented; digest-unbound marked.
4. **source-audit/er4-reachability-r3.md** — per-condition reachability of T13 actions through
   fullyAuditedStatement/partitionStateAdmissible at HEAD; pre-T14 vs HEAD equivalence;
   t14-shared-diffs-r3.diff; corrected continuous excerpts (transitions_L355-420.txt retained
   as superseded historical payload).
5. **review/focused-count-erratum-r3.md** — denominators: 73 top-level / 102 subtests / 175 RUN.
6. **performance/perf-binding-r3.md** — per-sample stdout gap admitted; cold+R3 NEW RUN outputs
   bound by SHA; reject/800/400 verified; gate start/end marked unrecorded.

## Layout
manifest.txt / payload-index.txt / reuse-ledger.txt at tar root; payloads under archive/.
REUSED = byte-identical member of a prior T13 archive (R1 or R2); NEW = created/changed in R3.
