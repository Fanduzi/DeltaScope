# ER3 — EXCHANGE bidirectional data-swap (both sides non-empty), 4 anchors

Identical probe on every anchor (er3-exchange-*.log): ep RANGE(p0<100,p1<200)
seeded (50,1),(99,3),(150,2); xt plain seeded (160,9).
ALTER TABLE ep EXCHANGE PARTITION p1 WITH TABLE xt WITHOUT VALIDATION.

| anchor | version | exchange rc | ep_p1 after | xt after | p0 after | defs after |
| mysql57  | 5.7.44           | 0 | 160,9 | 150,2 | 50,1+99,3 | p0=2,p1=0 |
| mysql80  | 8.0.46           | 0 | 160,9 | 150,2 | (p0 rows kept) | members intact |
| mysql84  | 8.4.10           | 0 | 160,9 | 150,2 | 50,1+99,3 | p0=2,p1=0 |
| tidb85   | 8.0.11-TiDB-v8.5.0 | 0 | 160,9 | 150,2 | kept | members intact |

Real two-way data swap proven on every anchor; p0 untouched; partition
definitions preserved. No anchor refused — all rc=0.
