# ER3 — HASH/KEY TRUNCATE data-identity proof (real partition-selection, not TABLE_ROWS)

Boundary fixed: `information_schema.PARTITIONS.TABLE_ROWS` is an estimate and cannot prove non-target
row survival (TiDB shows 0 even when data exists). This probe uses real membership-proving queries
`SELECT ... FROM t PARTITION (pN)` returning actual row identifiers (id,c) before/after TRUNCATE.

## Method (per anchor)
1. `CREATE TABLE th PARTITION BY HASH(id) PARTITIONS 2`, seed 4 rows (11,110)(22,220)(33,330)(44,440)
2. before: `SELECT part,id,c FROM th PARTITION(p0) UNION ALL th PARTITION(p1)` → row identity per partition
3. `ALTER TABLE th TRUNCATE PARTITION p0`
4. after: same selection → p0 empty, p1 rows verbatim; `information_schema.PARTITIONS` name/method unchanged
5. Same cycle for `tk PARTITION BY KEY(id) PARTITIONS 2`
6. Teardown `DROP DATABASE t13r3`

## Results (all rc=0)

| anchor | version | HASH before p0/p1 | HASH after | KEY before p0/p1 | KEY after | defs kept |
|---|---|---|---|---|---|---|
| MySQL | 8.0.46 | p0={22/220,44/440} p1={11/110,33/330} | p0=∅ p1={11/110,33/330} | p0={11/110,33/330} p1={22/220,44/440} | p0=∅ p1={22/220,44/440} | p0/p1 HASH |
| MySQL | 8.4.10 | same distribution | p0=∅ p1 verbatim | p0={11/110,33/330} p1={22/220,44/440} | p0=∅ p1 verbatim | p0/p1 HASH/KEY |
| TiDB | 8.0.11-TiDB-v8.5.0 | p0={22/220,44/440} p1={11/110,33/330} | p0=∅ p1={11/110,33/330} | p0={22/220} p1={11/110,33/330,44/440} | p0=∅ p1 verbatim (3 rows) | p0/p1 HASH/KEY |

Target-partition data deleted; non-target rows preserved verbatim; partition names+methods intact on all anchors.

## Image identity
- mysql:8.0.46 → local image_id sha256:7dcddc01f13b… (digest mysql@sha256:7dcddc01f13bab2f15cde676d44d01f61fc9f99fe7785e86196dfc07d358ae2b recorded in golden artifact)
- mysql:8.4.10 → local image_id sha256:8dbcf531a03a…
- TiDB: container `t26-ai-tidb` (pingcap/tidb:v8.5.0 490861bd4a2f) host port 14000, probed from host mysql client
- Probe-period resolved digests for the two ephemeral mysql containers were not separately pinned beyond the
  local image_id above: **version-observed / digest-unbound** for these ER3-R3 runs (no supply-chain claim).

## Files
- mysql80-8.0.46-hash-key-rows.log / mysql84-8.4.10-hash-key-rows.log / tidb85-8.5.0-hash-key-rows.log
- drivers: ../er3-probe.sh (docker-exec variant), ../er3-probe-tidb.sh (host client)
- Prior R2 conclusion stands: HASH/KEY TRUNCATE rc=0, DROP → ERROR 1512; this probe only adds
  row-identity/non-target-survival proof.
