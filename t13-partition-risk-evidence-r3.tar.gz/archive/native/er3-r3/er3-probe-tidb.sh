#!/bin/bash
run() {
  echo "=== [tidb85] $1 ==="; echo "SQL> $2"
  out=$(mysql --defaults-file=/dev/null -h127.0.0.1 -P14000 -uroot --connect-timeout=8 -e "$2" 2>&1); rc=$?
  echo "rc=$rc"; echo "$out"; echo "---"
}
run setup 'DROP DATABASE IF EXISTS t13r3; CREATE DATABASE t13r3;'
run version "SELECT VERSION();"
run hash_create 'CREATE TABLE t13r3.th (id INT, c INT) PARTITION BY HASH(id) PARTITIONS 2;'
run hash_seed   'INSERT INTO t13r3.th VALUES (11,110),(22,220),(33,330),(44,440);'
run hash_before "SELECT 'p0' AS part,id,c FROM t13r3.th PARTITION (p0) UNION ALL SELECT 'p1',id,c FROM t13r3.th PARTITION (p1) ORDER BY part,id;"
run hash_defs_before "SELECT PARTITION_NAME,PARTITION_METHOD,PARTITION_EXPRESSION FROM information_schema.PARTITIONS WHERE TABLE_SCHEMA='t13r3' AND TABLE_NAME='th' ORDER BY PARTITION_NAME;"
run hash_truncate 'ALTER TABLE t13r3.th TRUNCATE PARTITION p0;'
run hash_after "SELECT 'p0' AS part,id,c FROM t13r3.th PARTITION (p0) UNION ALL SELECT 'p1',id,c FROM t13r3.th PARTITION (p1) ORDER BY part,id;"
run hash_defs_after "SELECT PARTITION_NAME,PARTITION_METHOD,PARTITION_EXPRESSION FROM information_schema.PARTITIONS WHERE TABLE_SCHEMA='t13r3' AND TABLE_NAME='th' ORDER BY PARTITION_NAME;"
run key_create 'CREATE TABLE t13r3.tk (id INT, c INT) PARTITION BY KEY(id) PARTITIONS 2;'
run key_seed   'INSERT INTO t13r3.tk VALUES (11,110),(22,220),(33,330),(44,440);'
run key_before "SELECT 'p0' AS part,id,c FROM t13r3.tk PARTITION (p0) UNION ALL SELECT 'p1',id,c FROM t13r3.tk PARTITION (p1) ORDER BY part,id;"
run key_truncate 'ALTER TABLE t13r3.tk TRUNCATE PARTITION p0;'
run key_after "SELECT 'p0' AS part,id,c FROM t13r3.tk PARTITION (p0) UNION ALL SELECT 'p1',id,c FROM t13r3.tk PARTITION (p1) ORDER BY part,id;"
run key_defs_after "SELECT PARTITION_NAME,PARTITION_METHOD FROM information_schema.PARTITIONS WHERE TABLE_SCHEMA='t13r3' AND TABLE_NAME='tk' ORDER BY PARTITION_NAME;"
run teardown 'DROP DATABASE t13r3;'
