# ER4 — HASH/KEY DROP vs TRUNCATE verdict: PASS (no product defect)

## Source adjudication @9d2c439c
partition_applicability_rules.go (blob 80c34e84…) L52-57:
  partitionActionApplicableTypes = { "drop_partition": {range,range columns,list,list columns} }
  — ONLY drop_partition carries a type gate; truncate_partition/exchange_partition
  absent → typeGated=false → execute on every observed method (L114-124).
Evaluate L106-113: non-partitioned primary → 1505 finding (all actions).
EvidenceGaps L185-191: type fact owed ONLY for type-gated actions when
  partitioned=true && PartitionType==nil.

## Answers
- MySQL HASH DROP: applicability blocker (1512 partition_type_inapplicable) — proven.
- MySQL HASH TRUNCATE: no applicability finding — executes; forbid policy may still block (separate layer).
- MySQL KEY: identical — DROP refused 1512, TRUNCATE allowed.
- TiDB 8.5 HASH/KEY: same gate (native confirmed 1512 on v8.5.0; TiDB returns MySQL-compatible 1512 here).
- Unknown type: gap `target_table.partitioned`/`partition_type` owed, never fabricated refusal.
- DROP's refusal condition NOT reused for TRUNCATE — separate map key.

## Product probes (mysql:8.0.46 live, schema t13probe, hash+key+range fixtures)
- DROP hp(hash).p1 → reject/complete, findings: drop_partition.forbid + drop_partition.applicability(1512) — aud-drop-hash.json
- TRUNCATE hp(hash).p0 → reject/complete, finding: truncate_partition.forbid ONLY, zero applicability — aud-trunc-hash.json
- DROP rp(range).p0 → forbid only, no applicability — aud-drop-range.json
- TRUNCATE kp(key).p1 → forbid only — aud-trunc-key.json
- DROP offline (no metadata) → unverified + gap target_table.partitioned — aud-drop-offline.json

## Native anchors (per-statement rc/stdout/stderr, full logs)
- mysql:8.0.46 (er4-mysql80.log): TRUNCATE hp hash rc=0; TRUNCATE kp key rc=0;
  members_after shows defs retained; DROP hash p1 → ERROR 1512; DROP key p1 → 1512.
- mysql:8.4.10 (er4-mysql84.log): identical.
- pingcap/tidb:v8.5.0 (er4-tidb85.log): identical (1512 code is TiDB-compatible).
- 5.7: same partition-method class handled by family rules; TRUNCATE/DROP hash verified
  on the 8.0/8.4/TiDB anchors as ordered (5.7 covered by golden db mysql57 cases + probes).
Conclusion: product matches official DROP=RANGE/LIST-only, TRUNCATE=all-methods semantics.
