# ER6(a) — R1 performance erratum + R2 supplemental measurement

## Erratum on R1 samples [64,64,63,64,66,65,66,65,66,64]
R1 reported median=64ms / p95_linear=65.85ms — WRONG on the published integer samples:
correct stats on those 10 integers: median=64.5, p95_nearest_rank=66, p95_linear=66.
The original per-sample fractional values were not preserved; R1's fractional stats
cannot be reconstructed — marked historical-summary-only, not re-claimed.

## R2 NEW RUN (supplemental, deterministic fixture unchanged)
fixture: performance/fixture.sql (R1 REUSED) sha256=e0f5c43c25d1e8fe263c644daec4285fd13ab434daa2eb44253c704e76d4903a
generator: performance/generate_fixture.py (regen byte-identical, proven)
binary: bin/deltascope sha256=1fffdd765ef3055940ba7a77789d84a9acc7274204c5665e0ae3058a2a5bdd48 @HEAD 9d2c439c46f6
argv per sample: bin/deltascope audit --file fixture.sql --dialect mysql --format json
expected rc=1 (policy blockers — real audit work, NOT a measurement failure):
actual output = reject / 800 statements / 400 blockers / coverage unverified (offline honesty).

cold run (/usr/bin/time -p real): 0.09s (~90ms), stdout=/tmp t13p-cold.json.
warm samples (n=12, perf_counter_ns): see samples-r2.txt — raw ms per row.

warm1=149.512ms is a transitional first-warm (post-cold cache/JIT path). Reported honestly:
- FULL n=12: sorted=[64.753,65.088,65.2,65.946,66.091,66.682,66.816,66.879,67.196,67.87,68.954,149.512]
  median=66.749  p95_nearest_rank=149.512  p95_linear=105.205  min=64.753 max=149.512
- STEADY n=11 (excluding warm1, marked transitional):
  median=66.682  p95_nearest_rank=68.954  p95_linear=68.412  min=64.753 max=68.954

p95 methods: nearest-rank = sorted[ceil(0.95n)-1]; linear = h=(n-1)*0.95 interpolation.
Scope: audit-path latency only — never DB DDL execution time.
