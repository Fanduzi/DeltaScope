import sys
# deterministic T13 perf fixture: mixed partition DDL batch
out=[]
for i in range(200):
    out.append(f"ALTER TABLE pt{i} DROP PARTITION p0;")
    out.append(f"ALTER TABLE pt{i} TRUNCATE PARTITION p1;")
    out.append(f"ALTER TABLE pt{i} EXCHANGE PARTITION p2 WITH TABLE xt{i} WITHOUT VALIDATION;")
    out.append(f"ALTER TABLE nt{i} ADD COLUMN c{i} INT;")
sys.stdout.write('\n'.join(out)+'\n')
