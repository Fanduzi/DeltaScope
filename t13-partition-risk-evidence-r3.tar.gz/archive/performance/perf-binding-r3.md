# ER5(b) — performance output binding (R3)

## Fixture identity (unchanged, REUSED basis)
- generator: performance/generate_fixture.py (R2 payload)
- fixture.sql SHA-256 `e0f5c43c25d1e8fe263c644daec4285fd13ab434daa2eb44253c704e76d4903a` — 800 statements
- binary: bin/deltascope SHA-256 `1fffdd765ef3055940ba7a77789d84a9acc7274204c5665e0ae3058a2a5bdd48` @ vcs.revision=9d2c439c… (gvm-deltascope.txt)

## Per-sample stdout gap — admitted
R2 warm samples 1–12 recorded argv/rc/ms only; per-sample stdout was not captured and is
**unrecoverable** — no historical output is fabricated. One complete real audit output of the
fixture exists from the same session (cold run) plus one new R3 NEW RUN bound probe:

| run | argv | rc | ms | stdout SHA | bytes |
|---|---|---|---|---|---|
| cold (R2 session) | bin/deltascope audit --file fixture.sql --dialect mysql --format json | 1 | — (not the timed metric) | e54f25637d6a7bd8748008d8c8377ac69b5090a0a77047c0150e6997ed333c91 | 1,245,582? (see payload) |
| r3_newrun | same | 1 | 114.801 | 19b00170320307f716ebf3a03bdb292e61d7153aa5086a61791dba1f00f804af | 1,245,582 |

## Fixture audit result verification (perf-audit-r3-newrun.json)
- verdict=reject, coverage=unverified (offline, no metadata — honest gap, not failure)
- statements=800, blockers=400, warnings=400, notices=200, findings=800
- rc=1 is the expected policy-rejection exit (`--fail-on` default on blockers), NOT a measurement failure.
- cold vs newrun are **semantically identical** (verdict/coverage/summary/800 raw_sql/all 800 findings/gaps=2400 equal);
  bytes differ only in `global_findings` ordering (Go map iteration on per-table merge warnings — non-deterministic order, same content set).

## Timing statistics (R2 values retained, unchanged)
12 samples [64.753,65.088,65.2,65.946,66.091,66.682,66.816,66.879,67.196,67.87,68.954,149.512] ms:
median=66.749 / p95nr=149.512 / p95lin=105.205; steady-state 11 samples: median=66.682 / p95nr=68.954 / p95lin=68.412.
Audit-path runtime only — no database DDL latency claimed.

## Gates timing
Six-gate rc=0 preserved (R1 log REUSED). Original start/end timestamps were not recorded for the
gate run — marked unrecorded, not backfilled.
