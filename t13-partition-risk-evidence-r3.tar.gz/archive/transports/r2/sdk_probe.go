//go:build ignore
package main
import (
 "context";"fmt";"os"
 "github.com/Fanduzi/DeltaScope/pkg/deltascope"
)
func main() {
 res, err := deltascope.Audit(context.Background(), deltascope.Request{
  SQL: "ALTER TABLE t DROP PARTITION p0;", Dialect: deltascope.DialectMySQL,
  ConfigPath: "/tmp/ddl-golden-t13/T13/golden-policy-t13-drop.yaml",
 })
 if err != nil { fmt.Println("ERR",err); os.Exit(2) }
 fmt.Println("verdict:",res.Verdict,"coverage:",res.Coverage.Status,"statements:",len(res.Statements))
 for _,s := range res.Statements { for _,f := range s.Findings { fmt.Println("finding:",f.RuleID,f.Level) } }
}
