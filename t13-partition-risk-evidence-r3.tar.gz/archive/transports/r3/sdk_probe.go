//go:build ignore
package main
import (
 "context";"encoding/json";"fmt";"os"
 "github.com/Fanduzi/DeltaScope/pkg/deltascope"
)
func main() {
 req := deltascope.Request{
  SQL: "ALTER TABLE t DROP PARTITION p0;", Dialect: deltascope.DialectMySQL,
  ConfigPath: "/tmp/ddl-golden-t13/T13/golden-policy-t13-drop.yaml",
 }
 res, err := deltascope.Audit(context.Background(), req)
 if err != nil { fmt.Println("ERR",err); os.Exit(2) }
 out,_ := json.MarshalIndent(map[string]any{
   "request": map[string]any{"sql":req.SQL,"dialect":string(req.Dialect),"config_path":req.ConfigPath,"schema":req.Schema},
   "result": res,
 },"","  ")
 fmt.Println(string(out))
}
