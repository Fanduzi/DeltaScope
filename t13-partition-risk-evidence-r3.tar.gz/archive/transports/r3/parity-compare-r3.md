# ER2 — four-surface parity field comparison (R3)

Same SQL `ALTER TABLE t DROP PARTITION p0;` / same policy `golden-policy-t13-drop.yaml` (SHA-256 `f4547f39c201cf37778f4d17fb8a56a6c7c24d07072198e4ee969170ee68943c`, payload: transports/r3/golden-policy-t13-drop.yaml) / offline mysql / no metadata.

| surface | verdict | coverage | statements | findings | gaps | unsupported |
|---|---|---|---|---|---|
| CLI | reject | complete | 1 | [('ddl.alter.drop_partition.forbid', 'blocker')] | 0 | 0 |
| SDK | reject | complete | 1 | [('ddl.alter.drop_partition.forbid', 'blocker')] | 0 | 0 |
| HTTP | reject | complete | 1 | [('ddl.alter.drop_partition.forbid', 'blocker')] | 0 | 0 |
| MCP | reject | complete | 1 | [('ddl.alter.drop_partition.forbid', 'blocker')] | 0 | 0 |

Binary identity: all three binaries carry `build vcs.revision=9d2c439c46f6faed434e91c8b54ebc82abbf0787` (full unfiltered `go version -m` output in transports/r3/gvm-*.txt; `vcs.modified=true` = untracked scratch files only, tracked tree clean per diffs/no-product-change.txt).
Binary SHA-256: deltascope=1fffdd765ef3055940ba7a77789d84a9acc7274204c5665e0ae3058a2a5bdd48, deltascope-server=28dea1905c492491e02f606fa11b5fc9bef475a3a957b71c4e97aefc7244a2ec, deltascope-mcp=478bca9b93f8db40435846b099db39bb32b77b248db297d78188ef5cacde0572 (matches transports/r2/binary-policy-sha.txt).

MCP request↔response: request id=2 method=tools/call name=audit_sql config_path=<policy> ↔ response id=2, isError field ABSENT (transports/r3/mcp-frames.jsonl, direction-annotated; raw halves in mcp-request-frames.jsonl / mcp-response-frames.jsonl).
SDK: full marshaled Result in transports/r3/sdk-stdout.json incl. request block with exact ConfigPath; sdk_probe.go + sdk-run.txt (rc=0).
Verdict: reject / complete / exactly 1 blocker ddl.alter.drop_partition.forbid / 0 gaps / 0 unsupported on all four surfaces — full parity PASS.
