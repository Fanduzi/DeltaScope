# ER5(a) — focused-test denominator erratum (R3)

R2 receipt stated "175 RUN （全顶层）". Independent recount of the R2 raw log
`review/focused-t13-raw.log` (argv: `go test ./internal/... -run T13 -tags postgresql -v`,
rc=0, HEAD 9d2c439c) gives three distinct denominators:

| denominator | count | command |
|---|---|---|
| top-level tests | 73 | `grep -E '^=== RUN   [^ ]+$' log | grep -vc '/'` |
| subtests | 102 | `grep -E '^=== RUN' log | grep -c '/'` |
| total RUN lines | 175 | `grep -c '^=== RUN' log` |
| FAIL | 0 | `grep -c 'FAIL' log` (exit-code aside, zero FAIL lines) |

Run output:
    top=73 sub=102 total=175 fail_lines=0

The 175 count is correct as total RUN lines; the "全顶层" qualifier was wrong —
subtests counted at top-level indentation naming include 102 `Parent/child` rows.
No test re-run needed (wording erratum only).
