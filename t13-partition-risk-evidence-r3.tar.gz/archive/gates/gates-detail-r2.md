# Six gates — R1 NEW RUN execution tuples (logs reused, all rc=0)
| gate | argv | rc | log |
| make test | make test | 0 | gates/t13-gate-test.log |
| go vet | go vet ./... | 0 | gates/t13-gate-vet.log |
| validator | make ddl-golden-validator-test | 0 | gates/t13-gate-validator.log |
| inventory | make ddl-inventory-gate | 0 | gates/t13-gate-inventory.log |
| pg | make pg-unit-test-gates | 0 | gates/t13-gate-pg.log |
| corpus | make sql-corpus-gates | 0 | gates/t13-gate-corpus.log |
tested HEAD=9d2c439c46f6 on all; status file gates/t13-gates-status.log.
PASS criterion: rc=0 + no FAIL lines in logs. No re-run needed (logs complete).
T12 regression golden: 25/25/294 PASS (golden/t12-regression-artifact.json, R1 REUSED).
Focused: go test ./internal/... -run T13 -tags postgresql -v → 175 RUN, 0 FAIL
(raw: review/focused-t13-raw.log — R2 NEW RUN for raw-output requirement).
