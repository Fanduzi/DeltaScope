# T15-R5 field binding — case kind → artifact path → matrix field → oracle → rule

## Common
- case_id ← cases[].case_id · kind ← kind · anchor ← anchor
- sql ← input_sql (list joined "; ") — provenance comparison
- assertions ← len(assertions[]); assert_ok ← all(assertions[].ok) — oracle
- status ← status — oracle

## cli_audit / cli_metadata (17+17)
| matrix field | artifact path | oracle | rule |
|---|---|---|---|
| exit_a | actual.exit | expected.exit | oracle |
| verdict_a | actual.parsed.verdict | expected.verdict | oracle |
| cov_a | actual.parsed.coverage.status | expected.coverage | oracle |
| stmt_cov_a | parsed.statements[].coverage.status | expected.statement_coverage | oracle |
| findings_a | parsed.statements[].findings[] → {index,rule_id,level} | expected.finding_entries | oracle (len+rule_id+level) |
| gaps_a / gap_entries_a | parsed.statements[].evidence_gaps[] → {rule_id,reason_code,required_facts} | expected.evidence_gaps (count) | oracle (count) + provenance (entries) |
| unsup_a / unsup_entries_a | parsed.unsupported[] (TOP level) → {feature,sql,reason,metadata} | expected.unsupported (count) | oracle (count) + provenance (entries) |
| diag_a / diag_entries_a | parsed.diagnostics[] (TOP level) → {classification,audited} | expected.diagnostics (count) | oracle + provenance |
| version | expected.version | — | provenance-only |
| sql/stdout/stderr | verbatim | — | provenance-only (no oracle) |

## cli_metadata only
- setup/execute/post_verify/teardown ← actual.<phase> step ARRAYS:
  each {name,sql,rc,stdout,stderr,verify[]:{assert,sql,rc,output,stderr}}
  — PROVENANCE comparison (steps have no oracle block; marked
  provenance-only, never claimed as oracle-PASS).
- database ← actual.database — provenance-only.

## db_ddl (4)
- steps ← actual.steps[] {name,sql,rc,stdout,stderr,verify[]}
- steps_e ← expected.steps[] {name,rc,verify[]{assert,expect}}
- ORACLE: steps count/order, name, rc; verify count/order,
  expect==output. Matrix projection: full stdout/stderr/sql preserved
  (provenance-only where no oracle).

## db_syntax_negative (4)
- rc_a ← actual.rc | error_class_a ← actual.error_class |
  argv_a/stdout_a/stderr_a ← actual verbatim
- ORACLE: expected.error_class==actual.error_class;
  expected.rc_nonzero ⇔ actual.rc!=0; forbidden_markers absent from
  stdout/stderr.

## Global
- required_case_ids ← T15.json.required_case_ids == executed set (42)
- kinds 17/17/4/4 · assertions 480 all ok · status all pass.
