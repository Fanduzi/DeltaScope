# R1→R2 golden diff ledger

cases 42→42; assertions 482→480
case_ids identical: True

## T15.cli.t15-cli-stats-persistent-gap
expected R1: {"exit": 1, "verdict": "review", "statements": 1, "findings": 0, "diagnostics": 1, "unsupported": 1, "coverage": "incomplete", "statement_coverage": ["incomplete"], "evidence_gaps": 0, "unsupported_entries": [{"index": 0, "feature": "alter_table.option.stats_persistent", "reason": "parsed by the shared parser but not covered by audited semantics", "metadata": {"action": "table_option", "aspect": "option", "option": "stats_persistent"}}]}
expected R2: {"exit": 0, "verdict": "review", "statements": 1, "findings": 1, "diagnostics": 0, "unsupported": 0, "coverage": "complete", "statement_coverage": ["complete"], "evidence_gaps": 0, "finding_entries": [{"index": 0, "rule_id": "ddl.alter.table_option.warn", "level": "warning"}]}
actual R1: exit=1 verdict=review cov={'status': 'incomplete'}
actual R2: exit=0 verdict=review cov={'status': 'complete'}