#!/bin/bash
C=deltascope-ddl-golden-tidb85-client
echo "############ ANCHOR tidb85 ############"
docker exec $C mysql --protocol=tcp -h tidb85 -P 4000 -uroot -Nse 'SELECT VERSION()'
run_sql() {
  echo "== tidb85 | $1"
  out=$(docker exec $C mysql --protocol=tcp -h tidb85 -P 4000 -uroot golden -e "$1" 2>/tmp/qr.err); rc=$?
  err=$(head -2 /tmp/qr.err)
  echo "rc=$rc out=${out:0:180} err=${err:0:160}"
}
docker exec $C mysql --protocol=tcp -h tidb85 -P 4000 -uroot -e 'DROP DATABASE IF EXISTS golden; CREATE DATABASE golden'
run_sql "CREATE TABLE e1 (id INT) ENGINE=InnoDB"
run_sql "CREATE TABLE e2 (id INT) ENGINE=MyISAM"
run_sql "CREATE TABLE e4 (id INT) ENGINE=FEDERATED"
run_sql "SHOW TABLE STATUS"
run_sql "CREATE TABLE rf1 (id INT) ENGINE=InnoDB ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8"
run_sql "SHOW CREATE TABLE rf1"
run_sql "ALTER TABLE rf1 KEY_BLOCK_SIZE=4"
run_sql "SHOW CREATE TABLE rf1"
run_sql "CREATE TABLE cs1 (id INT, s VARCHAR(10)) DEFAULT CHARACTER SET utf8mb4"
run_sql "ALTER TABLE cs1 DEFAULT CHARACTER SET latin1"
run_sql "SHOW CREATE TABLE cs1"
run_sql "ALTER TABLE cs1 CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_bin"
run_sql "SHOW CREATE TABLE cs1"
run_sql "CREATE TABLE alg (id INT PRIMARY KEY) ENGINE=InnoDB"
run_sql "ALTER TABLE alg ADD COLUMN c1 INT, ALGORITHM=INSTANT"
run_sql "ALTER TABLE alg ADD COLUMN c2 INT, ALGORITHM=INPLACE, LOCK=NONE"
run_sql "ALTER TABLE alg ADD COLUMN c3 INT, ALGORITHM=COPY, LOCK=EXCLUSIVE"
run_sql "ALTER TABLE alg ADD COLUMN c4 INT, ALGORITHM=INSTANT, LOCK=NONE"
run_sql "ALTER TABLE alg FORCE"
run_sql "ALTER TABLE alg ORDER BY id"
run_sql "CREATE TABLE k1 (id INT) ENGINE=InnoDB COMPRESSION='zlib'"
run_sql "SHOW CREATE TABLE k1"
run_sql "CREATE TABLE en1 (id INT) ENGINE=InnoDB ENCRYPTION='Y'"
run_sql "CREATE TABLE st1 (id INT) ENGINE=InnoDB STATS_PERSISTENT=1 STATS_AUTO_RECALC=0 STATS_SAMPLE_PAGES=16"
run_sql "SHOW CREATE TABLE st1"
run_sql "ALTER TABLE st1 STATS_PERSISTENT=DEFAULT"
run_sql "CREATE TABLE im2 (id INT) ENGINE=InnoDB INSERT_METHOD=FIRST"
run_sql "CREATE TABLE im1 (id INT) ENGINE=MyISAM INSERT_METHOD=FIRST"
run_sql "ALTER TABLE e2 DISABLE KEYS"
run_sql "ALTER TABLE e2 ENABLE KEYS"
run_sql "CREATE TABLE ts1 (id INT) TABLESPACE=innodb_file_per_table"
run_sql "SHOW CREATE TABLE ts1"
