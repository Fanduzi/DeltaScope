# T15-R3 ER9 — native evidence labels & OOM ledger (corrected)

## Per-anchor evidence labels
| Anchor | Version | Evidence | Label |
|--------|---------|----------|-------|
| mysql57 | 5.7.44 | native-mysql.log (R1) | REUSED historical-committed; version-observed; digest-bound (mysql@sha256:4bc6bc… amd64) |
| mysql80 | 8.0.46 | native-mysql.log (R1) | REUSED; version-observed; digest-bound (…7dcddc01… arm64) |
| mysql84 | 8.4.10 | native-mysql.log (R1) | REUSED; version-observed; digest-bound (…8dbcf531… arm64) |
| tidb85 | 8.0.11-TiDB-v8.5.0 | native-tidb.log (R1) + tidb-algo-lock-r2.txt (R2) + tidb-algo-lock-r3.txt (R3) | R3 = NEW RUN per-statement rc truth — supersedes R2 wording; digest-bound (…490861bd… arm64) |

Correction: the R1 `native-mysql.log` retains its original (partially
truncated) form — it is labeled REUSED-historical, NOT re-claimed as
untruncated. The R3 TiDB probe is fully untruncated.

## OOM ledger — R1 vs R2 attribution
- The stale TiDB **volume cleanup** (stale secret causing 1045s) happened
  during **R1** evidence gathering, NOT in R2. R2 ran zero container
  lifecycle operations on other-task workloads (the only R2 docker ops
  were the task-owned golden stack start/stop via the runner itself).
- R1 incident detail: TiDB `deltascope-ddl-golden-tidb85` exited 137,
  `OOMKilled=true` (docker inspect evidence at the time). Host VM
  ≈10 GB total; competing memory pressure came from unrelated idle
  containers (h1run/t26 families). ~11 external containers were stopped
  in R1 to free memory; all were verified idle (no active work);
  disposable fixtures only — no data loss, no running-task workloads
  touched.
- Before/after: before — repeated 120/180s metadata timeouts, TiDB
  unhealthy; after — full T15 Golden 42/42 completed green.
- R3 note: this round started ONLY the task-owned
  `deltascope-ddl-golden-tidb85` + `-client` for the ER1 re-probe and
  removed them afterwards; zero other-task containers touched.
