#!/usr/bin/env python3
"""T15-R5 standalone golden validator — reads RAW artifact + frozen
T15.json manifest; validates all four kinds with real field bindings;
runs directed negative self-tests invoking the verifier itself.
Run from its own dir: python3 validate_r5.py [--selftest]
Expects ../golden/{artifact.json,matrix-r5.json,T15.json}."""
import json, sys, os, copy, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ART = os.path.join(HERE, '..', 'golden', 'artifact.json')
MAT = os.path.join(HERE, '..', 'golden', 'matrix-r5.json')
MAN = os.path.join(HERE, '..', 'golden', 'T15.json')
REQUIRED_KINDS = {'cli_audit':17,'cli_metadata':17,'db_ddl':4,'db_syntax_negative':4}

def F(sts,key):
    out=[]
    for st in sts or []:
        for f in st.get(key) or []: out.append(f)
    return out

def steps_of(blk):
    """cli_metadata phase blocks are step ARRAYS."""
    if blk is None: return []
    if isinstance(blk,dict): return [blk]
    return blk

def derive_case(c):
    k=c['kind']; e=c.get('expected',{}); a=c.get('actual',{})
    sql=c.get('input_sql','')
    sql='; '.join(sql) if isinstance(sql,list) else str(sql)
    r={'case_id':c['case_id'],'kind':k,'anchor':c.get('anchor'),'sql':sql,
       'assertions':len(c.get('assertions',[])),
       'assert_ok':all(x.get('ok') for x in c.get('assertions',[])),
       'status':c.get('status')}
    if k in ('cli_audit','cli_metadata'):
        p=a.get('parsed',{})
        r.update({
         'exit_e':e.get('exit'),'exit_a':a.get('exit'),
         'verdict_e':e.get('verdict'),'verdict_a':p.get('verdict'),
         'cov_e':e.get('coverage'),'cov_a':(p.get('coverage') or {}).get('status'),
         'stmt_cov_e':e.get('statement_coverage'),
         'stmt_cov_a':[(s.get('coverage') or {}).get('status') for s in p.get('statements',[])],
         'findings_e':e.get('finding_entries',[]),
         'findings_a':[{'index':i,'rule_id':f.get('rule_id'),'level':f.get('level')} for i,f in enumerate(F(p.get('statements'),'findings'))],
         'gaps_e':e.get('evidence_gaps'),
         'gaps_a':len(F(p.get('statements'),'evidence_gaps')),
         'gap_entries_a':[{'rule_id':g.get('rule_id'),'reason_code':g.get('reason_code'),'required_facts':g.get('required_facts')} for g in F(p.get('statements'),'evidence_gaps')],
         'unsup_e':e.get('unsupported'),
         'unsup_a':len(p.get('unsupported') or []),
         'unsup_entries_a':[{'feature':u.get('feature'),'sql':u.get('sql'),'reason':u.get('reason'),'metadata':u.get('metadata')} for u in (p.get('unsupported') or [])],
         'diag_e':e.get('diagnostics'),
         'diag_a':len(p.get('diagnostics') or []),
         'diag_entries_a':[{'classification':x.get('classification'),'audited':x.get('audited')} for x in (p.get('diagnostics') or [])],
         'version':e.get('version')})
        if k=='cli_metadata':
            for phase in ('setup','execute','post_verify','teardown'):
                r[phase]=[{'name':s.get('name'),'sql':s.get('sql'),'rc':s.get('rc'),
                   'stdout':s.get('stdout'),'stderr':s.get('stderr'),
                   'verify':[{'assert':v.get('assert'),'sql':v.get('sql'),'rc':v.get('rc'),'output':v.get('output'),'stderr':v.get('stderr')} for v in s.get('verify',[])]}
                  for s in steps_of(a.get(phase))]
            r['database']=a.get('database')
    elif k=='db_ddl':
        r['steps']=[{'name':s.get('name'),'sql':s.get('sql'),'rc':s.get('rc'),
          'stdout':s.get('stdout'),'stderr':s.get('stderr'),
          'verify':[{'assert':v.get('assert'),'sql':v.get('sql'),'rc':v.get('rc'),'output':v.get('output'),'stderr':v.get('stderr')} for v in s.get('verify',[])]}
          for s in a.get('steps',[])]
        r['steps_e']=[{'name':s.get('name'),'rc':s.get('rc'),
          'verify':[{'assert':v.get('assert'),'expect':v.get('expect')} for v in s.get('verify',[])]} for s in e.get('steps',[])]
        r['database']=a.get('database')
    elif k=='db_syntax_negative':
        r.update({'rc_nonzero_e':e.get('rc_nonzero'),'error_class_e':e.get('error_class'),
          'argv_a':a.get('argv'),'rc_a':a.get('rc'),'stdout_a':a.get('stdout'),
          'stderr_a':a.get('stderr'),'error_class_a':a.get('error_class'),
          'forbidden_markers':e.get('forbidden_markers')})
    return r

def oracle_checks(rows, errs):
    """Expected-vs-actual semantic judgment (independent of matrix)."""
    for r in rows:
        cid=r['case_id']; k=r['kind']
        if k in ('cli_audit','cli_metadata'):
            if r['exit_e']!=r['exit_a']: errs.append(f"{cid}.exit {r['exit_e']}!={r['exit_a']}")
            if r['verdict_e']!=r['verdict_a']: errs.append(f"{cid}.verdict")
            if r['cov_e']!=r['cov_a']: errs.append(f"{cid}.coverage")
            if r.get('stmt_cov_e')!=r.get('stmt_cov_a'): errs.append(f"{cid}.stmt_cov")
            if r['gaps_e']!=r['gaps_a']: errs.append(f"{cid}.gaps")
            if r['unsup_e']!=r['unsup_a']: errs.append(f"{cid}.unsup")
            if r['diag_e']!=r['diag_a']: errs.append(f"{cid}.diag")
            fe,fa=r.get('findings_e') or [],r.get('findings_a') or []
            if len(fe)!=len(fa): errs.append(f"{cid}.findings len")
            else:
                for i,(x,y) in enumerate(zip(fe,fa)):
                    if x.get('rule_id')!=y.get('rule_id') or x.get('level')!=y.get('level'):
                        errs.append(f"{cid}.findings[{i}]")
        elif k=='db_ddl':
            se,sa=r.get('steps_e') or [],r.get('steps') or []
            if len(se)!=len(sa): errs.append(f"{cid}.steps len {len(se)}!={len(sa)}")
            for i,(x,y) in enumerate(zip(se,sa)):
                if x.get('name')!=y.get('name'): errs.append(f"{cid}.steps[{i}].name")
                if x.get('rc')!=y.get('rc'): errs.append(f"{cid}.steps[{i}].rc {x.get('rc')}!={y.get('rc')}")
                ve,va=x.get('verify') or [],y.get('verify') or []
                if len(ve)!=len(va): errs.append(f"{cid}.steps[{i}].verify len")
                for j,(vx,vy) in enumerate(zip(ve,va)):
                    if vx.get('expect')!=vy.get('output'):
                        errs.append(f"{cid}.steps[{i}].verify[{j}] expect={vx.get('expect')!r} output={vy.get('output')!r}")
        elif k=='db_syntax_negative':
            if r['error_class_e']!=r['error_class_a']: errs.append(f"{cid}.error_class")
            if bool(r['rc_nonzero_e']) != bool(r['rc_a']): errs.append(f"{cid}.rc_nonzero")
            for m in r.get('forbidden_markers') or []:
                if m in (r.get('stderr_a') or '') or m in (r.get('stdout_a') or ''):
                    errs.append(f"{cid}.forbidden_marker {m!r} present")

def deep_cmp(a,b,path,errs):
    if type(a)!=type(b): errs.append(f"{path}: type"); return
    if isinstance(a,dict):
        for k in set(a)|set(b):
            if k not in a or k not in b: errs.append(f"{path}.{k}")
            else: deep_cmp(a[k],b[k],f"{path}.{k}",errs)
    elif isinstance(a,list):
        if len(a)!=len(b): errs.append(f"{path}: len")
        for i,(x,y) in enumerate(zip(a,b)): deep_cmp(x,y,f"{path}[{i}]",errs)
    elif a!=b: errs.append(f"{path}: {a!r}!={b!r}")

def verify(mat_path,art_path,man_path=MAN):
    errs=[]
    art=json.load(open(art_path))
    cases=art['cases']
    kinds={}
    for c in cases: kinds[c['kind']]=kinds.get(c['kind'],0)+1
    if kinds!=REQUIRED_KINDS: errs.append(f"kinds {kinds}")
    ids=[c['case_id'] for c in cases]
    if len(ids)!=len(set(ids)): errs.append('dup case_id artifact')
    if len(cases)!=42: errs.append(f"cases {len(cases)}")
    na=sum(len(c.get('assertions',[])) for c in cases)
    if na!=480: errs.append(f"assertions {na}")
    bad=[c['case_id'] for c in cases if not all(x.get('ok') for x in c.get('assertions',[]))]
    if bad: errs.append(f"assert fail {bad}")
    notpass=[c['case_id'] for c in cases if c.get('status')!='pass']
    if notpass: errs.append(f"status!=pass {notpass}")
    if os.path.exists(man_path):
        man=json.load(open(man_path))
        req=man.get('required_case_ids') or []
        if set(req)!=set(ids): errs.append(f"required!=executed diff={set(req)^set(ids)}")
        if len(req)!=len(ids): errs.append(f"required {len(req)}!=executed {len(ids)}")
    rows=[derive_case(c) for c in cases]
    oracle_checks(rows, errs)
    if mat_path and os.path.exists(mat_path):
        mrows=json.load(open(mat_path))
        mids=[r['case_id'] for r in mrows]
        if len(mids)!=len(set(mids)): errs.append('dup case_id matrix')
        if len(mrows)!=len(cases): errs.append(f"matrix rows {len(mrows)}")
        dmap={r['case_id']:r for r in rows};mmap={r['case_id']:r for r in mrows}
        for cid in dmap:
            if cid in mmap: deep_cmp(mmap[cid],dmap[cid],cid,errs)
    return errs

def neg_selftest(mat_path,art_path,man_path):
    base_m=json.load(open(mat_path)); base_a=json.load(open(art_path)); base_man=json.load(open(man_path))
    results=[]
    def run(name,mut_mat=None,mut_art=None,mut_man=None):
        tm=tempfile.NamedTemporaryFile('w',suffix='.json',delete=False)
        ta=tempfile.NamedTemporaryFile('w',suffix='.json',delete=False)
        tn=tempfile.NamedTemporaryFile('w',suffix='.json',delete=False)
        m=copy.deepcopy(base_m); a=copy.deepcopy(base_a); n=copy.deepcopy(base_man)
        if mut_mat: mut_mat(m)
        if mut_art: mut_art(a)
        if mut_man: mut_man(n)
        json.dump(m,tm);tm.close();json.dump(a,ta);ta.close();json.dump(n,tn);tn.close()
        errs=verify(tm.name,ta.name,tn.name)
        os.unlink(tm.name);os.unlink(ta.name);os.unlink(tn.name)
        results.append({'test':name,'detected':bool(errs),'path':(errs[0] if errs else '')})
    cli=[i for i,r in enumerate(base_m) if r['kind']=='cli_audit'][0]
    meta=[i for i,r in enumerate(base_m) if r['kind']=='cli_metadata'][0]
    db=[i for i,r in enumerate(base_m) if r['kind']=='db_ddl'][0]
    neg=[i for i,r in enumerate(base_m) if r['kind']=='db_syntax_negative'][0]
    ccli=[i for i,c in enumerate(base_a['cases']) if c['kind']=='cli_audit'][0]
    cmeta=[i for i,c in enumerate(base_a['cases']) if c['kind']=='cli_metadata' and c['actual'].get('execute')][0]
    cdb=[i for i,c in enumerate(base_a['cases']) if c['kind']=='db_ddl'][0]
    cneg=[i for i,c in enumerate(base_a['cases']) if c['kind']=='db_syntax_negative'][0]
    cuns=[i for i,c in enumerate(base_a['cases']) if (c['actual'].get('parsed') or {}).get('unsupported')]
    cuns=cuns[0] if cuns else ccli
    # R4 legacy 17
    run('mat-verdict',mut_mat=lambda m:m[cli].__setitem__('verdict_a','reject'))
    run('mat-coverage',mut_mat=lambda m:m[cli].__setitem__('cov_a','incomplete'))
    run('mat-finding',mut_mat=lambda m:m[cli]['findings_a'][0].__setitem__('rule_id','x') if m[cli]['findings_a'] else None)
    run('mat-gap',mut_mat=lambda m:m[cli].__setitem__('gaps_a',9))
    run('mat-meta-exit',mut_mat=lambda m:m[meta]['execute'][0].__setitem__('rc',99) if m[meta].get('execute') else None)
    run('mat-db-rc',mut_mat=lambda m:m[db]['steps'][0].__setitem__('rc',9))
    run('mat-db-verify',mut_mat=lambda m:m[db]['steps'][1]['verify'][0].__setitem__('output','99') if len(m[db]['steps'])>1 and m[db]['steps'][1].get('verify') else None)
    run('mat-neg-rc',mut_mat=lambda m:m[neg].__setitem__('rc_a',0))
    run('mat-sql',mut_mat=lambda m:m[cli].__setitem__('sql','SELECT 1'))
    run('mat-drop',mut_mat=lambda m:m.pop())
    run('mat-dup',mut_mat=lambda m:m.append(copy.deepcopy(m[0])))
    run('mat-assert-n',mut_mat=lambda m:m[cli].__setitem__('assertions',1))
    run('mat-assert-ok',mut_mat=lambda m:m[cli].__setitem__('assert_ok',False))
    run('art-verdict',mut_art=lambda a:a['cases'][ccli]['actual']['parsed'].__setitem__('verdict','reject'))
    run('art-verify',mut_art=lambda a:a['cases'][cdb]['actual']['steps'][1]['verify'][0].__setitem__('output','99') if len(a['cases'][cdb]['actual']['steps'])>1 and a['cases'][cdb]['actual']['steps'][1].get('verify') else None)
    run('art-neg-class',mut_art=lambda a:a['cases'][cneg]['actual'].__setitem__('error_class','9999'))
    run('art-assert-ok',mut_art=lambda a:a['cases'][ccli]['assertions'][0].__setitem__('ok',False))
    # R5 directed 12
    run('R5-meta-exec-rc',mut_art=lambda a:a['cases'][cmeta]['actual']['execute'][0].__setitem__('rc',99))
    run('R5-meta-verify-out',mut_art=lambda a:a['cases'][cmeta]['actual']['execute'][0]['verify'][0].__setitem__('output','BAD') if a['cases'][cmeta]['actual']['execute'][0].get('verify') else a['cases'][cmeta]['actual']['execute'][0].__setitem__('stdout','BAD'))
    run('R5-meta-drop-step',mut_art=lambda a:a['cases'][cmeta]['actual']['execute'].pop())
    run('R5-art-del-unsup',mut_art=lambda a:a['cases'][cuns]['actual']['parsed'].__setitem__('unsupported',None))
    run('R5-art-add-unsup',mut_art=lambda a:(a['cases'][ccli]['actual']['parsed'].setdefault('unsupported',[]) or a['cases'][ccli]['actual']['parsed']['unsupported']).append({'feature':'x','sql':'y','reason':'z','metadata':{}}))
    run('R5-exp-unsup',mut_mat=lambda m:[r.__setitem__('unsup_e',0) for r in m if r['kind']=='cli_audit' and r.get('unsup_e')])
    run('R5-exp-db-rc',mut_art=lambda a:a['cases'][cdb]['expected']['steps'][0].__setitem__('rc',9))
    run('R5-exp-db-verify',mut_art=lambda a:a['cases'][cdb]['expected']['steps'][1]['verify'][0].__setitem__('expect','999') if len(a['cases'][cdb]['expected']['steps'])>1 and a['cases'][cdb]['expected']['steps'][1].get('verify') else a['cases'][cdb]['expected']['steps'][0].__setitem__('rc',9))
    run('R5-art-db-verify',mut_art=lambda a:a['cases'][cdb]['actual']['steps'][1]['verify'][0].__setitem__('output','ZZZ') if len(a['cases'][cdb]['actual']['steps'])>1 and a['cases'][cdb]['actual']['steps'][1].get('verify') else a['cases'][cdb]['actual']['steps'][0].__setitem__('rc',9))
    run('R5-neg-class',mut_art=lambda a:a['cases'][cneg]['actual'].__setitem__('error_class','0000'))
    run('R5-req-swap',mut_man=lambda n:n.__setitem__('required_case_ids',[n['required_case_ids'][0].replace(n['required_case_ids'][0].split('.')[-1],'nonexistent-zzz')]+n['required_case_ids'][1:]))
    run('R5-status-fail',mut_art=lambda a:a['cases'][ccli].__setitem__('status','fail'))
    for r in results: print(f"{r['test']}\t{'DETECTED' if r['detected'] else 'MISS'}\t{r['path']}")
    return results

if __name__=='__main__':
    errs=verify(MAT,ART,MAN)
    print(f"verify: {len(errs)} mismatches")
    for e in errs[:20]: print(' ',e)
    if '--selftest' in sys.argv:
        res=neg_selftest(MAT,ART,MAN)
        d=sum(1 for r in res if r['detected'])
        print(f"selftest {d}/{len(res)} detected")
        sys.exit(1 if (errs or d!=len(res)) else 0)
    sys.exit(1 if errs else 0)
