# T15-R3 ER1 — TiDB ALGORITHM/LOCK per-statement truth (corrects R2)

Anchor: `8.0.11-TiDB-v8.5.0` @ `pingcap/tidb@sha256:490861bd4a2f…`
linux/arm64. NEW RUN `probes/tidb-algo-lock-r3.txt`: every ALTER in its
OWN `mysql -e` invocation with independent rc; SHOW WARNINGS in the
SAME session; column count + final SHOW CREATE TABLE per step.

## R2 erratum (what was wrong)
R2 classified `ALGORITHM=INPLACE`/`COPY` on ADD COLUMN as "vendor
refusal / atomic failure" — inferred from a SHOW WARNINGS Error-level
1846 row in a batched session. That was wrong on two counts:
1. SHOW WARNINGS Level=Error is NOT the statement's exit code.
2. The final SHOW CREATE already showed the columns had landed.

## Per-statement truth
| SQL | rc | Session warning | Applied? | Classification |
|-----|----|-----------------|----------|----------------|
| ADD COLUMN (no decl) | 0 | none | yes | baseline success |
| ADD COLUMN ALGORITHM=INSTANT | 0 | none | yes | assertion satisfied — real instant path |
| ADD COLUMN ALGORITHM=INPLACE | 0 | Error 1846 "not supported … Try INSTANT" | **yes** | **succeeded with downgrade warning** — NOT a refusal |
| ADD COLUMN ALGORITHM=COPY | 0 | Error 1846 "not supported … Try INSTANT" | **yes** | succeeded with downgrade warning |
| ADD INDEX ALGORITHM=INSTANT | **1** | hard ERROR 1846 (0A000) | **no** | **true vendor refusal** |
| ADD INDEX ALGORITHM=COPY | 0 | Error 1846 warning | yes | succeeded with downgrade warning |
| LOCK=NONE / SHARED / EXCLUSIVE | 0 | none | yes | accepted compatibility declaration — no lock mode selected |
| INSTANT+LOCK=NONE | 0 | none | yes | both semantics combine |
| COPY+LOCK=EXCLUSIVE | 0 | Error 1846 warning | yes | downgrade warning; LOCK accepted declaration |

## Product cross-check (no product defect)
`spec.tidbOnlineDDLOutcome` @ db17cf6d:
- `algorithm != "instant"` (inplace/copy/absent) → `OnlineDDLCombinable`
  — statement proceeds, exactly matching "succeeded with warning".
- `algorithm=instant` + `add_index` → `OnlineDDLRefused(1846)` —
  matching the probed hard refusal.
- `algorithm=instant` + unprobed ops → `OnlineDDLUnproven` — honest.
So the product's TiDB branch was ALREADY correct; only the R2 evidence
document wording was wrong. Per the R3 order this is a docs/evidence
correction — no DEFECT-STOP.
