package main

import (
	"context"
	"encoding/json"
	"fmt"

	ds "github.com/Fanduzi/DeltaScope/pkg/deltascope"
)

func main() {
	res, err := ds.Audit(context.Background(), ds.Request{
		SQL:     "ALTER TABLE t STATS_PERSISTENT=1;",
		Dialect: ds.DialectMySQL,
	})
	if err != nil {
		panic(err)
	}
	b, _ := json.MarshalIndent(res, "", " ")
	fmt.Println(string(b))
}
