# T15-R4 ER3 — golden-complete vs parity-unverified: REAL cause

## R3 erratum
R3 claimed the difference was "golden uses LIVE metadata". WRONG —
the golden case is also offline (`context.mode=offline`,
`context.note="existence not checked"`, anchor=null, connect=null in
the artifact). Both sides are offline.

## Actual mechanism — rule enablement, not metadata
- Golden `t15-cli-stats-persistent-gap` runs under
  `policy_profile=t15-table-option`: an ISOLATED profile rendered by
  `scripts/ddl_golden.py` — 3 rules enabled
  (table_option.compatibility.require/​applicability/​warn), every other
  cataloged rule `enabled: false` — including
  `ddl.table.exists.alter.require`, the rule that emits the
  `unknown_table_state` evidence gap for offline ALTERs.
- Parity probes ran the CLI's DEFAULT policy where that require rule
  is enabled → 1 evidence gap → coverage.status=unverified.

## Live reproduction (offline, default+one-disable config)
`deltascope audit --file t15r2.sql --dialect mysql --config
t15noexist.yaml` where the config ONLY sets
`ddl.table.exists.alter.require.enabled=false`:
→ coverage=complete, gaps=0 — byte-identical conclusion to golden.
Config SHAs archived; golden-policy render logic at
scripts/ddl_golden.py:524-541 (`enabled: false` for every unlisted id).

## Rule/gap mechanism (source)
`ddl.table.exists.alter.require` = tableExistenceRule
(internal/domain/rule/ddl/metadata_rules.go:38, registered at
register.go:645-646); its `EvidenceGaps()` emits
`unknown_table_state`/`required_facts=[target_table.existence]` when
the statement targets a table whose existence is unprovable — only
when the rule is enabled.

## Same SQL + different policy → exact delta
same SQL `ALTER TABLE t STATS_PERSISTENT=1;` · same dialect mysql ·
same offline mode · DIFFERENT rule enablement →
require-rule enabled: verdict review, 1 warn + 1 gap, cov unverified ·
require-rule disabled: verdict review, 1 warn + 0 gap, cov complete.
Coverage semantics unchanged — the gap is a rule-emitted artifact of
enablement, not a product inconsistency.
