# T15-R3 ER5 — four-surface parity I/O & context-difference proof

## Input identity (all four surfaces, this round)
- SQL: `ALTER TABLE t STATS_PERSISTENT=1;` (single statement, no schema)
- Dialect: `mysql`; policy: built-in defaults (no YAML loaded)
- Mode: offline — NO metadata connection on any surface
- Binaries: `vcs.revision=db17cf6d53418f776008848d94962c91f5471cdc`
  (go version -m evidence below); MCP banner carries same revision.

## Per-surface raw I/O
- CLI: `bin/deltascope audit --file /tmp/t15r2.sql --dialect mysql
  --format json` → rc 0 → `parity/cli-stats.json`
- SDK: `pkg/deltascope Audit(ctx, Request{SQL, Dialect:DialectMySQL})`
  → `parity/sdk-stats.json` (probe source `/tmp/sdk_probe.go`, archived)
- HTTP: `bin/deltascope-server -listen 127.0.0.1:18899`; POST /v1/audit
  body `{"sql":"...","dialect":"mysql"}` → `parity/http-stats.json`
- MCP: `bin/deltascope-mcp` stdio — frames in `parity/mcp-stats.txt`:
  line1 `initialize` response id=1 (protocol 2024-11-05, serverInfo
  deltascope-mcp v0.511.2-0.20261114100350-db17cf6d5341+dirty);
  line2 `tools/call` response id=2 for `audit_sql` — includes BOTH
  textual content and `structuredContent`; `isError` absent; line3
  tools/list_changed notification. Request frames sent:
  initialize id=1, notifications/initialized, tools/call id=2 — raw
  request stream preserved as `parity/mcp-requests.txt`.

## Result (all four identical semantics)
verdict=review · coverage.status=unverified · 1 warning
`ddl.alter.table_option.warn` · 1 evidence_gap
(`ddl.table.exists.alter.require` / unknown_table_state /
required_facts=[target_table.existence]) · 0 unsupported · 0 diagnostics
· summary warnings=1.

## Golden-complete vs parity-unverified — the difference is context,
## not product semantics
- Golden `t15-cli-stats-persistent-gap` runs the CLI with a LIVE
  metadata connection (its fixture anchors): `target_table.existence`
  is provable → `coverage=complete`, `evidence_gaps=0`.
- The parity probes deliberately run offline (no DB): existence cannot
  be proven → the shared layer emits the honest evidence gap and
  coverage.status=`unverified`.
- Both outcomes come from the SAME adjudication layer; the verdict,
  finding id/level and unsupported set are identical. Transport
  differences (JSON shape, MCP structuredContent, exit semantics) are
  surface behavior only — the work order's own distinction.
