# T15-R3 ER3 — STATS_* value fidelity + AC4 branch proofs

## 1. STATS_* authored-value fidelity (probe @ db17cf6d)
`parseSQL`+`Extract` output for each form:
- `STATS_PERSISTENT=0` / `=1` / `=DEFAULT` → `{stats_persistent: "declared"}`
- `STATS_AUTO_RECALC=DEFAULT` → `{stats_auto_recalc: "default"}`; `=0` → `"0"`
- `STATS_SAMPLE_PAGES=8` → `"8"`; `=DEFAULT` → `"default"`

Honest limitation: `STATS_PERSISTENT` keeps presence only — the grammar
discards the authored 0/1/DEFAULT token (recorded in
`docs/decisions/2026-11-08-ddl-table-options-online-ddl.md`, which
describes this extraction contract). AUTO_RECALC/SAMPLE_PAGES keep the
full authored value.

Consequence admitted: for STATS_PERSISTENT the prospective state cannot
publish the concrete flag value — only the declaration event, gated by
a warning. `coverage=complete` is still correct: every EXTRACTED aspect
(name + declared presence) is consumed by audited semantics; the
discarded value never enters the aspect set — this is the documented
bounded-extraction contract, not a silently-dropped aspect. The warn
finding message says "controls whether InnoDB statistics persist across
restarts" with suggestion to verify effect — it does not claim the
authored value was audited.

## 2. AC4 branch-by-branch proof (before → action → after)
Fixture `t15StatsShape` (test source in batch_state_t15_test.go):
Options {engine:InnoDB, row_format:DYNAMIC, charset:utf8mb4,
collation:utf8mb4_0900_ai_ci, table_rows:2, data_length:100,
index_length:40, avg_row_length:50, auto_increment:3} + PK cardinality 5
+ secondary idx_s cardinality 5.

| Action | Branch | After |
|--------|--------|-------|
| ENGINE=MyISAM | `alterOptionRebuilds` → clear both | all stats dropped |
| ROW_FORMAT=COMPRESSED | same | all dropped |
| CONVERT TO CHARACTER SET | same | all dropped |
| COMPRESSION='zlib' | same | all dropped |
| ENCRYPTION='Y' | same | all dropped |
| TABLESPACE=… | same | all dropped |
| KEY_BLOCK_SIZE=4 | same | all dropped |
| COMMENT='x', ENGINE=MyISAM (multi-action) | multi path rebuild scan | all dropped |
| ORDER BY id | maintenance: full rebuild | all dropped |
| FORCE | maintenance: full rebuild | all dropped |
| DISABLE/ENABLE KEYS on MyISAM | index rebuild only | table_rows kept; PK+idx cardinality dropped |
| DISABLE/ENABLE KEYS on InnoDB | server ignores toggle | ALL kept |
| COMMENT='x' | instant | table_rows kept |
| STATS_PERSISTENT=1 | instant | kept |
| DEFAULT CHARACTER SET | instant | kept |
| INSERT_METHOD=LAST | instant | kept |

Single-action path: `applyTableOptionAlter` + `applyMaintenanceAlter`.
Multi-action path: `prepareMultiAction` post-option rebuild scan.
Tests: `TestT15AC4RebuildOptionInvalidatesStats` (10 rebuild + 4 instant
subtests), `TestT15AC4KeysToggleDropsIndexCardinalityOnly` (MyISAM+InnoDB
× DISABLE/ENABLE = 4 subtests) — raw `-v -count=1` output archived at
`gates/focused-raw.log` (23 RUN, 0 FAIL, rc=0 at db17cf6d).
