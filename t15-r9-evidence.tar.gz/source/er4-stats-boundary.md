# T15-R4 ER4 — STATS_PERSISTENT presence-only boundary vs #94 AC4

## ADR authority (verbatim)
`docs/decisions/2026-11-08-ddl-table-options-online-ddl.md`
- commit `ba56922c9e02343934f3f400b93cde29b5b5baa5` (2026-10-29 author
  date; file dated 2026-11-08), HEAD blob `c7de0ecb9a1220b3ce2c3231f07874c84f6f7d6b`
- §3: "The grammar discards `STATS_PERSISTENT`/`PACK_KEYS` authored
  values, so those record the presence marker `declared`, never a
  fabricated number."
- §1: "Rules, coverage, and ordered state consume the same answer —
  they can never disagree about whether a declaration was audited."
- §4: unaudited keys keep BOUNDED `alter_table.option.<name>` gaps —
  meaning the contract's completeness claim is "every extracted aspect
  is classified", not "every authored token is preserved".
- Archived verbatim at `source/adr-original.md`.

## Scope of the approved boundary
APPROVED: presence-marker extraction for the two grammar-discarded
options (`stats_persistent`, `pack_keys`); classifying that presence
as a consumed audited aspect; warning without a fabricated value.
NOT approved by this ADR: claiming the authored 0/1/DEFAULT value was
audited; publishing a concrete persistent flag into prospective state;
treating DEFAULT-reset semantics as value-verified.
The product stays inside the approved scope: it surfaces the option as
an audited warning finding, publishes NO catalog value for it, and
does not pretend the flag value is known.

## Full chain — 0 vs 1 vs DEFAULT (probe @ db17cf6d)
| SQL | AST | extractor | spec.Options | aspects | prospective state | coverage |
|-----|-----|-----------|--------------|---------|-------------------|----------|
| STATS_PERSISTENT=0 | TableOptionStatsPersistent(uint) | `"declared"` | {stats_persistent:declared} | consumed (mysqlAlterConsumedOptions) | nothing published (no fabricated flag) | complete + warn |
| STATS_PERSISTENT=1 | same | `"declared"` | same | same | same | complete + warn |
| STATS_PERSISTENT=DEFAULT | same | `"declared"` | same | same | same | complete + warn |
| STATS_AUTO_RECALC=DEFAULT | TableOptionStatsAutoRecalc(Default) | `"default"` | {stats_auto_recalc:default} | consumed | nothing published | complete + warn |
| STATS_AUTO_RECALC=0 | uint 0 | `"0"` | {stats_auto_recalc:0} | consumed | nothing published | complete + warn |
| STATS_SAMPLE_PAGES=8 | uint 8 | `"8"` | {stats_sample_pages:8} | consumed | nothing published | complete + warn |
| STATS_SAMPLE_PAGES=DEFAULT | Default | `"default"` | {stats_sample_pages:default} | consumed | nothing published | complete + warn |

## What is and is not audited — stated plainly
- Preserved facts: option name presence (all three), authored value
  (auto_recalc/sample_pages: numeric or `default`).
- Not audited: the concrete flag of STATS_PERSISTENT (0/1/DEFAULT are
  indistinguishable by design); DEFAULT-reset vs explicit-value
  distinction for stats_persistent specifically.
- No fact is marked "unknown" because none was extracted — the
  discarded token never enters the aspect model (approved boundary).
- No authored semantics are claimed audited: the warn message
  describes what the option controls operationally, and the suggestion
  tells the reviewer to verify live effect — the finding does not
  assert the declared value took effect.

## AC4 reconciliation
AC4 requires option changes to update batch facts and invalidate
related stats + independent assertions for default/reset. The ADR
boundary answers how: stats options are catalog directives that
control server-side statistics maintenance — the product records the
declaration (warn) and publishes NO new state value, while the
table_rows/cardinality facts they can refresh are governed by the
rebuild-invalidation rules added in db17cf6d. DEFAULT/reset has an
independent assertion in the manifest for the options whose values
ARE extracted (auto_recalc/sample_pages default forms), and
STATS_PERSISTENT's reset form is audited as the same declaration by
approved contract.
