# T15-R9 evidence pack — README accounting fix

Frozen product HEAD: db17cf6d53418f776008848d94962c91f5471cdc (parent 9d2c439c…).

R9 scope (evidence-only, README errata):
- R8 residual: this README still carried the pre-removal member counts
  (from the round when independent-verify.txt was an in-archive member).
- R8→R9 file-path set is UNCHANGED — only this README text is corrected.
- independent-verify.txt is NOT a member of this archive; the final
  verification log lives outside the sealed archive (delivered in receipt).
- Carried forward REUSED: R6 12-process-exit proof, R5 29/29 in-process
  selftests, validator, matrix, field-binding, all golden/gates/
  regressions/parity/native/perf/OOM evidence.
- privacy-scan.txt: denominator 54 = 56 members − manifest.txt −
  privacy-scan.txt; git-identity email only, all credential classes zero.

Bookkeeping denominators (exact, this archive):
- archive total file members: 56 (manifest.txt included)
- manifest.txt entries: 55 — unique paths, one per physical member
- payload-index.txt entries: 53 payload files
- bookkeeping members (manifest-covered, not in payload-index): 2
  (payload-index.txt, reuse-ledger.txt)
- privacy-scan.txt: 1 payload member
- privacy scan denominator: 54 = 56 − manifest.txt − privacy-scan.txt

Classification vs R8 archive: payload 52 REUSED / 1 NEW (README.md).
The 2 bookkeeping files are regenerated, not part of payload classification.
