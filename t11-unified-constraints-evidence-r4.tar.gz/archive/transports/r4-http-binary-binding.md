# R4 — HTTP server binary identity binding

## Original binary (R2 probe)
- Path: `bin/deltascope-server`, SHA-256 `855b0d0ed69374ca24d7617a4bb2f4a3a92a77d77cf4d52fdb808cdc7d0e470e` (68,580,114B)
- `go version -m`: `vcs.revision=ce7cda29275f2c324c4007fb8936c131cbb3618c`, `vcs.time=2026-11-13T12:29:51Z`, `vcs.modified=true`, go1.26.3, darwin/arm64, CGO_ENABLED=1
- Relationship to frozen HEAD: `ce7cda29` ("test(ddl-golden): graduate T03 oracle cases…") is an **ancestor** of `9d2c439c46f6` — `git merge-base --is-ancestor ce7cda29 HEAD` → true; `git rev-list --count ce7cda29..HEAD` = 9 commits.
- Product-source delta in those 9 commits: `git diff --stat ce7cda29..HEAD -- internal/ pkg/ cmd/` → only `batch_state_layout_r6.go` (+14, TiDB rename-cache guard) + one test file. Nothing on the MySQL FK-forbid HTTP path.
- Conclusion: original binary's audit-path source is identical for this probe, BUT the binary is not itself built at frozen HEAD → per work order, rebuilt from frozen HEAD and re-probed (definitive binding below).

## R4 rebuilt binary (definitive)
- Build: `CGO_ENABLED=0 go build -o /tmp/t11-r4-build/deltascope-server ./cmd/deltascope-server` in the frozen working tree (isolated output dir; no repo writes)
- Binary SHA-256: `1bb9e595f8ab14b17197ca2dc4bb3a462b2715334a06c19d25bd8a01299bf031`
- `go version -m`: `vcs.revision=9d2c439c46f6faed434e91c8b54ebc82abbf0787` = frozen HEAD exactly; `vcs.modified=true` (untracked evidence/artifacts in tree; tracked diff zero — see ER5 no-change proof)
- Version string: `v0.511.2-0.20261113203735-9d2c439c46f6+dirty`

## R4 HTTP parity probe (single path per order)
- Server argv: `deltascope-server -listen 127.0.0.1:19999 -config /tmp/ddl-golden/T11/golden-policy-t11-fk-forbid.yaml`
- Policy SHA-256: `f371ad78d7bf59ddd496d17c43eea8aec2c2c873c5b3fee012628cc9637a5f9e` (isolated: only `ddl.table.foreign_key.forbid` enabled)
- Request: `POST /v1/audit` `{"sql":"ALTER TABLE child ADD CONSTRAINT fk_c FOREIGN KEY (c) REFERENCES parent(id);","dialect":"mysql"}`
- Response (`r4-http-probe-response.json`): **HTTP 200**; `verdict=reject`; `coverage.status=complete`; findings=`1× ddl.table.foreign_key.forbid:blocker`; `evidence gaps=0`; `summary: 1 stmt / 1 blocker / 0 warn / 0 notice`
- Matches expected: 200 / reject / complete / 1 blocker / 0 gaps ✓
- Server lifecycle: `r4-http-probe-server.log` — startup log, request log (status 200), SIGTERM shutdown; port 19999 released.
- Note: a first launch attempt bound-failed because an earlier default-policy instance held :19999; that stray produced a default-policy response (unverified+notice) which was discarded and is NOT the parity result — the bound instance log shows only the correct single request.
