# R2 parity matrix — identical SQL + identical isolated policy

| Field | CLI | SDK | HTTP | MCP (config_path) | MCP (default, reproduced) |
|---|---|---|---|---|---|
| verdict | reject | reject | reject | reject | reject |
| coverage | complete | complete | complete | complete | unverified |
| findings | 1× fk.forbid blocker | 1× fk.forbid blocker | 1× fk.forbid blocker | 1× fk.forbid blocker | 1× fk.forbid blocker + 1× add_constraint.notice |
| evidence_gaps | 0 | 0 | 0 | 0 | 2 (exists.alter.require, add_index.exists.forbid) |
| rule_summary.loaded | 1 | 1 | 1 | n/a | n/a |
| exit/return | exit 1 (fail_on_triggered) | Result, nil error | HTTP 200 + verdict reject | isError absent(false→absent), JSON-RPC result | same |

Conclusion: under identical policy+context all four surfaces produce identical semantics — same reject, same coverage=complete, same single blocker. The MCP R1 divergence was a probe configuration omission (config_path not passed), not product divergence. MCP status/error/privacy contract remains: reject carried via verdict field; isError absent on non-error; unverified coverage is honest under default policy without metadata.
