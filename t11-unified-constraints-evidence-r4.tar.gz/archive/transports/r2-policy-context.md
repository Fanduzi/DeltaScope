# R2 transport parity — exact policy/context per surface

## Shared inputs
- SQL: `ALTER TABLE child ADD CONSTRAINT fk_c FOREIGN KEY (c) REFERENCES parent(id);`
- Dialect: mysql (explicit request/flag on every surface)
- Metadata mode: none (offline) on every surface — no connection_ref passed
- Isolated policy: `/tmp/ddl-golden/T11/golden-policy-t11-fk-forbid.yaml` — every rule `enabled: false` except `ddl.table.foreign_key.forbid` (blocker, forbid=true); SHA-256 `f371ad78d7bf59ddd496d17c43eea8aec2c2c873c5b3fee012628cc9637a5f9e`
- Tested HEAD: `9d2c439c46f6faed434e91c8b54ebc82abbf0787`
- Binaries: deltascope `b302f4b3…3697`, deltascope-mcp `95715359…4a5` (server shares deltascope-server `bin` of same build tree — see commands log)

## Per-surface invocation
| Surface | Invocation | Policy binding |
|---|---|---|
| CLI | `deltascope audit --config <pol> --dialect mysql --format json --file fk.sql` | `--config` flag → isolated policy |
| SDK | `deltascope.Audit(ctx, Request{SQL, Dialect: mysql, ConfigPath: <pol>})` (go run probe) | `Request.ConfigPath` → isolated policy |
| HTTP | `deltascope-server -config <pol> -listen 127.0.0.1:18193` + `POST /v1/audit {sql,dialect}` | server flag → isolated policy for all requests |
| MCP (R2) | `deltascope-mcp` stdio; `audit_sql` args `{sql, dialect, config_path: <pol>}` | `AuditSQLParams.config_path` (internal/interfaces/mcp/connection.go) → isolated policy per-request |
| MCP (R1, reproduced) | same frames without `config_path` | **default shipped policy** — cause of R1 diff |

## R1 discrepancy classification — RESOLVED: category B
R1's MCP call omitted `config_path` → default shipped policy active:
- `ddl.alter.add_constraint.notice` (default-enabled) → extra notice finding
- `ddl.table.exists.alter.require` + `ddl.alter.add_index.exists.forbid` (default-enabled existence rules) → 2 `unknown_table_state` evidence gaps → coverage `unverified`
It was NOT a semantic/adapter defect: the FK blocker itself was identical, and with `config_path` injected the MCP result is byte-identical in semantic shape to CLI/SDK/HTTP (verdict/coverage/findings).
