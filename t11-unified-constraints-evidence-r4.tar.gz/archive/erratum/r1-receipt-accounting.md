# R1 receipt accounting erratum

## 1. Archive accounting (self-reference defect)
R1 in-archive `receipt/receipt.md` recorded the PRE-repack values `104,247 bytes / 88 manifest rows`. Final packed R1 archive is authoritative: **106,512 bytes / 89 manifest rows / NEW=89 / REUSED=0 / SHA-256 `0d3cfd10b27020c4270f797c6cec84115ad4224fb3dd6a2c9f26e89030d00892`**. Root cause: receipt was packed inside the archive before the final repack; the external delivered receipt carried the correct values. R2 records the final values.

## 2. File-reference corrections
| R1 receipt said | R1 actual | R2 evidence |
|---|---|---|
| `source-audit/ancestry-raw.txt` | did not exist — actual file is `source-audit/ancestry.txt` | R2: `source-audit/r2-commit-ledger.txt` (9 commits, full SHA/parent/tree/ancestry rc) |
| `application/focused-tests.log` | did not exist | R2: `application/r2-focused-tests-*.log` + `.rc.txt` + `r2-count-reconciliation.md` |

## 3. Focused-test count erratum
R1 stated "214 T11 test cases in internal/application/audit". Real counted results under `-run T11`: **140 total** (audit 133 = 81 top + 52 sub; rule 7). The 214 figure was an unverified approximation — corrected.

## 4. Missing-directory erratum
R1 README described `review/`, `decisions/`, `inventory/` sections; the directories shipped empty in the archive. R2 supplies `review/standards-review.md`, `review/spec-review.md`, `decisions/t11-decision-binding.md`, `inventory/t11-inventory-binding.md` — these are R2-NEW content, not recovered R1 content.

## 5. Matrix completeness
R1 `matrix/case-results.md` listed 39/40 cases (missing `T11.db.mysql57.ddl`). R2 `matrix/case-results-r2.md` lists all 40; `matrix/reconciliation.log` proves set equality with the artifact.

## 6. go_vet evidence
R1 `gates/go_vet.log` was 0 bytes with no rc record. R2 provides `gates/r2-go_vet.stdout.log`/`stderr.log`/`rc.txt` (=0) + register entry.
