# T11 historical native probes — standalone payload copies @ frozen HEAD 9d2c439c

These are the authoritative raw files cited by the R3 standards ledger. They are committed repo files under `docs/work-plans/t11-unified-constraints/`; this directory ships byte-identical copies as independent archive payloads (previously only reachable inside R2's historical diff exports).

| File | Repo path | Blob SHA @ frozen HEAD |
|---|---|---|
| CONTRACT.md | docs/work-plans/t11-unified-constraints/CONTRACT.md | 3c483eae3a8fc4b7b80111afca87c1d4fbe9d5ce |
| fk-probe.log | docs/work-plans/t11-unified-constraints/fk-probe.log | f98af807471e1a03f3eebfca1ad7ea2bb4d370cc |
| fk-probe-tidb.log | docs/work-plans/t11-unified-constraints/fk-probe-tidb.log | 4f39a2a31ef608172e6a2653f448fe84ffadfe59 |
| r1-probe-mysql57-80.log | docs/work-plans/t11-unified-constraints/r1/r1-probe-mysql57-80.log | df1ec4b5bd09bbd678f5fc36a40e97c18a1fcf41 |
| r1-probe-mysql84-tidb85.log | docs/work-plans/t11-unified-constraints/r1/r1-probe-mysql84-tidb85.log | 440e36ca8cabecd95051b8e80b125d4f364d6ebc |
| r1-probe2.log | docs/work-plans/t11-unified-constraints/r1/r1-probe2.log | 4be0200d12d0d333514607b24658e747bd4ebabb |
| r1-probe3.log | docs/work-plans/t11-unified-constraints/r1/r1-probe3.log | 536db5ced2c7807fb44d9071c3cc4a9f0ef48330 |
| r1-probe4.log | docs/work-plans/t11-unified-constraints/r1/r1-probe4.log | 850830afac3b6b588ae5a5a5152d48f6e87fb548 |
