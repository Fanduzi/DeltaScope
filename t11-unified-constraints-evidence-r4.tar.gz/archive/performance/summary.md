# T11 performance baseline (offline CLI, subprocess wall-clock)

- Method: subprocess wall-clock (`/usr/bin/time -p`), n=5, warm, Darwin arm64
- Binary: /tmp/t11-evidence/deltascope — SHA-256 `b302f4b39d923c361c5288c2c687e68fd9c2f9ce659a33815ac80112373f3697`
- HEAD: 9d2c439c46f6faed434e91c8b54ebc82abbf0787
- Fixture: `t11-perf.sql` — 794-statement mixed PK/UNIQUE/FK batch (1 parent CREATE + 340×(CREATE w/ FK+UNIQUE + ALTER ADD FK + periodic DROP FK)); generated deterministically inline below
- Raw samples (s): 0.07, 0.03, 0.03, 0.03, 0.03 → median 0.03, p95 0.07, min 0.03, max 0.07
- Note: offline CLI timing only; no database-execution performance claimed; memory not instrumented.
