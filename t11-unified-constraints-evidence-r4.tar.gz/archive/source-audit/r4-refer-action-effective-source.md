# R4 — foreignKeyReferActionPremise effective source binding @ frozen HEAD

- File: `internal/application/audit/batch_state_fk.go`
- Git blob SHA: `6bbf645f02150e77b59d6f7bdcee20493ee54338` (`git rev-parse HEAD:<path>`)
- Frozen HEAD: `9d2c439c46f6faed434e91c8b54ebc82abbf0787`
- Function: `foreignKeyReferActionPremise` — doc comment L510–516, signature L517, closing brace L547
- Full verbatim source: `r4-refer-action-source.txt` (extracted via `git show HEAD:<path> | sed -n '508,548p'` — includes doc comment through closing brace; NOT truncated at the set_default branch)

## Call path
- `applyAddForeignKey` L57: `refused, provable := s.foreignKeyReferActionPremise(entry.shape.Columns, constraint)` — the refused verdict converts the add into a tombstoned/non-landed member (drop answers missing).
- `createTableForeignKeyPremise` L294: same premise on the CREATE path.
- Caller chain: `batchState.Apply` → `applyAddForeignKey` / `createTableForeignKeyPremise` → `foreignKeyReferActionPremise`.

## Branch semantics (complete)
1. `set_null` on any declared action + a member column proven `NOT NULL` → `(refused=true, provable=true)` — unconditional, all dialects.
2. `set_default` on either action:
   - MySQL dialect only: `resolvedVersion` nil/major 0 → `(false, false)` — evidence gap, no claim.
   - `version.Major < 8` → `(true, true)` — refuse.
   - `version.Major >= 8` → falls through → `(false, true)` — allowed.
   - TiDB/other dialects: falls through → `(false, true)` — allowed.
3. Default: `(false, true)`.

## Mapping to R4 ER1 native results
| Version | Branch | Prediction | Native (r4-setdefault-results) | Match |
|---|---|---|---|---|
| MySQL 5.7.44 | Major<8 → refuse | reject | ERROR 1215 on both DEL/UPD SET DEFAULT | ✓ |
| MySQL 8.0.46 | Major≥8 → allow | accept+land | rc=0, I_S.RC lands | ✓ |
| MySQL 8.4.10 | Major≥8 → allow | accept+land | rc=0, lands | ✓ |
| TiDB v8.5.0 | non-MySQL fallthrough → allow | accept+land | rc=0, lands | ✓ |

## Pinning tests (exact paths/names)
- `internal/application/audit/batch_state_t11r1_de_test.go` `TestT11R1DReferActionBoundaries` L247:
  - "set null on not-null member refuses" — both dialects @ 8.0.46 / TiDB v8.5.0
  - "set default refuses on mysql 5.7" — provider version `5.7.44`, drop answers missing
  - "set default lands on mysql 8.0 and tidb" — provider `8.0.46` + `8.0.11-TiDB-v8.5.0`
- Golden: `T11.cli.t11-cli-fk-actions-modeled`, `T11.cli.t11-cli-fk-match-evidence`, `T11.meta.t11-mysql80-composite-actions` (actions recorded in finding metadata).
