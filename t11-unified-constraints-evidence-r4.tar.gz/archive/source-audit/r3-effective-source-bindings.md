# T11 effective source bindings @ frozen HEAD 9d2c439c

Frozen HEAD `9d2c439c46f6faed434e91c8b54ebc82abbf0787` / tree `bcec2a29…`. All blobs resolved via `git rev-parse HEAD:<path>` (read-only).

| # | Range | File (blob SHA) | Key functions (lines) | Golden/test IDs | Downstream impact |
|---|---|---|---|---|---|
| 1 | Constraint model / extractor | internal/infrastructure/parser/tidb/extractor.go `ceafd4cdd8131258ca1de7bbb7fbc7061b515fba` | `extractConstraint` L3304; `normalizeConstraintName` L3438; `checkConstraintFromColumnOption` L1275; `constraintProducesIndex` L2627 | extractor_t* tests; T11 fk-alter-* cases | T12 added CHECK projection — FK paths unchanged |
| 2 | FK referenced-key eligibility | internal/application/audit/batch_state_fk.go `6bbf645f…` | `referencedKeyPremise` L351; `referencedKeyMatch` L420; `indexMatchesColumnsExactly` L453; `referencedKeyMemberEligible` L475 | t11-mysql80-firstpath; r1-probe-mysql84 | unchanged post-T11 |
| 3 | 8.4 restrict_fk_on_non_standard_key branch | spec/metadata.go L193 (InstanceFacts field) `759a59ba…`; mysql/provider.go L202+L244 `2d0250c4…`; batch_state_fk.go `secondaryReferencedKeyEligible` L493 | observed-flag arm | dropfk-check-bearing; r3-probes | intact |
| 4 | FK referential actions | batch_state_fk.go `foreignKeyReferActionPremise` L517 | normalized shared vocabulary | fk-actions-modeled, fk-match-evidence | intact |
| 5 | CREATE/ALTER shared rules | internal/domain/rule/ddl/common.go `3e298012a7943f02006f797d896b55fd9531f542` (rule IDs L19/43-45/198/226/552) + policy defaults_ddl.go | rule registry | t11-cli-* family | intact |
| 6 | batch-state add/drop FK | batch_state_fk.go | `applyAddForeignKey` L22; `applyDropForeignKey` L994; `recordInboundEdge` L120 | meta firstpath, dropfk family | intact |
| 7 | supporting-index dependency | batch_state_fk.go | `publishForeignKeySupportingIndex` L939; `foreignKeyIndexDependency` L1128; `foreignKeyPKObjectDependency` L1174; `referencedDropDependency` L1210 | drop-needed-index, create-bare-fk-drop-derived | intact |
| 8 | rename-parent invalidation | batch_state.go `0c8ae529…` | `applyRenameTable` L2460; `applyRenamePair` L2781; `invalidateBoundKey` L2952; `invalidateDropIdentities` L3017 | rename-parent-invalidates | c27190ec cache-guard fix only gates TiDB cache premise — rename semantics unchanged |
| 9 | DROP CHECK / DROP CONSTRAINT boundary | batch_state_fk.go | `firstDropCheckAlter` L549; `applyDropCheck` L581; `publishCheckDropTarget` L656; `unvouchForeignKeyMember` L861 | dropfk-check-bearing | T12 owns CHECK half — boundary respected |
| 10 | shared execution entry (4 surfaces) | pkg/deltascope/audit.go `Audit` L297 `4cfb78d6…`; cli/audit.go L145 `b613e964…`; http/handler.go `1e6e581c9101d4661cc194035f94294b3cbfa46c` `handleAudit` L554; mcp/audit_tool.go `newAuditSQLTool` L38/`auditSQLOffline` L76 `e0cb1fba…` | all → `appaudit.AuditSQL` | transports/r2-parity-matrix | identical semantics proven |

## Provider reads
- `internal/infrastructure/metadata/mysql/provider.go` `2d0250c4…`: instance-facts query L202 includes `restrict_fk_on_non_standard_key`, `tidb_enable_check_constraint`, `tidb_enable_clustered_index`; binding L244. Query errors propagate as provider errors (r1 premise fixes).

## Spec surface
- `internal/domain/spec/metadata.go` `759a59ba…`: `FindForeignKeyConstraint` L624; `HasUnprovenForeignKeyName` L679; `ForeignKeyNameSpaceUnvouched` L703; InstanceFacts restrict flag L193.

## Binary identity at frozen HEAD (still available)
- `bin/deltascope` SHA-256 `3c6c82c6bbc7969dec2ccfd83c620ccf34caccc6b15f8d2950888129af3ef0b7` (52,909,746B, mtime 11月14 02:07) — CLI parity probes.
- `bin/deltascope-server` SHA-256 `855b0d0ed69374ca24d7617a4bb2f4a3a92a77d77cf4d52fdb808cdc7d0e470e` (68,580,114B, mtime 11月13 20:50) — HTTP parity probes. `--version` = `v0.511.2-0.20261113122951-ce7cda29275f+dirty` (module pseudo-version embeds commit ce7cda29; `+dirty` is the build-stamp convention — the working tree contained uncommitted evidence/harness files at build time; tracked product diff remains zero at frozen HEAD).
- `bin/deltascope-mcp` (38,505,650B, mtime 11月14 05:16) — MCP parity probes; transport entry `internal/interfaces/mcp/audit_tool.go` (blob `e0cb1fba…`) compiled into this binary.
