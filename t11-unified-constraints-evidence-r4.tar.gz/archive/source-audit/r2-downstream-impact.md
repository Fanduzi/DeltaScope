# Downstream-impact analysis — post-27edfea2 commits touching T11-scope files

Raw list: downstream-impact.txt (R1). Per-dimension check at frozen HEAD:

| Reviewer check area | Later commits touching it | T11 behavior now | Proof |
|---|---|---|---|
| Second-object state | T12+ shared batch_state work | unchanged for T11 scope | 12 cli_metadata cases pass |
| FK supporting-index dependency | unchanged surface | intact | drop-needed-index case |
| rename-parent invalidation | T05 cache-guard fix (c27190ec) | intact — fix only corrected TiDB cache-premise arm | rename-parent-invalidates |
| unknown constraint kind | T12 CHECK introduction | intact — unvouch still applied | dropfk-check-bearing (now provable → blocker) |
| mixed batch actions | T15/T16 additions | intact | composite-actions |
| CHECK-bearing boundary | T12 delivered the CHECK half | expectation TIGHTENED (unverified→complete, gap→blocker) | t12-t11json.diff |

Only T11-scope semantic change post-freeze-point: the T12 check-bearing graduation (tightened, not weakened). All 40 cases + focused tests pass at HEAD → coexistence proven, no T11 regression.
