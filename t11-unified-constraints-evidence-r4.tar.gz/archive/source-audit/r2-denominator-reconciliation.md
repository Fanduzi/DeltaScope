# Assertion denominator reconciliation — 505 → 506 → 518

## Step 1: 505 (T11-era)
T11 impl/R1/R2/R2-tail archives recorded 40 cases / 505 assertions — the T11-era runner + oracle count. Historical archives were produced in earlier sessions; byte-level replay of those runs is not possible (original artifacts not byte-preservable), so provenance is honest: count comes from the recorded archive summaries.

## Step 2: 506 — T12 graduation of `t11-mysql80-dropfk-check-bearing`
Commit `1f8e5a0b4e89d8cc4e6f8dd34708476808e2ba91` (feat(t12), issue #91) modified `testdata/ddl-golden/T11.json` — verbatim diff in `t12-t11json.diff`:
- expect.exit: 0→1; verdict: review→reject; findings: 0→1; coverage: unverified→complete
Reason: T12 made CHECK constraints auditable → the statement's `constraints` fact becomes provable → `ddl.alter.drop_foreign_key.exists.require` emits a proven-present blocker instead of an `unknown_table_state` gap. This is oracle TIGHTENING (stronger expectation), not weakening. Independent oracle basis: T12 contract + native anchor observation.

## Step 3: 518 — anchor-identity hardening (+12 = 4 anchors × 3)
Commits `c96cf97c` (record anchor image ID, platform, schema evidence) + `83581fd8` (prove immutable anchor image identity) added three assertions per anchor (image digest locked / running image identity / platform), applied uniformly across ALL golden tasks. See `anchor-identity-commits.txt`. Not T11-specific.

## Current: 40 cases / 518 assertions — verified at frozen HEAD run (golden/run.log, artifact.json).
No case deleted; no negative counterexample removed; no finding/coverage expectation weakened (the single oracle edit was a strict tightening).
