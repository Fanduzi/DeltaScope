# T11/#90 — Existing-implementation audit (at frozen HEAD 9d2c439c)

## 1. Commit chain (all `merge-base --is-ancestor <c> HEAD` → rc=0)

| Commit | Parent | Subject | Remote position |
|---|---|---|---|
| 11d6439171cd… | 8b6f3098 | feat(t11): unified PK/UNIQUE/FK CREATE/ALTER constraint checks | ON-REMOTE |
| 661e57563190… | 11d64391 | docs(t11): T11 verification archive bound to 11d64391 | ON-REMOTE |
| 206499195e21… | 661e5756 | fix(t11): R1 landing premises, collection contract, dependency gates | ON-REMOTE |
| 216e187cb226… | 20649919 | test(t11): R1-A downstream oracles — name-only members never fabricate | ON-REMOTE |
| ec9629d8a7b3… | 216e187c | docs(t11): T11-R1 verification archive bound to 216e187c | ON-REMOTE |
| 988560c2abff… | d0c7cf33 | fix(audit): T11-R2 — same-statement PK facts, strict referenced-key anchor, self/existing binding dependencies, DROP CONSTRAINT kind coverage | local-only |
| efc004c7c93c… | 988560c2 | docs(t11): T11-R2 verification archive bound to 988560c2 | local-only |
| 27edfea2f41e… | efc004c7 | fix(audit): T11-R2-tail — unvouch unknown-kind drop targets, bind rename findings to new name | local-only |
| 186710db6908… | 27edfea2 | docs(t11): T11-R2-tail verification archive bound to 27edfea2 | local-only |

Product commits: 11d64391 (impl), 20649919 (R1), 216e187c (R1-A oracles), 988560c2 (R2), 27edfea2 (R2-tail). Docs/test-only: the rest.

## 2. Source/spec/provider/state/rule mapping (current HEAD)

- Parser/Spec: FK inline + table-level, named/bare constraints, composite members, ON DELETE/UPDATE normalized (MATCH left as unmodeled evidence); PK/UNIQUE inline + table-level + `CONSTRAINT` naming + `CREATE UNIQUE INDEX` equivalence path.
- Rules: `ddl.table.foreign_key.forbid`, `ddl.constraint.foreign_key.name.{contains,prefix,suffix}.require`, `ddl.table.primary_key.{columns.max_count,unsigned.require,auto_increment.require,…}`, `ddl.constraint.primary_key.name.*`, `ddl.constraint.unique_key.name.*`, `ddl.alter.drop_foreign_key.{exists.require,notice}`, `ddl.alter.add_constraint.notice`, `ddl.alter.drop_index.exists.require`, `ddl.alter.drop_primary_key.forbid`.
- Provider: FK members + referential constraints + supporting-index relations loaded into snapshots; query errors propagate as real provider errors (not gaps).
- Prospective state: `batch_state*.go` — same-statement PK facts (R2), referenced-key anchor binding, self/existing binding dependencies, unknown-kind drop targets unvouched (R2-tail), rename findings bound to new name, DROP INDEX→FK support relations, rename-parent invalidation, ordered drop-present/missing distinction.
- Audit/SDK/CLI/HTTP/MCP: shared domain rules — identical `rule_id`/level across surfaces (verified this round on all four transports).

## 3. Historical denominators reconciliation

| Era | Cases | Assertions | Basis |
|---|---|---|---|
| T11 impl/R1/R2/R2-tail archives | 40/40 | 505 | R2-tail-era runner |
| T14-era gate INDEX | 40/40 | 506 | +1 oracle: `t11-mysql80-dropfk-check-bearing` graduated by T12 (CHECK constraints auditable → `constraints` fact provable → `ddl.alter.drop_foreign_key.exists.require` blocker replaces `unknown_table_state` gap). Independent oracle basis: T12 contract; expect tightened, not weakened |
| **Current HEAD run** | **40/40** | **518** | +12 = 4 anchors × 3 anchor-identity assertions (image digest locked baseline / running image identity / platform), added by T02-era immutable-anchor hardening — uniform across tasks, not a T11 semantic change |

No case deleted; no negative counterexample removed; required_case_ids = 40 unchanged.

## 4. Downstream co-existence

Later commits (T12–T26) touch shared `batch_state*.go` and add sibling rules (e.g., T12 CHECK, T26 SRS). T11-scope behavior at current HEAD is locked by the 40-case golden + 214 focused T11 tests + rule tests — all PASS. No T11 gap found; **zero product changes this round**.

## 5. Reusable scope vs unproven scope

- Reusable (proven this round): all §四 matrix rows A–D via Golden + focused tests + transports.
- Boundary truths retained: TiDB `DROP CONSTRAINT fk` spelled-form is a CHECK-clause boundary (T12), MATCH unmodeled evidence, MySQL 5.7 `RESTRICT` vs 8.x `NO ACTION` normalized.
