# T11 effective source review @ frozen HEAD 9d2c439c

Review chain (file → key ranges, all at frozen HEAD):

## 1. parser / normalizer
- `internal/infrastructure/parser/tidb/` — extractor projects `CONSTRAINT sym FOREIGN KEY`, bare `FOREIGN KEY`, `PRIMARY KEY`, `UNIQUE [KEY]`, `CREATE UNIQUE INDEX`, `DROP FOREIGN KEY|INDEX|PRIMARY KEY|CONSTRAINT` into spec members; ON DELETE/UPDATE actions normalized; MATCH kept unmodeled.
- `internal/domain/spec/` — `spec.Constraint` members carry kind/name/members/referenced table+columns/actions; `spec.Alter` constraint actions.

## 2. constraint model + metadata provider
- `internal/infrastructure/metadata/` — loads TABLE_CONSTRAINTS + REFERENTIAL_CONSTRAINTS + supporting-index relations (MySQL), TiDB FK facts under `tidb_enable_foreign_key`; query errors propagate as provider errors (not gaps).

## 3. prospective batch state
- `internal/application/audit/batch_state*.go` (~58k LOC shared with T12–T26): same-statement PK/FK facts, referenced-key anchor binding, self/existing binding dependencies, DROP INDEX→FK support relations, rename-parent invalidation, ordered drop-present/missing distinction, unknown-kind unvouch (R2-tail), rename findings bound to new name.

## 4. shared rules
- `internal/domain/rule/` — T11-owned: `ddl.table.foreign_key.forbid`, `ddl.constraint.foreign_key.name.{contains,prefix,suffix}.require`, `ddl.table.primary_key.columns.max_count`, `ddl.constraint.primary_key.name.*`, `ddl.constraint.unique_key.name.*`, `ddl.alter.drop_foreign_key.{exists.require,notice}`; shared existence rules: `ddl.table.exists.alter.require`, `ddl.alter.drop_index.exists.require`, `ddl.alter.drop_primary_key.forbid`.

## 5. surfaces
- `pkg/deltascope` facade → `internal/application/audit` (same domain evaluation)
- CLI `--config`, SDK `Request.ConfigPath`, HTTP server `-config`, MCP `AuditSQLParams.config_path` — all resolve into the same policy load + rule evaluation (proven identical output, transports/r2-parity-matrix.md).

## Focused test families at frozen HEAD
`batch_state_t11_fk_test.go`, `batch_state_t11_test.go`, rule-package T11 tests (fk forbid/name, pk max/name, uk name, dropfk exists/notice), coverage + contract tests.
