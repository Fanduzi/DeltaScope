# Focused T11 test count reconciliation — R2 NEW RUN @ 9d2c439c

## Commands (rerun this round; raw logs retained)
1. `go test ./internal/application/audit/... -v -run T11` → rc=0 → `r2-focused-tests-audit.stdout.log` / `.stderr.log` / `.rc.txt`
2. `go test ./internal/domain/rule/... -v -run T11` → rc=0 → `r2-focused-tests-rule.stdout.log` / `.stderr.log` / `.rc.txt`
3. Broader cross-check: `-run 'T11|ForeignKey|foreign_key|PrimaryKey|primary_key|UniqueKey|unique_key|DropForeign|DropIndex|drop_foreign'` on audit pkg → 275 `=== RUN` lines (includes non-T11-named constraint tests; reference only)

## Counting method (no double counting)
- `=== RUN` lines count every executed test incl. subtests (Go prints `=== RUN` for each).
- Top-level vs subtest split via `--- PASS:` indentation.

## Verified results (rc=0, zero FAIL)

| suite | top-level | subtests | total results |
|---|---|---|---|
| audit pkg `-run T11` | 81 | 52 | **133** |
| rule pkg `-run T11` | 7 | 0 | **7** |
| **combined** | **88** | **52** | **140** |

## R1 "214" claim — ERRATUM
R1 receipt stated "214 T11 test cases". Under the defined counting method the real figure is **140** (133 audit + 7 rule). The 214 figure cannot be reproduced and was an unverified count — corrected here, not restated. See `erratum/r1-receipt-accounting.md`.

## FAIL count: 0 across all runs.
