# T11 semantic acceptance matrix (PK / UNIQUE / FK / TiDB edges)

Evidence: golden artifact 40/40 + 518 assertions; case ids map rows below.

## A. PRIMARY KEY
- CREATE inline PK / table-level PK / ALTER ADD PK / composite+order / DROP PK / implicit NOT NULL / existing+duplicate+missing target / real index vs logical PK identity / downstream state — covered by T11.db.* ddl_steps + cli t11-cli-pk-max-* / t11-cli-pk-name-* + meta ordered cases + PK rules tests.
## B. UNIQUE
- inline/table-level/CONSTRAINT-named/CREATE UNIQUE INDEX/ALTER ADD/composite+order/index-identity binding/DROP INDEX+CONSTRAINT forms/rename+state/unknown-kind — covered by cli uk-name + dropfk/drop-index cases + db steps.
## C. FOREIGN KEY
- inline+table-level+named+ALTER/composite+ref order/REFERENCES schema.table(cols)/cross-schema (t11-cli-fk-schema-ref)/ON DELETE+UPDATE/DROP FK + DROP CONSTRAINT dialect forms/referenced-key eligibility/member structure/existing+missing/supporting index+implicit deps/downstream effects — covered by cli fk-* family + meta mysql80-* + tidb85-clustered-parent.
## D. TiDB edges
- clustered/nonclustered PK (t11-tidb85-clustered-parent), PK-handle identity, implicit row id, FK actual support (tidb_enable_foreign_key ON, native enforcement), MySQL/TiDB dialect differences (t11-cli-fk-alter-tidb), DROP CONSTRAINT fk = CHECK boundary — all covered.
