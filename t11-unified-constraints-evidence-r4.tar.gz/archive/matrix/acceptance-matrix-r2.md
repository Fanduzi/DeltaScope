# T11 acceptance matrix — dimension × case binding (40 cases = artifact set, reconciled)

Dimensions cover #90 contract: PK / UNIQUE / FK on CREATE+ALTER, naming, members, referenced-key identity, supporting indexes, dependent edges, DROP trichotomy, ordered/batch state, disabled-rule path, TiDB edges, negative/syntax, four-anchor native execution.

| Dimension | Cases | Status |
|---|---|---|
| A1 PK CREATE inline+table-level+composite | T11.db.*.ddl (4 anchors), t11-cli-pk-max-create-pair | 5 pass |
| A2 PK ALTER ADD (same max-count/naming as CREATE) | t11-cli-pk-max-alter, t11-cli-pk-name-alter-control | 2 pass |
| A3 PK DROP + ordered state + dependent invalidation | t11-mysql80-* meta ordered cases | pass |
| A4 PK identity (implicit NOT NULL, index vs logical PK, TiDB clustered) | t11-tidb85-clustered-parent, db_ddl | pass |
| B1 UNIQUE inline/table/named/CREATE UNIQUE INDEX/DROP | uk-name-alter-control, db_ddl | pass |
| C1 FK CREATE parity (inline/table/named/composite/cross-schema) | fk-create-pair, fk-name-create-pair, fk-schema-ref, db_ddl | pass |
| C2 FK ALTER ADD parity (firstpath/two/bare/composite) | fk-alter-firstpath, fk-alter-two, fk-alter-bare, fk-alter-composite-actions, fk-alter-tidb | pass |
| C3 FK naming rules contains/prefix/suffix | fk-name-alter-ok, fk-name-alter-bad | pass |
| C4 FK forbid rule incl. disabled path | t11-cli-fk-forbid-off, fk-alter-firstpath | pass |
| C5 referenced-key identity + member structure | meta firstpath, db_ddl | pass |
| C6 supporting index + implicit dependencies | t11-mysql80-drop-needed-index, create-bare-fk-drop-derived | pass |
| C7 DROP FOREIGN KEY trichotomy (present/absent/unknown) | ordered-drop-present, dropfk-missing, dropfk-provider-present, dropfk-constraints-unknown, dropfk-exists-offline, dropfk-check-bearing | 6 pass |
| C8 ON DELETE/UPDATE modeled; MATCH unmodeled | fk-actions-modeled, fk-match-evidence, composite-actions | pass |
| C9 dependent edges + batch ordered state | rename-parent-invalidates, drop-needed-index, meta composite | pass |
| D1 TiDB edges (clustered PK, dialect differences, spelled-form boundary) | tidb85-clustered-parent, fk-alter-tidb, dropfk-check-bearing | pass |
| E1 add-column control / non-constraint regression | t11-cli-addcol-control, fk-notice-control | pass |
| F1 syntax negatives on all anchors | *.syntax_negative ×4 | pass |

Coverage classes: positive + negative + disabled + unknown-metadata + cross-object dependency + batch state all represented; no dimension is claimed beyond executed cases (see spec-review bounded list for non-claims).
