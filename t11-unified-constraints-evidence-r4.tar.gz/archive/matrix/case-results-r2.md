case_id | kind | anchor/version | status | assertions | golden evidence
|---|---|---|---|---|---
T11.db.mysql57.ddl | db_ddl | MySQL 5.7.44 | pass | 33 | golden/cases/T11.db.mysql57.ddl.json
T11.db.mysql57.syntax_negative | db_syntax_negative | MySQL 5.7.44 | pass | 3 | golden/cases/T11.db.mysql57.syntax_negative.json
T11.db.mysql80.ddl | db_ddl | MySQL 8.0.46 | pass | 33 | golden/cases/T11.db.mysql80.ddl.json
T11.db.mysql80.syntax_negative | db_syntax_negative | MySQL 8.0.46 | pass | 3 | golden/cases/T11.db.mysql80.syntax_negative.json
T11.db.mysql84.ddl | db_ddl | MySQL 8.4.10 | pass | 33 | golden/cases/T11.db.mysql84.ddl.json
T11.db.mysql84.syntax_negative | db_syntax_negative | MySQL 8.4.10 | pass | 3 | golden/cases/T11.db.mysql84.syntax_negative.json
T11.db.tidb85.ddl | db_ddl | TiDB v8.5.0 | pass | 34 | golden/cases/T11.db.tidb85.ddl.json
T11.db.tidb85.syntax_negative | db_syntax_negative | TiDB v8.5.0 | pass | 3 | golden/cases/T11.db.tidb85.syntax_negative.json
T11.cli.t11-cli-fk-alter-firstpath | cli_audit | offline/none | pass | 15 | golden/cases/T11.cli.t11-cli-fk-alter-firstpath.json
T11.cli.t11-cli-fk-create-pair | cli_audit | offline/none | pass | 13 | golden/cases/T11.cli.t11-cli-fk-create-pair.json
T11.cli.t11-cli-fk-alter-bare | cli_audit | offline/none | pass | 9 | golden/cases/T11.cli.t11-cli-fk-alter-bare.json
T11.cli.t11-cli-fk-alter-composite-actions | cli_audit | offline/none | pass | 9 | golden/cases/T11.cli.t11-cli-fk-alter-composite-actions.json
T11.cli.t11-cli-fk-alter-two | cli_audit | offline/none | pass | 8 | golden/cases/T11.cli.t11-cli-fk-alter-two.json
T11.cli.t11-cli-addcol-control | cli_audit | offline/none | pass | 9 | golden/cases/T11.cli.t11-cli-addcol-control.json
T11.cli.t11-cli-fk-forbid-off | cli_audit | offline/none | pass | 7 | golden/cases/T11.cli.t11-cli-fk-forbid-off.json
T11.cli.t11-cli-fk-alter-tidb | cli_audit | offline/none | pass | 9 | golden/cases/T11.cli.t11-cli-fk-alter-tidb.json
T11.cli.t11-cli-fk-name-alter-bad | cli_audit | offline/none | pass | 9 | golden/cases/T11.cli.t11-cli-fk-name-alter-bad.json
T11.cli.t11-cli-fk-name-alter-ok | cli_audit | offline/none | pass | 8 | golden/cases/T11.cli.t11-cli-fk-name-alter-ok.json
T11.cli.t11-cli-fk-name-create-pair | cli_audit | offline/none | pass | 8 | golden/cases/T11.cli.t11-cli-fk-name-create-pair.json
T11.cli.t11-cli-pk-max-alter | cli_audit | offline/none | pass | 9 | golden/cases/T11.cli.t11-cli-pk-max-alter.json
T11.cli.t11-cli-pk-max-create-pair | cli_audit | offline/none | pass | 8 | golden/cases/T11.cli.t11-cli-pk-max-create-pair.json
T11.cli.t11-cli-pk-name-alter-control | cli_audit | offline/none | pass | 8 | golden/cases/T11.cli.t11-cli-pk-name-alter-control.json
T11.cli.t11-cli-uk-name-alter-control | cli_audit | offline/none | pass | 8 | golden/cases/T11.cli.t11-cli-uk-name-alter-control.json
T11.cli.t11-cli-fk-notice-control | cli_audit | offline/none | pass | 8 | golden/cases/T11.cli.t11-cli-fk-notice-control.json
T11.cli.t11-cli-fk-actions-modeled | cli_audit | offline/none | pass | 7 | golden/cases/T11.cli.t11-cli-fk-actions-modeled.json
T11.cli.t11-cli-fk-match-evidence | cli_audit | offline/none | pass | 10 | golden/cases/T11.cli.t11-cli-fk-match-evidence.json
T11.cli.t11-cli-dropfk-exists-offline | cli_audit | offline/none | pass | 13 | golden/cases/T11.cli.t11-cli-dropfk-exists-offline.json
T11.cli.t11-cli-fk-schema-ref | cli_audit | offline/none | pass | 8 | golden/cases/T11.cli.t11-cli-fk-schema-ref.json
T11.meta.t11-mysql80-firstpath | cli_metadata | offline/none | pass | 18 | golden/cases/T11.meta.t11-mysql80-firstpath.json
T11.meta.t11-mysql80-ordered-drop-present | cli_metadata | offline/none | pass | 15 | golden/cases/T11.meta.t11-mysql80-ordered-drop-present.json
T11.meta.t11-mysql80-dropfk-missing | cli_metadata | offline/none | pass | 13 | golden/cases/T11.meta.t11-mysql80-dropfk-missing.json
T11.meta.t11-mysql80-dropfk-provider-present | cli_metadata | offline/none | pass | 15 | golden/cases/T11.meta.t11-mysql80-dropfk-provider-present.json
T11.meta.t11-mysql80-dropfk-constraints-unknown | cli_metadata | offline/none | pass | 17 | golden/cases/T11.meta.t11-mysql80-dropfk-constraints-unknown.json
T11.meta.t11-mysql80-dropfk-check-bearing | cli_metadata | offline/none | pass | 16 | golden/cases/T11.meta.t11-mysql80-dropfk-check-bearing.json
T11.meta.t11-mysql80-create-bare-fk-drop-derived | cli_metadata | offline/none | pass | 16 | golden/cases/T11.meta.t11-mysql80-create-bare-fk-drop-derived.json
T11.meta.t11-mysql80-drop-needed-index | cli_metadata | offline/none | pass | 14 | golden/cases/T11.meta.t11-mysql80-drop-needed-index.json
T11.meta.t11-mysql80-rename-parent-invalidates | cli_metadata | offline/none | pass | 18 | golden/cases/T11.meta.t11-mysql80-rename-parent-invalidates.json
T11.meta.t11-mysql80-composite-actions | cli_metadata | offline/none | pass | 14 | golden/cases/T11.meta.t11-mysql80-composite-actions.json
T11.meta.t11-tidb85-firstpath | cli_metadata | offline/none | pass | 15 | golden/cases/T11.meta.t11-tidb85-firstpath.json
T11.meta.t11-tidb85-clustered-parent | cli_metadata | offline/none | pass | 19 | golden/cases/T11.meta.t11-tidb85-clustered-parent.json
