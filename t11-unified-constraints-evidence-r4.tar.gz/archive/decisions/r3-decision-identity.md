# T11 decision record identity @ frozen HEAD 9d2c439c

- Path: `docs/decisions/2026-10-25-ddl-unified-constraint-checks.md`
- Blob SHA: `169ed214fe24ab958247828ed16ffb11f5a92870`
- Last-touching commit: `186710db69088d59eae82726bbc6ad4789f8a353` — docs(t11): T11-R2-tail verification archive bound
- Lines: 318
- Content covers: unified PK/UNIQUE/FK CREATE/ALTER semantics, ordered FK state, supporting-index model, referenced-key eligibility (incl. restrict_fk_on_non_standard_key arm), DROP CONSTRAINT boundaries, TiDB edges.
