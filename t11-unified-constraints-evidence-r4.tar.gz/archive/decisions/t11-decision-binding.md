# T11 decision binding

- Record: `docs/decisions/2026-10-25-ddl-unified-constraint-checks.md` (committed, milestone branch)
- Git identity at frozen HEAD `9d2c439c`: `git log -1 --format=%H docs/decisions/2026-10-25-ddl-unified-constraint-checks.md`
- Content: unified PK/UNIQUE/FK CREATE/ALTER checks + foreign-key ordered state rationale; covers rule ownership, prospective-state modeling, TiDB edges, deferred scope (MATCH unmodeled; DROP CONSTRAINT spelled form → T12)
- No new record required this round: R2 is evidence-only; zero product change.
