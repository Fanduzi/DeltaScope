# gates/r2-command-register.md — R2 NEW RUN @ frozen HEAD
tested HEAD: 9d2c439c46f6faed434e91c8b54ebc82abbf0787
cwd: /Users/fan/GolangProjects/DeltaScope

## make test
start: 2026-11-14T02:14:10Z
end: 2026-11-14T02:14:13Z (elapsed 3s)
rc: 0 — PASS
## make pg-unit-test-gates
start: 2026-11-14T02:14:13Z
end: 2026-11-14T02:14:23Z (elapsed 10s)
rc: 0 — PASS
## make sql-corpus-gates
start: 2026-11-14T02:14:23Z
end: 2026-11-14T02:14:24Z (elapsed 1s)
rc: 0 — PASS
## make ddl-inventory-gate
start: 2026-11-14T02:14:24Z
end: 2026-11-14T02:14:25Z (elapsed 1s)
rc: 0 — PASS
## make ddl-golden-validator-test
start: 2026-11-14T02:14:25Z
end: 2026-11-14T02:16:11Z (elapsed 106s)
rc: 0 — PASS
## go vet ./...
start: 2026-11-14T02:16:14Z
end: 2026-11-14T02:16:15Z
rc: 0 — PASS (empty stdout/stderr is expected for vet; rc is authoritative)
