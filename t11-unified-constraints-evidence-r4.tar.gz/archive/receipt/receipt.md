# T11/#90 — R4 final-semantic-evidence receipt (in-archive)

Work order: T11-R4-FINAL-SEMANTIC-EVIDENCE-01 — close four named evidence gaps. No product/oracle/test changes.

- ER1: SET DEFAULT verdict rewritten per doc-vs-native divergence; R4 per-statement probes on 4 anchors — 5.7 rejects (ERROR 1215), 8.0/8.4/TiDB accept+land; product `foreignKeyReferActionPremise` predictions match all four.
- ER2: matrix regenerated — fk-schema-ref & composite-actions now show 1 fk.forbid:blocker finding; 40/518 preserved.
- ER3: complete foreignKeyReferActionPremise source + call path + test bindings.
- ER4: HTTP binary identity bound — original binary from ancestor ce7cda29 (no audit-path delta); definitive rebuilt-at-HEAD binary re-probed: 200/reject/complete/1 blocker/0 gaps.
- ER5: historical probes as standalone payloads w/ blob SHAs; fresh no-change proof; fresh cred scan.
- Archive SHA recorded in delivered message (self-reference excluded).
