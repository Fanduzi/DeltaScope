# T11 Standards review — PK / UNIQUE / FK official-semantics alignment

Sources: MySQL 8.4/8.0/5.7 Reference Manual §13.1.20 (CREATE TABLE), §13.1.9 (ALTER TABLE); TiDB v8.5 docs (FOREIGN KEY constraints / clustered indexes). Native observations recorded by golden `db_*` cases on real anchors (mysql 5.7.44 / 8.0.46 / 8.4.10 / tidb v8.5.0) — see `native/native-anchors.json`.

## PRIMARY KEY

| Aspect | MySQL 5.7 | MySQL 8.0 | MySQL 8.4 | TiDB 8.5 | DeltaScope T11 | Evidence |
|---|---|---|---|---|---|---|
| inline `col ... PRIMARY KEY` | yes | yes | yes | yes | audited | T11.cli-fk-create-pair, db_ddl |
| table-level `PRIMARY KEY (...)` | yes | yes | yes | yes | audited | db_ddl steps, pk-max cases |
| `CONSTRAINT name PRIMARY KEY` (named PK ignored by server, name stays `PRIMARY`) | yes | yes | yes | yes | audited — naming rules bind to declaration semantics | pk-name-alter-control |
| ALTER ADD PRIMARY KEY | yes | yes | yes | yes | audited — feeds same max-count + naming semantics as CREATE | pk-max-alter |
| composite + member order | yes | yes | yes | yes | audited | db_ddl, ordered state |
| DROP PRIMARY KEY | yes (allowed w/ caution) | yes | yes | yes | audited — forbid/exists rules + ordered state | meta ordered-drop cases |
| implicit NOT NULL promotion | yes | yes | yes | yes | audited (implicit not_null modeled) | db_ddl assertions |
| clustered index semantics | InnoDB always clustered | same | same | opt-in `CLUSTERED`/`NONCLUSTERED` (8.5 supports both) | audited incl. TiDB clustered-parent | t11-tidb85-clustered-parent |
| duplicate/missing PK on ALTER | error 1068 / error | same | same | error | audited — exists rules + ordered no-op/distinct paths | meta cases |

## UNIQUE KEY

| Aspect | MySQL 5.7/8.0/8.4 | TiDB 8.5 | DeltaScope T11 | Evidence |
|---|---|---|---|---|
| inline UNIQUE | all | yes | audited | db_ddl |
| table-level UNIQUE + CONSTRAINT-named | all | yes | audited | db_ddl, uk-name cases |
| `CREATE UNIQUE INDEX` equivalence | all | yes | audited (index-identity binding) | drop-needed-index case |
| ALTER ADD UNIQUE | all | yes | audited | uk-name-alter-control |
| composite UNIQUE + member order | all | yes | audited | db_ddl |
| DROP INDEX / DROP KEY `name` | all | yes | audited — ordered drop-present/missing + dependency | meta cases |

## FOREIGN KEY

| Aspect | MySQL 5.7 | MySQL 8.0 | MySQL 8.4 | TiDB 8.5 | DeltaScope T11 | Evidence |
|---|---|---|---|---|---|---|
| table-level `FOREIGN KEY (c) REFERENCES p(id)` | yes | yes | yes | yes (native FK since 6.6+, enforced when tidb_enable_foreign_key=ON) | audited | db_ddl, fk-create-pair |
| `CONSTRAINT sym FOREIGN KEY` naming | yes | yes | yes | yes | audited — name rules contains/prefix/suffix | fk-name-* cases |
| inline column FK `c INT, FOREIGN KEY...` table-level only; `REFERENCES tbl` inline parse-accepted but ignored | accepted syntax, no constraint created | same | same | same | audited — modeled as declaration-level fact | fk-* create cases |
| composite members + order | yes | yes | yes | yes | audited | fk-alter-composite-actions |
| referenced schema.table(cols) incl. cross-schema | yes | yes | yes | yes | audited | fk-schema-ref |
| ON DELETE/UPDATE actions | RESTRICT/NO ACTION/CASCADE/SET NULL/SET DEFAULT | same (+ SET DEFAULT rejected in 8.0.x for real FKs — parser accepted) | RESTRICT removed as keyword alias? (8.4: RESTRICT not allowed in grammar — observed) | CASCADE/SET NULL supported; RESTRICT/NO ACTION accepted | audited — normalized shared vocabulary | fk-actions-modeled, native rc observations |
| `MATCH FULL/PARTIAL/SIMPLE` | parsed, ignored (no match semantics) | same | same | parsed, ignored | audited as **unmodeled evidence** — carried, not silently dropped | fk-match-evidence |
| ALTER ADD CONSTRAINT ... FK | yes | yes | yes | yes | audited — feeds forbid + naming rules | fk-alter-firstpath/two/bare |
| ALTER ADD FOREIGN KEY without CONSTRAINT name → server auto-names `child_ibfk_1` | yes | yes | yes | yes (auto-name) | audited — bare-FK path modeled | fk-alter-bare |
| DROP FOREIGN KEY `sym` | yes (requires constraint name) | yes | yes | yes | audited — exists.require with proven-present/absent/unknown trichotomy | dropfk cases |
| DROP CONSTRAINT `sym` spelled form | not valid FK syntax (CHECK only) | CHECK only | CHECK only | TiDB accepts `DROP CONSTRAINT fk` spelled form for FK (observed native) | **bounded**: TiDB spelled-form kept at CHECK-clause boundary (T12) | dropfk-check-bearing |
| supporting index auto-creation | InnoDB creates index if none leftmost-covering | same | same | TiDB creates supporting index | audited — supporting-index fact + implicit deps | drop-needed-index |
| drop FK keeps supporting index | yes | yes | yes | yes | audited — drop removes constraint, index survives | native db_ddl |
| referenced-key eligibility (must be PK/UNIQUE or indexed prefix) | strict | strict (InnoDB) | strict | strict | audited — referenced-key anchor + member structure | meta firstpath |
| self-referencing FK | yes | yes | yes | yes | audited | meta cases (self/existing binding deps) |
| MySQL 5.7 vs 8.x action naming | uses `RESTRICT` | `NO ACTION` common | `NO ACTION` | normalized | audited — normalized shared vocabulary | fk-actions-modeled |

## Bounded / explicitly unaudited edges (not claimed)
- `MATCH` clause: carried as evidence, no semantic action binding — `t11-cli-fk-match-evidence`.
- TiDB `DROP CONSTRAINT fk` spelled form: CHECK-clause boundary — T12 scope.
- `ddl.table.exists.alter.require`/`ddl.alter.add_index.exists.forbid` offline → `unknown_table_state` gaps (honest unproven, not fabricated).
