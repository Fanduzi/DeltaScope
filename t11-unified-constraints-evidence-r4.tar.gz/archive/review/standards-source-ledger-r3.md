# Standards source ledger R3 — citation → claim binding

| Claim | Source type | Source |
|---|---|---|
| 8.4 grammar includes RESTRICT/NO ACTION | official | dev.mysql.com/doc/refman/8.4/en/create-table-foreign-keys.html |
| RESTRICT lands verbatim on 8.4.10 | native-observed | r3-probes/mysql84-restrict-setdefault.log (NEW RUN) |
| Default action normalizes to NO ACTION on 8.x | native-observed | fk-probe.log (I_S.RC rows) |
| 5.7 shows RESTRICT in I_S.RC | native-observed | fk-probe.log mysql57 section |
| 5.7/8.0 non-unique referenced index allowed | official + native-observed | MySQL 8.0 refman FK section; r1-probe logs r1d (nonunique accepted 5.7/8.0) |
| 8.4 default restrict_fk_on_non_standard_key=ON → 6125 | official + native-observed | refman/8.4 system vars; r1-probe-mysql84 log + R3 NEW RUN |
| flag OFF → nonunique leftmost accepted on 8.4 | native-observed | r3-probes/mysql84-nonstandard-off.log (fk_nu_off landed) |
| TiDB 8.5 nonunique referenced index accepted | native-observed | r1-probe2.log tidb r1d nonunique rc=0 |
| SET DEFAULT declared-action lands on 8.0/8.4/TiDB | native-observed | r1-probe2.log sd rows + R3 NEW RUN |
| SET DEFAULT doc "not recognized" conflict scope | official | refman FK actions note — runtime-vs-declaration scope |
| TiDB DROP CONSTRAINT fk = warned no-op | native-observed | r3-probes/tidb85-drop-constraint.log (Warning 1105, FK survives) + r1-probe2 |
| MySQL 8.x DROP CONSTRAINT fk removes FK; 5.7 rejects | native-observed | r1-probe2.log poststate 0 vs 1 |
| Supporting index survives DROP FK on all anchors | native-observed | fk-probe.log + tidb85-drop-constraint.log |
| Drop needed index refused (1553/8200) | native-observed | r1-probe3.log e3/e4 sections |
| TiDB clustered PK can't drop PK (8200) | native-observed | r1-probe3.log tidb e3 |
