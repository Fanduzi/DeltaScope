# T11 Standards review R3 — corrected, per-version, evidence-tagged

Legend: **[official]** vendor documentation · **[native-observed]** real anchor execution (log cited) · **[source-proven]** code at frozen HEAD · **[bounded]** explicit non-claim · **[unresolved]** open conflict.

## ER1.1 — MySQL 8.4 RESTRICT — CORRECTED

R2 wrongly implied 8.4 grammar excludes RESTRICT. Correction:
- **[official]** MySQL 8.4 FK grammar includes `ON DELETE/UPDATE RESTRICT` and `NO ACTION` (dev.mysql.com/doc/refman/8.4/en/create-table-foreign-keys.html).
- **[native-observed R3 NEW RUN]** `mysql:8.4.10` disposable anchor (t11-r3-mysql84, ephemeral root pw): `CONSTRAINT fk_r FOREIGN KEY (c) REFERENCES p1(id) ON DELETE RESTRICT ON UPDATE RESTRICT` — **accepted, lands verbatim**: I_S.REFERENTIAL_CONSTRAINTS shows `RESTRICT/RESTRICT`; SHOW CREATE TABLE emits literal `ON DELETE RESTRICT ON UPDATE RESTRICT` (`r3-probes/mysql84-restrict-setdefault.log`).
- **[native-observed R1]** `fk-probe.log`: 5.7.44 shows RESTRICT in I_S.RC; 8.0.46/8.4.10 default actions show `NO ACTION` — normalization happens only for *undeclared* actions, not for spelled RESTRICT.
- DeltaScope: actions normalized into shared vocabulary; spelled RESTRICT vs NO ACTION distinction preserved in members — **[source-proven]** (`fk-actions-modeled` case).

## ER1.2 — Referenced-key eligibility — per version

| Parent target | MySQL 5.7.44 | MySQL 8.0.46 | MySQL 8.4.10 | TiDB 8.5 |
|---|---|---|---|---|
| PRIMARY KEY | allowed | allowed | allowed | allowed — [native] r1-probe logs |
| UNIQUE key | allowed | allowed | allowed | allowed — [native] r1d unique |
| non-unique secondary index (leftmost) | **allowed** [official InnoDB "nonstandard key"; R2 erred writing absolute strict] | allowed | **rejected: ERROR 6125** under default `restrict_fk_on_non_standard_key=ON` [native R3 + r1d]; **allowed when flag OFF** — [native R3 NEW RUN: `fk_nu_off` landed on `pnu(ix)`] | **allowed** — [native: r1-probe2 `r1d nonunique` rc=0, no 1822] |
| non-leftmost index on target cols | rejected 1215 | rejected 1822 | rejected 6125 | rejected 1822 — [native] r1d non-leftmost |
| no usable index | rejected 1215 | rejected 1822 | rejected 6125 | rejected 1822 — [native] r1d noindex |
| existing-FK binding vs new-FK eligibility | binding only needs matching constraint name | same | same | same — [native] probes |

- **[official]** 8.4 `restrict_fk_on_non_standard_key` documented in refman/8.4 server-system-variables; default ON since 8.4.0.
- **[source-proven]** T11 history diff `20649919`/r1 probes already carry the 6125-vs-1822 version/flag distinction — R2's flat "strict" table was coarser than the implementation.

## ER1.3 — SET DEFAULT — conflict RESOLVED by native evidence

- **[official]** MySQL manual states InnoDB/NDB do not recognize `SET DEFAULT` referential actions (doc text).
- **[native-observed]** Reality on the anchors — DDL **accepted and lands**:
  - MySQL 8.0.46: `fk_sd SET DEFAULT/NO ACTION` in I_S.RC (r1-probe2.log)
  - MySQL 8.4.10: same landing (`fk_sd NO ACTION/SET DEFAULT`) — r1-probe2 + R3 NEW RUN `mysql84-restrict-setdefault.log`
  - TiDB v8.5.0: `fk_sd SET DEFAULT/NO ACTION` lands (r1-probe2.log tidb round)
  - MySQL 5.7.44: probe did not record landing (sd rows empty) — **[unresolved]** for 5.7 specifically; doc suggests rejection (1215/foreign keys with SET DEFAULT not supported by InnoDB) but no landing row captured.
- Resolution: the doc's "not recognized" is about **runtime enforcement semantics**; the DDL *declaration* is stored on 8.x/TiDB anchors. T11 models the declared action as a spec fact — **[source-proven]**, consistent with observed behavior. Scope note: runtime enforcement divergence (what SET DEFAULT actually does at delete time) is **not** audited by T11 — **[bounded]**.
- If reviewer wants the 5.7 cell settled, a minimal follow-up probe can be run; current evidence does not claim it.

## ER1.4 — TiDB DROP CONSTRAINT spelled form on FK — clarified

- **[native-observed R3 NEW RUN]** `tidb85-drop-constraint.log` on TiDB v8.5.0 (`tidb_enable_foreign_key=ON`):
  - `ALTER TABLE c1 DROP CONSTRAINT fk_dc` → statement **accepted** (rc=0) BUT `Warning 1105 tidb_enable_check_constraint is off`; **FK remains** in TABLE_CONSTRAINTS; supporting index `fk_dc` kept.
  - `ALTER TABLE c1 DROP FOREIGN KEY fk_dc` → constraint row gone; supporting index kept (native FK semantics).
- **[native-observed R1]** r1-probe2 tidb round: same survival; check targets DO get removed by `DROP CONSTRAINT` when it's a CHECK.
- **[native-observed R1]** MySQL 8.x contrast: `DROP CONSTRAINT fk` actually removes the FK (poststate=0); MySQL 5.7 rejects the syntax (poststate=1 retained).
- Conclusion: TiDB spelled `DROP CONSTRAINT` on an FK is a **warned no-op** — accepted but never removes an FK (routed to CHECK-arm handling). It stays at the CHECK-clause boundary (T12) — **bounded**, not a product defect: T11 only models `DROP FOREIGN KEY` for FK removal.

## Cross-cutting unchanged rows
PK/UNIQUE rows from R2 remain accurate (no conflict found) — carried as REUSED-equivalent content.
