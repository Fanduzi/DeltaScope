# T11 Spec review — issue #90 acceptance contract vs evidence

Parent: #79 (official DDL semantic acceptance). #90 scope: unified PK/UNIQUE/FK CREATE/ALTER governance, ordered state, DROP FOREIGN KEY semantics.

| #90 acceptance item | Status | Evidence basis |
|---|---|---|
| ALTER ADD PRIMARY KEY feeds same max-count + naming semantics as CREATE | **behavior-verified** | pk-max-alter (9), pk-max-create-pair (8), pk-name-alter-control (8) + db_ddl |
| ALTER ADD FOREIGN KEY feeds forbid + naming rules | **behavior-verified** | fk-alter-firstpath (15), fk-alter-two (8), fk-alter-bare (9), fk-name-alter-* (17) |
| FK members / supporting indexes / referenced-key identity / dependent edges / same-statement facts modeled | **source + behavior verified** | fk members in rule metadata; supporting-index dependency (drop-needed-index); same-statement PK facts (R2 commits) |
| DROP FOREIGN KEY: proven-present vs proven-absent vs unknown | **behavior-verified** | ordered-drop-present (15), dropfk-missing (13), dropfk-provider-present (15), dropfk-constraints-unknown (17), dropfk-exists-offline (13) |
| Unsupported/unproven metadata stays evidence gap, never fabricated | **behavior-verified** | constraints-unknown case; MATCH stays unmodeled; unvouch on unknown-kind drop targets |
| MySQL 5.7/8.0/8.4 + TiDB 8.5 coverage | **native-verified** | db_ddl ×4 anchors (33/33/33/34), syntax_negative ×4 |
| Four-surface shared semantics | **behavior-verified (R2)** | transports/r2-parity-matrix.md — identical verdict/coverage/findings under identical isolated policy |
| Not-yet-proven scope | declared | TiDB `DROP CONSTRAINT fk` spelled form (CHECK boundary → T12); MATCH semantic actions |
| #79 parent contract | compliant | policy violations vs evidence gaps vs unsupported vs parse failures vs complete-audit remain distinct; inventory updated; decision record bound |

## Rule ownership (T11-owned)
`ddl.table.foreign_key.forbid`, `ddl.constraint.foreign_key.name.{contains,prefix,suffix}.require`, `ddl.table.primary_key.columns.max_count`, `ddl.constraint.primary_key.name.*`, `ddl.constraint.unique_key.name.*`, `ddl.alter.drop_foreign_key.{exists.require,notice}` — plus shared existence rules consumed by ordered paths.

## Classification legend
behavior-verified = Golden case + focused test pass; source-verified = code reviewed at frozen HEAD; official-semantics-verified = matches manual/native observation; bounded = explicit non-claim.
