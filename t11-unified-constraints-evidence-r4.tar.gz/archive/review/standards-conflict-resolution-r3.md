# Standards conflict resolution R3

| # | Conflict | Resolution | Status |
|---|---|---|---|
| 1 | R2 "8.4 RESTRICT not in grammar" vs official grammar | R2 wrong; grammar includes RESTRICT; lands verbatim on 8.4.10 | resolved — corrected |
| 2 | Flat "strict" eligibility vs real version/flag matrix | Rewritten per-version; 8.4 = 6125 under default flag, OFF → accepted; TiDB nonunique accepted; 5.7/8.0 InnoDB nonstandard-key allowed | resolved — corrected |
| 3 | SET DEFAULT: doc "not recognized" vs native landing | Declaration lands on 8.0.46/8.4.10/TiDB v8.5.0 (I_S.RC rows); doc refers to enforcement semantics; T11 models declared action only; runtime enforcement divergence = bounded non-claim; **5.7 cell unresolved** (no landing evidence captured) | resolved with scoped bound |
| 4 | TiDB DROP CONSTRAINT "accepted" vs "removes FK" | Both facts kept: statement accepted (rc=0) BUT warned no-op for FKs — FK survives, index kept; distinct from DROP FOREIGN KEY which removes; stays T12 boundary | resolved — clarified |
