# T11-R4 — SET DEFAULT final verdict (supersedes R3 ER1.3 resolution)

R3 explained doc-vs-native as "doc = runtime semantics only". That framing is **withdrawn** per work order: the MySQL refman text covers *DDL acceptability* ("is not recognized as part of the foreign key definition"), not merely delete-time behavior. The R4 verdict restates the conflict honestly: the official doc says InnoDB does not recognize SET DEFAULT; the anchors' observed behavior is version-specific and partially divergent — recorded as divergence, not reinterpreted.

## A. Official documentation
- dev.mysql.com refman 8.0/8.4 `create-table-foreign-keys`: `SET DEFAULT` is recognized by the parser but **not recognized as part of an FK definition** by InnoDB/NDB (stated alongside RESTRICT/NO ACTION handling). **[official]**

## B/C. Native DDL result + FK landing — R4 NEW RUN, per-statement evidence
Disposable containers, ephemeral root pw via `MYSQL_PWD` env (never on argv/log), dedicated schema `r4sd`, unique names. Raw: `native/r4-setdefault-commands.log` + `native/r4-setdefault-results/*.txt` (per-stmt sql/rc/stdout/stderr). Digest records in commands.log.

| Anchor | Image | ON DELETE SET DEFAULT | ON UPDATE SET DEFAULT | FK landed? |
|---|---|---|---|---|
| MySQL 5.7.44 | mysql:5.7.44 | **rc=1 ERROR 1215 (HY000)** Cannot add foreign key constraint | rc=1 same error | NO — TC/RC empty |
| MySQL 8.0.46 | mysql:8.0.46 | rc=0 | rc=0 | YES — I_S.RC `NO ACTION / SET DEFAULT`; SHOW CREATE preserves clause |
| MySQL 8.4.10 | mysql:8.4.10 | rc=0 | rc=0 | YES — I_S.RC `NO ACTION / SET DEFAULT` (del) / `SET DEFAULT / NO ACTION` (upd) |
| TiDB v8.5.0 | pingcap/tidb:v8.5.0 (digest `490861bd4a2f…`) | rc=0 | rc=0 | YES — `NO ACTION / SET DEFAULT` |

Env identity per anchor recorded: VERSION(), @@version_comment, @@sql_mode, @@foreign_key_checks(=1), InnoDB SUPPORT=DEFAULT, `restrict_fk_on_non_standard_key` → 1193 unknown on 5.7/8.0, ON on 8.4.10 (independent of SET DEFAULT outcome).

## D. Product (prospective-state) prediction vs native — per version
`foreignKeyReferActionPremise` @ frozen HEAD (batch_state_fk.go L517–547, blob `6bbf645f…`):
- MySQL dialect + set_default action: `version.Major < 8 → refused`; `Major ≥ 8 → allowed`; unknown version → `provable=false` (evidence gap, not a claim).
- Non-MySQL dialects (TiDB): falls through → allowed.

| Version | Native | Product | Match |
|---|---|---|---|
| 5.7.44 | rejects (1215) | refuse (major<8) | **YES** |
| 8.0.46 | accepts+lands | allow (major≥8) | **YES** |
| 8.4.10 | accepts+lands | allow | **YES** |
| TiDB 8.5 | accepts+lands | allow | **YES** |

No product/native inconsistency found → no defect-evidence stop triggered.

## E. Doc-vs-native divergence statement (final)
- 5.7: doc and native agree (rejection) — consistent.
- 8.0/8.4/TiDB: native *accepts and stores* the declared SET DEFAULT action despite the doc's "not recognized" phrasing. T11 models only the **declared action** as a spec fact (consistent with landing); the doc's wording and any runtime enforcement divergence are recorded here as a bounded divergence — DeltaScope does not claim the doc is wrong about runtime behavior, and T11 does not audit runtime DML behavior **[bounded]**.
- 5.7 SET DEFAULT cell previously "unresolved" — now **resolved**: rejected, ERROR 1215.
