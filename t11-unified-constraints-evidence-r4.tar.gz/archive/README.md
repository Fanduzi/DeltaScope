# T11 / #90 — acceptance evidence archive (R4 final semantic-evidence round)

Task: T11 — unified PK/UNIQUE/FK CREATE/ALTER checks (issue #90)
Frozen identity: HEAD `9d2c439c46f6faed434e91c8b54ebc82abbf0787` / tree `bcec2a29997276ca8d3a173da15ce7cb4c66ab4c` / parent `d6af124165ff05ba1ca18948a7aa20c8f03df58f` / branch `milestone/mysql-tidb-ddl-completion`

## R4 scope (per work order T11-R4-FINAL-SEMANTIC-EVIDENCE-01)
- `review/r4-setdefault-final-verdict.md` — SET DEFAULT verdict rewritten: doc-vs-native stated as honest divergence, not reinterpretation; per-version product-vs-native match table (all 4 anchors match; no defect)
- `native/r4-setdefault-*` — per-statement native probe: disposable containers (mysql 5.7.44/8.0.46/8.4.10, tidb v8.5.0), ephemeral creds via env var only, image digests, per-stmt sql/argv/rc/stdout/stderr/warnings/SHOW CREATE/I_S rows, teardown log
- `matrix/case-results-r4.md` + `context-reconciliation-r4.log` — 40 cases/518 assertions; the two prior 0-findings rows corrected to `1 findings: ddl.table.foreign_key.forbid:blocker` (generator now reads expected.findings+finding_metadata)
- `source-audit/r4-refer-action-*` — COMPLETE `foreignKeyReferActionPremise` source (L508–548 incl. full set_default branch), blob `6bbf645f…`, call path, per-version mapping, pinning test `TestT11R1DReferActionBoundaries`
- `transports/r4-http-*` — original binary bound (ancestor ce7cda29 +9 commits, no audit-path delta) AND definitive re-probe: rebuilt at frozen HEAD (`vcs.revision=9d2c439c`), HTTP 200/reject/complete/1 blocker/0 gaps
- `native/historical-probes/` — the cited historical probes as standalone payloads with repo blob SHAs
- `diffs/r4-no-product-change.txt` — fresh workspace proof: HEAD/tree/parent unchanged, git status clean (tracked), diff/staged rc=0

## Preservation
R1 (`0d3cfd10…`), R2 (`b3dac993…`), R3 (`f69829f6…`) archives preserved byte-for-byte; unchanged members carried as REUSED with six-tuple provenance naming the source archive.

## Unchanged results
Golden 40/40 @ 518; four-surface parity; gates all rc=0; focused tests 140; denominator 505→506→518; product diff ZERO.
