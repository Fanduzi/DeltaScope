# T11 inventory binding — testdata/ddl-inventory/inventory.yaml

File: `testdata/ddl-inventory/inventory.yaml` at frozen HEAD `9d2c439c`.
Task registry (line 80): `T11: {issue: 90, title: "PK/UNIQUE/FK across CREATE and ALTER"}`.
Owners list (line 189) includes `tidb.alter-table.fk-check`.

## T11-owned inventory rows (`owner: T11` field line → row id line)
| owner line | id line | Row id | Notes |
|---|---|---|---|
| 604 | 565 | mysql.create-table-constraints | status_evidence cites 2026-10-25 T11 (#90): CREATE/ALTER FK parity, ON DELETE/UPDATE modeled, MATCH unmodeled |
| 1247 | 1208 | mysql.alter-table.add-primary-key | cites T11: ALTER ADD PK answers `ddl.table.primary_key.columns.max_count` matching CREATE oracle |
| 1288 | 1249 | mysql.alter-table.drop-primary-key | cites T11: drop-PK ordered path + provider-loaded FK dependents invalidation |
| 1329 | 1290 | mysql.alter-table.add-foreign-key | cites T11 parity (forbid + naming on ALTER) |
| 1370 | 1331 | mysql.alter-table.drop-foreign-key | cites T11: `exists.require` proven-missing blocker + evidence gap when constraint set unknown; ordered state removes only proven member, keeps supporting index (native on 4 anchors) |
| 4133 | 4108 | tidb.alter-table.fk-check | cites T11: FK half delivered (forbid/naming/exists on TiDB paths, FK facts under tidb_enable_foreign_key=ON); CHECK half T12 (now also closed by T12) |

All rows carry `evidence: ["file:testdata/ddl-golden/T11.json", …]` and `audit_status: audited` (fk-check row audited overall with CHECK by T12).
No inventory change required this round: R2 is evidence-only; ownership/status already recorded at frozen HEAD.
