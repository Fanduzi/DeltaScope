# T11 inventory identity @ frozen HEAD 9d2c439c

- File: `testdata/ddl-inventory/inventory.yaml`
- Blob SHA: `3cb068e166ec608984b8e3487f60dd182a3bb2db` (5056 lines)

## Six T11-owned rows — frozen-HEAD content slices

### 1. mysql.create-table-constraints (id L565, owner L604)
status_evidence cites 2026-10-25 T11: CREATE/ALTER FK parity — identical forbid finding on both paths; ON DELETE/UPDATE modeled spec facts; MATCH unmodeled evidence.

### 2. mysql.alter-table.add-primary-key (id L1208, owner L1247)
ALTER ADD PRIMARY KEY answers `ddl.table.primary_key.columns.max_count` through the produced primary index/constraint columns, matching the CREATE oracle.

### 3. mysql.alter-table.drop-primary-key (id L1249, owner L1288)
Drop-PK ordered path coexists with provider-loaded FK dependents — child tables referencing the touched parent are invalidated alongside the transition.

### 4. mysql.alter-table.add-foreign-key (id L1290, owner L1329)
Audit_status audited; evidence file:testdata/ddl-golden/T11.json; T11 ALTER-ADD parity entry.

### 5. mysql.alter-table.drop-foreign-key (id L1331, owner L1370)
`ddl.alter.drop_foreign_key.exists.require` proven-missing blocker + evidence gap on unloaded constraint sets; ordered state removes only the proven member and keeps the supporting index (native on all 4 anchors).

### 6. tidb.alter-table.fk-check (id L4108, owner L4133)
FK half T11-audited (forbid/naming/exists on TiDB, FK facts under tidb_enable_foreign_key=ON); CHECK half T12 (tidb_enable_check_constraint arm); T11.json + T12.json refs.
