#!/usr/bin/env python3
"""T17-R1 independent golden validator.

Binds three sources directly:
  A. T17.json oracle  -> artifact expected/actual   (ER4)
  B. artifact actual  -> matrix derived projection  (lossless check)
  C. expected         -> actual semantic judgment    (ER1 fields)

Usage:
  python3 validate_t17_r1.py --artifact ART.json --matrix MAT.json --oracle T17.json
Exit 0 on zero mismatches; nonzero with each mismatch on its own line.
"""
import json, sys, os, argparse, collections

REQUIRED_KINDS = {'cli_audit': 14, 'cli_metadata': 30, 'db_ddl': 4, 'db_syntax_negative': 4}
REQUIRED_CASES = 52
REQUIRED_ASSERTIONS = 852


def load(p):
    with open(p) as f:
        return json.load(f)


def steps_of(blk):
    if blk is None:
        return []
    if isinstance(blk, dict):
        return [blk]
    return blk


def flat(sts, key):
    return [f for st in sts or [] for f in st.get(key) or []]


def norm_sql(sql):
    return '; '.join(sql) if isinstance(sql, list) else str(sql)


# ---------- case_id maps ----------

def oracle_case_map(oracle):
    """T17.json -> {case_id: (kind, oracle_entry)}.

    cli_cases/metadata_cases carry per-case ids. db_ddl and
    db_syntax_negative are anchor-fan-out templates: the same oracle block
    binds `T17.db.<anchor>.ddl` / `T17.db.<anchor>.syntax_negative` for every
    anchor in oracle.anchors."""
    m = {}
    for c in oracle.get('cli_cases') or []:
        m['T17.cli.' + c['id']] = ('cli_audit', c)
    for c in oracle.get('metadata_cases') or []:
        m['T17.meta.' + c['id']] = ('cli_metadata', c)
    for anchor in (oracle.get('anchors') or {}):
        m[f'T17.db.{anchor}.ddl'] = ('db_ddl',
                                     {'steps': oracle.get('ddl_steps') or [],
                                      'anchor': anchor})
        m[f'T17.db.{anchor}.syntax_negative'] = ('db_syntax_negative',
                                                 dict(oracle.get('syntax_negative') or {},
                                                      anchor=anchor))
    return m


# ---------- ER4: oracle -> artifact binding ----------

def bind_oracle(oracle, artifact, errs):
    omap = oracle_case_map(oracle)
    req = set(oracle.get('required_case_ids') or omap.keys())
    ids = [c['case_id'] for c in artifact['cases']]
    if set(req) != set(ids):
        errs.append(f"oracle.required!=artifact diff={set(req) ^ set(ids)}")
    for c in artifact['cases']:
        cid = c['case_id']
        if cid not in omap:
            errs.append(f"{cid}: no oracle case")
            continue
        kind, oc = omap[cid]
        if c['kind'] != kind:
            errs.append(f"{cid}.kind oracle={kind} artifact={c['kind']}")
        # input SQL + dialect + profile (db_ddl binds joined step sqls below)
        if kind != 'db_ddl' and oc.get('sql') is not None and norm_sql(oc.get('sql')) != norm_sql(c.get('input_sql')):
            errs.append(f"{cid}.input_sql differs from oracle")
        if oc.get('dialect') and oc.get('dialect') != c.get('dialect'):
            errs.append(f"{cid}.dialect")
        if oc.get('anchor') and oc.get('anchor') != c.get('anchor'):
            errs.append(f"{cid}.anchor")
        oe = oc.get('expect') or {}
        ae = c.get('expected') or {}
        if kind == 'db_ddl':
            # template binding: oracle ddl_steps <-> artifact expected.steps
            os_ = oc.get('steps') or []
            es_ = ae.get('steps') or []
            onames = [s.get('name') for s in os_]
            enames = [s.get('name') for s in es_]
            if onames != enames:
                errs.append(f"{cid}.expected.steps.names oracle={onames} expected={enames}")
            # expected.steps carry name/rc/verify but not sql; oracle sql
            # binds to actual step sql (below) and to joined input_sql.
            osql = [s.get('sql') for s in os_ if s.get('sql')]
            if osql and norm_sql(osql) != norm_sql(c.get('input_sql')):
                errs.append(f"{cid}.input_sql differs from oracle")
            for i, (o, x) in enumerate(zip(os_, es_)):
                if 'expect_rc' in o and o['expect_rc'] != x.get('rc'):
                    errs.append(f"{cid}.expected.steps[{i}].rc oracle={o['expect_rc']} expected={x.get('rc')}")
                ov, xv = o.get('verify') or [], x.get('verify') or []
                if len(ov) != len(xv):
                    errs.append(f"{cid}.expected.steps[{i}].verify len")
                for j, (vo, vx) in enumerate(zip(ov, xv)):
                    if vo.get('sql') is not None and vo['sql'] != vx.get('sql'):
                        errs.append(f"{cid}.expected.steps[{i}].verify[{j}].sql")
                    if 'expect' in vo and str(vo['expect']) != str(vx.get('expect')):
                        errs.append(f"{cid}.expected.steps[{i}].verify[{j}].expect")
            # oracle <-> actual steps (name/order/sql/expect_rc/verify)
            as_ = steps_of((c.get('actual') or {}).get('steps'))
            anames = [s.get('name') for s in as_]
            if onames != anames:
                errs.append(f"{cid}.steps.names oracle={onames} actual={anames}")
            for i, (o, a) in enumerate(zip(os_, as_)):
                if o.get('sql') is not None and o['sql'] != a.get('sql'):
                    errs.append(f"{cid}.steps[{i}].sql")
                if 'expect_rc' in o and o['expect_rc'] != a.get('rc'):
                    errs.append(f"{cid}.steps[{i}].expect_rc oracle={o['expect_rc']} actual_rc={a.get('rc')}")
                ov2, av = o.get('verify') or [], a.get('verify') or []
                if len(ov2) != len(av):
                    errs.append(f"{cid}.steps[{i}].verify len")
                for j, (vo, vy) in enumerate(zip(ov2, av)):
                    if vo.get('sql') is not None and vo['sql'] != vy.get('sql'):
                        errs.append(f"{cid}.steps[{i}].verify[{j}].sql")
                    if 'expect' in vo and str(vo['expect']) != str(vy.get('output')):
                        errs.append(f"{cid}.steps[{i}].verify[{j}].expect oracle={vo['expect']!r} actual={vy.get('output')!r}")
            continue
        if kind == 'db_syntax_negative':
            ox = oc.get('expect') or {}
            for f in ('rc_nonzero', 'error_class', 'forbidden_markers'):
                if f in ox and ox.get(f) != ae.get(f):
                    errs.append(f"{cid}.expected.{f} oracle!=artifact")
            if oc.get('sql') and norm_sql(oc['sql']) != norm_sql(c.get('input_sql')):
                errs.append(f"{cid}.input_sql differs from oracle")
            continue
        # scalar expectations present in oracle must equal artifact expected
        for f in ('exit', 'verdict', 'statements', 'findings', 'diagnostics',
                  'unsupported', 'evidence_gaps'):
            if f in oe and oe.get(f) != ae.get(f):
                errs.append(f"{cid}.expected.{f} oracle!=artifact")
        for f in ('coverage', 'statement_coverage', 'finding_entries',
                  'evidence_gap_entries', 'unsupported_entries', 'version'):
            if f in oe and oe.get(f) != ae.get(f):
                errs.append(f"{cid}.expected.{f} oracle!=artifact")
        # metadata phases: names/order/sql/expect_rc/verify
        for ph in ('setup', 'execute', 'post_verify', 'teardown'):
            os_, as_ = steps_of(oc.get(ph)), steps_of((c.get('actual') or {}).get(ph))
            # oracle steps must each exist in actual with same name+order+sql
            onames = [s.get('name') for s in os_]
            anames = [s.get('name') for s in as_]
            if onames != anames:
                errs.append(f"{cid}.{ph}.names oracle={onames} actual={anames}")
            for i, (o, a) in enumerate(zip(os_, as_)):
                if o.get('sql') is not None and o.get('sql') != a.get('sql'):
                    errs.append(f"{cid}.{ph}[{i}].sql")
                if 'expect_rc' in o and o['expect_rc'] != a.get('rc'):
                    errs.append(f"{cid}.{ph}[{i}].expect_rc oracle={o['expect_rc']} actual_rc={a.get('rc')}")
                ov, av = o.get('verify') or [], a.get('verify') or []
                if len(ov) != len(av):
                    errs.append(f"{cid}.{ph}[{i}].verify len")
                for j, (x, y) in enumerate(zip(ov, av)):
                    if x.get('sql') is not None and x['sql'] != y.get('sql'):
                        errs.append(f"{cid}.{ph}[{i}].verify[{j}].sql")
                    if 'expect' in x and str(x['expect']) != str(y.get('output')):
                        errs.append(f"{cid}.{ph}[{i}].verify[{j}].expect oracle={x['expect']!r} actual={y.get('output')!r}")
    return omap


# ---------- ER1: finding attribution ----------

def stmt_index(st, pos):
    v = st.get('index')
    return v if isinstance(v, int) else pos


def findings_grouped(sts):
    """{stmt_index: Counter((rule_id,level))} — multiset per statement,
    immune to intra-statement order but sensitive to moves/dup/deletes."""
    g = collections.defaultdict(collections.Counter)
    locs = collections.defaultdict(list)
    for pos, st in enumerate(sts or []):
        si = stmt_index(st, pos)
        for f in st.get('findings') or []:
            g[si][(f.get('rule_id'), f.get('level'))] += 1
            locs[si].append({'statement_index': f.get('statement_index'),
                             'location': f.get('location'),
                             'rule_id': f.get('rule_id')})
    return dict(g), dict(locs)


def expected_grouped(entries):
    g = collections.defaultdict(collections.Counter)
    for x in entries or []:
        g[x.get('index')][(x.get('rule_id'), x.get('level'))] += 1
    return dict(g)


# ---------- expected -> actual semantic judgment ----------

def semantic_checks(c, errs):
    cid = c['case_id']
    k = c['kind']
    e = c.get('expected') or {}
    a = c.get('actual') or {}
    if k not in ('cli_audit', 'cli_metadata'):
        if k == 'db_ddl':
            se = steps_of(e.get('steps'))
            sa = steps_of(a.get('steps'))
            if len(se) != len(sa):
                errs.append(f"{cid}.steps len {len(se)}!={len(sa)}")
            for i, (x, y) in enumerate(zip(se, sa)):
                if x.get('name') != y.get('name'):
                    errs.append(f"{cid}.steps[{i}].name")
                if x.get('rc') is not None and x.get('rc') != y.get('rc'):
                    errs.append(f"{cid}.steps[{i}].rc {x.get('rc')}!={y.get('rc')}")
                ve, va = x.get('verify') or [], y.get('verify') or []
                if len(ve) != len(va):
                    errs.append(f"{cid}.steps[{i}].verify len")
                for j, (vx, vy) in enumerate(zip(ve, va)):
                    if 'expect' in vx and str(vx['expect']) != str(vy.get('output')):
                        errs.append(f"{cid}.steps[{i}].verify[{j}].expect={vx['expect']!r} out={vy.get('output')!r}")
        elif k == 'db_syntax_negative':
            if e.get('error_class') != a.get('error_class'):
                errs.append(f"{cid}.error_class")
            if bool(e.get('rc_nonzero')) != bool(a.get('rc')):
                errs.append(f"{cid}.rc_nonzero")
            for m in e.get('forbidden_markers') or []:
                if m in (a.get('stderr') or '') or m in (a.get('stdout') or ''):
                    errs.append(f"{cid}.forbidden_marker {m!r}")
        return

    p = a.get('parsed') or {}
    if 'exit' in e and e['exit'] != a.get('exit'):
        errs.append(f"{cid}.exit {e.get('exit')}!={a.get('exit')}")
    if 'verdict' in e and e['verdict'] != p.get('verdict'):
        errs.append(f"{cid}.verdict")
    cov = p.get('coverage')
    cov = cov.get('status') if isinstance(cov, dict) else cov
    if e.get('coverage') is not None and e['coverage'] != cov:
        errs.append(f"{cid}.coverage")
    sc_a = [(s.get('coverage') or {}).get('status') for s in p.get('statements', [])]
    if e.get('statement_coverage') is not None and e['statement_coverage'] != sc_a:
        errs.append(f"{cid}.stmt_cov")
    if 'findings' in e and e['findings'] != len(flat(p.get('statements'), 'findings')):
        errs.append(f"{cid}.findings count")
    if 'diagnostics' in e and e['diagnostics'] != len(p.get('diagnostics') or []):
        errs.append(f"{cid}.diagnostics")
    if 'unsupported' in e and e['unsupported'] != len(p.get('unsupported') or []):
        errs.append(f"{cid}.unsupported count")
    if 'evidence_gaps' in e and e['evidence_gaps'] != len(flat(p.get('statements'), 'evidence_gaps')):
        errs.append(f"{cid}.evidence_gaps count")

    # ER1 — finding attribution: index(statement) + rule_id + level +
    # per-statement count, as a grouped comparison immune to intra-statement
    # reorder but sensitive to cross-statement moves.
    if 'finding_entries' in e:
        eg = expected_grouped(e['finding_entries'])
        ag, alocs = findings_grouped(p.get('statements'))
        if eg != ag:
            errs.append(f"{cid}.findings grouped expected={ {i: v for i, v in sorted(eg.items())} } actual={ {i: v for i, v in sorted(ag.items())} }")
        # cross-check finding.statement_index field vs enclosing statement index
        for si, fl in (alocs or {}).items():
            for f in fl:
                if f['statement_index'] is not None and f['statement_index'] != si:
                    errs.append(f"{cid}.findings stmt_index_field {f['statement_index']}!=enclosing {si}")
    # evidence gap entries — set comparison (semantically unordered)
    if 'evidence_gap_entries' in e:
        def gkey(g):
            return (g.get('index'), g.get('rule_id'), g.get('reason_code'),
                    json.dumps(sorted(g.get('required_facts') or [])))
        egset = {gkey(x) for x in e['evidence_gap_entries']}
        agset = {gkey({'index': stmt_index(st, pos), **g})
                 for pos, st in enumerate(p.get('statements') or [])
                 for g in (st.get('evidence_gaps') or [])}
        if egset != agset:
            errs.append(f"{cid}.evidence_gap_entries expected-actual={egset - agset} actual-expected={agset - egset}")
    if 'unsupported_entries' in e:
        # actual unsupported[] carries feature/sql/reason/metadata but no
        # index field; oracle index is the statement position (provenance).
        for i, (x, y) in enumerate(zip(e['unsupported_entries'], p.get('unsupported') or [])):
            for f in ('feature', 'reason', 'metadata'):
                if x.get(f) != y.get(f):
                    errs.append(f"{cid}.unsup[{i}].{f}")
            if 'sql' in x and x['sql'] != y.get('sql'):
                errs.append(f"{cid}.unsup[{i}].sql")
    if 'version' in e:
        va = (a.get('version_evidence') or {}).get('resolved') or {}
        if e['version'].get('product') != va.get('product') or e['version'].get('version') != va.get('version'):
            errs.append(f"{cid}.version")
    # metadata step verification rc/stdout binding (actual already bound
    # to oracle in bind_oracle; here bind expected phases when present)
    if k == 'cli_metadata':
        for ph in ('setup', 'execute', 'post_verify', 'teardown'):
            for i, s in enumerate(steps_of(a.get(ph))):
                if 'rc' not in s:
                    errs.append(f"{cid}.{ph}[{i}] missing rc")


# ---------- matrix projection (B check) ----------

def derive_row(c):
    k = c['kind']
    e = c.get('expected') or {}
    a = c.get('actual') or {}
    r = {'case_id': c['case_id'], 'kind': k, 'anchor': c.get('anchor'),
         'sql': norm_sql(c.get('input_sql')),
         'assertions': len(c.get('assertions', [])),
         'assert_ok': all(x.get('ok') for x in c.get('assertions', [])),
         'status': c.get('status')}
    if k in ('cli_audit', 'cli_metadata'):
        p = a.get('parsed') or {}
        ag, alocs = findings_grouped(p.get('statements'))
        r.update({
            'exit_e': e.get('exit'), 'exit_a': a.get('exit'),
            'verdict_e': e.get('verdict'), 'verdict_a': p.get('verdict'),
            'cov_e': e.get('coverage'),
            'cov_a': (p.get('coverage') or {}).get('status'),
            'stmt_cov_e': e.get('statement_coverage'),
            'stmt_cov_a': [(s.get('coverage') or {}).get('status') for s in p.get('statements', [])],
            'findings_e': e.get('finding_entries', []),
            'findings_a': [{'index': si, 'rule_id': rid, 'level': lv}
                           for si, fl in sorted(ag.items())
                           for (rid, lv), n in sorted(fl.items()) for _ in range(n)],
            'finding_locations_a': [{'index': si, **loc}
                                    for si, ll in sorted(alocs.items()) for loc in ll],
            'gaps_e': e.get('evidence_gaps'),
            'gaps_a': len(flat(p.get('statements'), 'evidence_gaps')),
            'gap_entries_a': [{'index': stmt_index(st, pos),
                               'rule_id': g.get('rule_id'),
                               'reason_code': g.get('reason_code'),
                               'required_facts': g.get('required_facts')}
                              for pos, st in enumerate(p.get('statements') or [])
                              for g in (st.get('evidence_gaps') or [])],
            'gap_entries_e': e.get('evidence_gap_entries'),
            'unsup_e': e.get('unsupported'),
            'unsup_a': len(p.get('unsupported') or []),
            'unsup_entries_e': e.get('unsupported_entries'),
            'unsup_entries_a': [{'feature': u.get('feature'), 'reason': u.get('reason'),
                                 'metadata': u.get('metadata')}
                                for u in (p.get('unsupported') or [])],
            'diag_e': e.get('diagnostics'),
            'diag_a': len(p.get('diagnostics') or []),
            'version_e': e.get('version'),
            'version_a': (a.get('version_evidence') or {}).get('resolved'),
        })
        if k == 'cli_metadata':
            for ph in ('setup', 'execute', 'post_verify', 'teardown'):
                r[ph] = [{'name': s.get('name'), 'sql': s.get('sql'), 'rc': s.get('rc'),
                          'stdout': s.get('stdout'), 'stderr': s.get('stderr'),
                          'verify': [{'assert': v.get('assert'), 'sql': v.get('sql'),
                                      'rc': v.get('rc'), 'output': v.get('output'),
                                      'stderr': v.get('stderr')} for v in s.get('verify', [])]}
                         for s in steps_of(a.get(ph))]
            r['database'] = a.get('database')
    elif k == 'db_ddl':
        r['steps'] = [{'name': s.get('name'), 'sql': s.get('sql'), 'rc': s.get('rc'),
                       'stdout': s.get('stdout'), 'stderr': s.get('stderr'),
                       'verify': [{'assert': v.get('assert'), 'sql': v.get('sql'),
                                   'rc': v.get('rc'), 'output': v.get('output'),
                                   'stderr': v.get('stderr')} for v in s.get('verify', [])]}
                      for s in steps_of(a.get('steps'))]
        r['steps_e'] = [{'name': s.get('name'), 'rc': s.get('rc'),
                         'verify': [{'assert': v.get('assert'), 'expect': v.get('expect')}
                                    for v in s.get('verify', [])]}
                        for s in steps_of(e.get('steps'))]
        r['database'] = a.get('database')
    elif k == 'db_syntax_negative':
        r.update({'rc_nonzero_e': e.get('rc_nonzero'), 'error_class_e': e.get('error_class'),
                  'argv_a': a.get('argv'), 'rc_a': a.get('rc'), 'stdout_a': a.get('stdout'),
                  'stderr_a': a.get('stderr'), 'error_class_a': a.get('error_class'),
                  'forbidden_markers': e.get('forbidden_markers')})
    return r


def deep_cmp(a, b, path, errs):
    if type(a) != type(b):
        errs.append(f"{path}: type {type(a).__name__}!={type(b).__name__}")
        return
    if isinstance(a, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a or k not in b:
                errs.append(f"{path}.{k}")
            else:
                deep_cmp(a[k], b[k], f"{path}.{k}", errs)
    elif isinstance(a, list):
        if len(a) != len(b):
            errs.append(f"{path}: len {len(a)}!={len(b)}")
        for i, (x, y) in enumerate(zip(a, b)):
            deep_cmp(x, y, f"{path}[{i}]", errs)
    elif a != b:
        errs.append(f"{path}: {a!r}!={b!r}")


def verify(art_path, mat_path, ora_path):
    errs = []
    for label, p in (('artifact', art_path), ('matrix', mat_path),
                     ('oracle', ora_path)):
        if not p or not os.path.exists(p):
            return [f"required input missing: {label} {p}"]
        try:
            json.load(open(p))
        except Exception as e:
            return [f"required input unreadable/malformed: {label} {p}: {e}"]
    artifact = load(art_path)
    oracle = load(ora_path)
    cases = artifact['cases']
    kinds = collections.Counter(c['kind'] for c in cases)
    if dict(kinds) != REQUIRED_KINDS:
        errs.append(f"kinds {dict(kinds)}")
    ids = [c['case_id'] for c in cases]
    if len(ids) != len(set(ids)):
        errs.append('dup case_id artifact')
    if len(cases) != REQUIRED_CASES:
        errs.append(f"cases {len(cases)}")
    na = sum(len(c.get('assertions', [])) for c in cases)
    if na != REQUIRED_ASSERTIONS:
        errs.append(f"assertions {na}")
    bad = [c['case_id'] for c in cases if not all(x.get('ok') for x in c.get('assertions', []))]
    if bad:
        errs.append(f"assert fail {bad}")
    notpass = [c['case_id'] for c in cases if c.get('status') != 'pass']
    if notpass:
        errs.append(f"status!=pass {notpass}")
    # A: oracle -> artifact
    bind_oracle(oracle, artifact, errs)
    # C: expected -> actual
    for c in cases:
        semantic_checks(c, errs)
    # B: artifact -> matrix lossless (fail-closed: presence/parse verified above)
    mrows = load(mat_path)
    if [r['case_id'] for r in mrows] != ids:
        errs.append('matrix case_id order/set differs')
    mmap = {r['case_id']: r for r in mrows}
    for c in cases:
        cid = c['case_id']
        if cid in mmap:
            deep_cmp(mmap[cid], derive_row(c), cid, errs)
    return errs


def main():
    ap = argparse.ArgumentParser()
    here = os.path.dirname(os.path.abspath(__file__))
    ap.add_argument('--artifact', default=os.path.join(here, '..', 'golden', 'artifact.json'))
    ap.add_argument('--matrix', default=os.path.join(here, '..', 'golden', 'matrix-t17.json'))
    ap.add_argument('--oracle', default=os.path.join(here, '..', 'golden', 'T17.json'))
    ap.add_argument('--emit-matrix', action='store_true')
    a = ap.parse_args()
    if a.emit_matrix:
        art = load(a.artifact)
        json.dump([derive_row(c) for c in art['cases']], sys.stdout, indent=1)
        return 0
    errs = verify(a.artifact, a.matrix, a.oracle)
    for e in errs:
        print(e)
    print(f"verify: {len(errs)} mismatches")
    return 0 if not errs else 1


if __name__ == '__main__':
    sys.exit(main())
