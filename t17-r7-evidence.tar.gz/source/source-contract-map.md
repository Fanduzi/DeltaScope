# T17 ER5 — Source / Contract / case_id Mapping (frozen HEAD 36e616f8)

Scope: database/schema lifecycle for MySQL 5.7.44 / 8.0.46 / 8.4.10 and
TiDB v8.5.0 — `CREATE|ALTER|DROP DATABASE|SCHEMA` (synonyms), IF-clauses,
default charset/collation/encryption, conditional three-state
prospective tracking, namespace policy, and the T17/T20 placement
boundary. AC1–AC5 refer to issue #96.

## 1. Pipeline map (SQL → verdict)

| Stage | File (committed blob @36e616f8) | Key symbols / lines | Fact ownership | T17 case_ids |
|---|---|---|---|---|
| SQL parse | `internal/infrastructure/parser/tidb/extractor.go` (`ceafd4cdd813`) | `extractCreateDatabase` ~:990 → `DDLOperationCreateSchema`; `extractDropDatabase` ~:1008 → `DDLOperationDropSchema` (+`if_exists`); `extractAlterDatabase` ~:1786 → `DDLOperationAlterSchema`. `DATABASE`/`SCHEMA` normalize identically; options → `ddl.Options` (charset/collate/encryption/placement_policy), unrecognized → `UnextractedOptions` | statement shape; synonym folding; option extraction | all 52 |
| Normalized model | `internal/domain/spec/ddl.go` (`adf99e6b`) + `spec/statement.go` (`8521f01`) | `DDL.Operation`, `DDL.ObjectName` (lowercased), `DDL.Options`, `DDL.UnextractedOptions`, `Statement.Index/Kind` | namespace identity ≠ table identity | all 52 |
| Metadata resolution | `internal/application/audit/metadata.go` (`d0d6978b`) | `planObjectLookup` :1015; `resolveObjectSnapshot` :1154 (provider errors propagate — never downgrade to Unavailable); schema branch ~:1088; nameless ALTER → `AlterDefaultSchema` :1025 | known-present / known-absent / unknown (3-state) | t17-cli-unknown-state-mysql; all `t17-meta-*` (30 cases) |
| Policy / rules | `internal/domain/rule/ddl/lifecycle_t17_rules.go` (`4473b473`) | `newSchemaExistenceRule` :72 → `ddl.database.create.exists.forbid` / `alter.exists.require` / `drop.exists.require` (unvouched existence → `schema.existence` evidence gap, reason `unknown_schema_state`); `newDatabaseDenylistRule` :148 (`schemas:` param, alias/case/qualification-safe); `newSchemaEncryptionApplicabilityRule` :202 (MySQL <8.0.16 blocker; TiDB notice; unresolved version → `target.version` gap); `newDatabaseSystemModifyRule` :290 | findings vs gaps ownership | t17-cli-if-arms-*, t17-mysql80-denylist, t17-mysql80/tidb85-system-*, t17-*-encryption*, t17-cli-custom-levels-mysql |
| Register | `internal/domain/rule/ddl/register.go` (`ed8f3aed`) | :786-801 rule registration incl. denylist/system/encryption | rule surface | t17-cli-disabled-mysql (all-off → clean pass), t17-mysql80-all-disabled |
| Prospective state | `internal/application/audit/batch_state_schema.go` (`378ec2dc`) | `schemaTargetName` :45 (explicit DB target overrides request schema); `resolveSchema` :66; `schemaPostAttrs` :134 (Apply/Withhold/Refused three-way); `applyCreateSchema` :329 (INE conditional convergence — no `batchCreated` for unproven create); `applyAlterSchema` :380; `applyDropSchema` :448 (namespace + descendants invalidation); `schemaDeclaredOptions` :522; `projectSchemaTarget` :537; `schemaStateForTarget` :576 | ordered batch semantics; recreation cannot revive old objects/defaults/stats | t17-mysql80-drop-cascade, t17-mysql80-recreate, t17-mysql80-cross-namespace, t17-cli-unknown-state-mysql, t17-*-ine-* |
| Coverage aspects | `internal/application/audit/coverage.go` (`dee2cd26`) | `extractedOptionGap` :219-231 — `placement_policy`: MySQL→vendor boundary; TiDB→`create_schema`/`alter_schema` ONLY stays unaudited (T17/T20 boundary, this commit); `statementCoverageAspects` ~:438 — TiDB placement skip narrowed to `CreateTable`/`AlterTable`; `tiflash_replica`/`read_only`/charset/collate/encryption handled | recognized-but-unaudited vs vendor-boundary vs modeled | t17-cli-tidb-placement-aspect, t17-cli-mysql-placement-vendor, t17-cli-ine-placement-tidb, t17-tidb85-placement-missing, t17-*-tiflash-* |
| Verdict / report | `internal/application/audit/service.go` (`7c47a9a8`) | `AuditSQL` :88 → `Service.Audit` :93; aggregate precedence incomplete>unverified>complete; reject never hidden | public contract (kind/index/target/findings/gaps/unsupported/verdict/coverage) | all 52 |
| SDK | `pkg/deltascope/audit.go` | `Audit(ctx, Request)` :297 → same engine, same tuple | SDK parity | parity-4cases |
| CLI | `internal/interfaces/cli/audit.go` (`b613e964`) | `audit --file --dialect --config --format json` → exit code | CLI parity + exit mapping | 14 `cli_audit` cases |
| HTTP | `internal/interfaces/http/handler.go` (`1e6e581`) | `POST /v1/audit` — result nested; unsupported → HTTP 400 + error code (transport mapping; semantic tuple identical) | HTTP parity | parity |
| MCP | `internal/interfaces/mcp/audit_tool.go` (`e0cb1fba`) | `audit_sql` tool; `config_path` per-request arg; `structuredContent` | MCP parity | parity |
| Oracle | `testdata/ddl-golden/T17.json` | 52 required==executed case ids; per-case expectations + real exec records | independent expectations | — |
| ADR | `docs/decisions/2026-11-10-ddl-database-schema-lifecycle.md` | Decisions 1-8 + R1 amendments + **T17-acceptance amendment** (schema placement boundary) | contract rationale | — |

## 2. AC → source → case_id

- **AC1 lifecycle/attributes/conditionals**: extractor ops + batch_state_schema Apply/Withhold/Refused + `ddl.database.*.exists.*` rules. Cases: `t17-cli-seed-*` (canonical create→alter→drop), `t17-cli/met-*-if-*`, `*-create-duplicate`, `*-create-if-noop`, `*-drop-absent`, `*-drop-if-noop`, `*-alter-absent`, `*-charset-lifecycle`, `*-synonym-lifecycle` (SCHEMA synonym), `*-nameless-alter` (ALTER DATABASE without name → request default schema).
- **AC2 namespace & policy**: `schemaTargetName` explicit-DB precedence; denylist `schemas:` match safe against alias/case/qualification; `system.modify.forbid` uniform answer over divergent native leniency (5.7/TiDB accept `mysql` natively, 8.0+ refuses). Cases: `t17-mysql80-denylist`, `t17-mysql80-system-mysql`, `t17-mysql57-system-lenient`, `t17-tidb85-system-mysql-drop`, `t17-mysql80-cross-namespace`, `t17-cli-nameless-no-schema-mysql`, `t17-mysql80-custom-levels`, `t17-cli-custom-levels-mysql`, `*-all-disabled`.
- **AC3 tri-state & ordering**: `schemaPostAttrs` three-way; INE conditional convergence (`applyCreateSchema`); `applyDropSchema` descendant invalidation; recreate does not revive old facts; refused ops never mutate state; unknown condition → gap not guess. Cases: `t17-cli-unknown-state-mysql`, `t17-mysql80-drop-cascade`, `t17-mysql80-recreate`, `t17-cli-ine-*` (encryption-refused-5.7, version-unproven, placement-unvouchable arms), `t17-mysql80-tiflash-refused`, `t17-tidb85-tiflash-unproven`.
- **AC4 TiDB & placement boundary**: TiDB DATABASE/SCHEMA equivalence + charset/collation + encryption accepted-and-ignored (no attr published, `schemaPostAttrs` withhold path) + database-level `PLACEMENT POLICY` declarations preserved as parse facts but lifecycle deferred. `create_schema`/`alter_schema` placement → `UnsupportedUnauditedReason` on TiDB / `UnsupportedVendorBoundaryReason` on MySQL; table/partition placement keeps T20 modeling (unaccepted — not claimed). Cases: `t17-cli-tidb-placement-aspect`, `t17-cli-mysql-placement-vendor`, `t17-cli-ine-placement-tidb`, `t17-tidb85-placement-missing`, `t17-tidb85-encryption-ignored`, `t17-tidb85-charset-lifecycle`, `t17-tidb85-notices`, `t17-tidb85-nameless-alter`, `t17-tidb85-create-duplicate`, `t17-tidb85-tiflash-unproven`.
- **AC5 public contract**: statement kind/index/target, finding rule_id/level/location/multiplicity, coverage status, evidence gaps (rule_id/reason_code/required_facts), unsupported feature/reason/metadata, verdict, CLI exit codes, SDK/HTTP/MCP parity. Cases: all 52 + 4-case four-surface parity set.

## 3. Boundary explanations (contract-owned)

1. **Schema-level placement stays unaudited**: T20's committed code models policy bindings, but T20 is NOT independently accepted; T17 AC4 explicitly defers placement-policy lifecycle to T20. Reporting the declaration as `unaudited` is the honest incomplete-coverage contract (T03) — never silent pass. Table/partition bindings are untouched by this change (`statementCoverageAspects` skip remains for `CreateTable`/`AlterTable` only), so T20 behavior is unaffected — they simply remain *unclaimed* by T17.
2. **MySQL placement = vendor boundary**: `ALTER|CREATE DATABASE ... PLACEMENT POLICY` parses under MySQL but the feature is TiDB-only → `UnsupportedVendorBoundaryReason` (proven refusal, not an evidence gap).
3. **Namespace drop & recreate**: `applyDropSchema` invalidates the schema entry AND descendant table facts; recreate (`applyCreateSchema` on absent entry) mints a fresh entry — stale metadata/statistics never carry over. Verified by `t17-mysql80-drop-cascade` (drop→table access gap) and `t17-mysql80-recreate` (fresh charset gbk, no revival).
4. **Fact ownership T17 vs T20**: T17 owns schema existence/attrs/charset/collation/encryption/conditionals/namespace policy. T20 owns placement-policy object existence, member sets, binding effects — asserted only at table/partition level here, schema-level declarations preserved-but-unadjudicated.

## 4. Cross-task dependencies

- T05 (#84): `batchCreated`/ordered prospective state infrastructure — verified present (batch_state.go ordered pipeline, schema entry types).
- T16 (#95): table-lifecycle neighbor; `applyDropSchema` descendant invalidation composes with T16's table state.
- T20 (#99): UNACCEPTED — only the boundary carve-out is changed; its modeling untouched.
- T03 (#82): incomplete-coverage contract the placement aspect obeys.

## 5. Official-standard citations (R3 addition)

Precise upstream references for the versioned boundaries asserted above
(added under T17-R3 ER5; content unchanged — citations only).

### MySQL database-option version boundaries

- `ALTER DATABASE ... [DEFAULT] ENCRYPTION`: introduced in MySQL **8.0.16**.
  Source: MySQL 8.0 Reference Manual, "13.1.2 ALTER DATABASE Statement"
  (https://dev.mysql.com/doc/refman/8.0/en/alter-database.html —
  canonical URL; note dev.mysql.com returns HTTP 403 to non-browser
  agents at R4 check time — the URL itself is the official reference) —
  documents `DEFAULT ENCRYPTION` as of 8.0.16; WL#12098 "Schema-level
  encryption". DeltaScope contract: on MySQL < 8.0.16 (i.e. anchor 5.7.44
  and unproven-version arms), schema encryption is a **proven refusal**
  (vendor boundary → unsupported/refused option path), never silently
  accepted; verified by `t17-cli-ine-encryption-refused-5.7`.
- `CREATE|ALTER {DATABASE|SCHEMA}` charset/collation options: stable
  across 5.7.44/8.0.46/8.4.10. Source: MySQL 5.7 & 8.0 Reference Manual,
  "13.1.1 ALTER DATABASE" / "13.1.12 CREATE DATABASE".
- `CREATE DATABASE ... IF NOT EXISTS` / `DROP ... IF EXISTS`: conditional
  clauses official on all three anchors (same manual pages).

### TiDB 8.5 placement declaration

- `ALTER DATABASE <db> PLACEMENT POLICY [=] <policy>`: TiDB-vendor SQL,
  documented in TiDB v8.5 docs "Placement Rules in SQL"
  (https://docs.pingcap.com/tidb/v8.5/placement-rules-in-sql/ — verified
  HTTP 200 at R4) and "ALTER DATABASE Statement"
  (https://docs.pingcap.com/tidb/v8.5/sql-statement-alter-database/ —
  verified HTTP 200 at R4). Schema-level binding accepted by the TiDB
  parser, rejected as vendor boundary under MySQL dialects.
- ADR `docs/decisions/2026-11-12-tidb-placement-policy-lifecycle.md`
  records the repo-owned deferral of placement-policy lifecycle semantics.

### T17/T20 ownership boundary

- T17 owns: schema existence, charset/collation/encryption attributes,
  conditional clauses, system/denylist namespace policy, ordered state.
- T20 owns: placement-policy OBJECT lifecycle (policy existence, member
  sets, binding effects). Committed but NOT independently accepted at
  36e616f8. Consequence: schema-level placement declarations on TiDB are
  preserved as parse facts and reported `unaudited` (aspect=option);
  table/partition placement modeling is untouched and unclaimed by T17.
