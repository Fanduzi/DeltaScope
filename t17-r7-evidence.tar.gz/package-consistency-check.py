#!/usr/bin/env python3
"""T17-R4 sealed-package consistency check (fail-closed).

Explicit required-member inventory — does NOT depend on README regex
discovery. Fails rc=1 when:
  - any required member is absent;
  - manifest.txt exists but does not list a required member, or lists it
    with a sha/size mismatch;
  - payload-index.txt exists but does not cover a required member.

Run from anywhere; paths resolve relative to this file's directory.
"""
import hashlib, os, sys

ROOT = os.path.dirname(os.path.abspath(__file__))

CASES = ["disabled", "reject", "gap", "placement"]

REQUIRED = [
    "README.md", "manifest.txt", "payload-index.txt", "privacy-scan.txt",
    "reuse-ledger.txt", "package-consistency-check.py",
    "golden/artifact.json", "golden/matrix-t17.json", "golden/T17.json",
    "golden/oracle-T17.json", "golden/golden-run-36e616f8.log",
    "validator/validate_t17_r1.py", "validator/process_selftest_r1.py",
    "validator/process_selftest_r1.tsv",
    "validator/process_selftest_r1.jsonl",
    "validator/r3-validate-stdout.txt", "validator/r3-validate-stderr.txt",
    "parity/compare.py", "parity/tamper_r3.py", "parity/provenance-r3.md",
    "parity/r3/tamper-results.tsv",
    "parity/provenance-r4.md",
    "parity/r4/case-dual.sql", "parity/r4/policy-r4-dual.yaml",
    "parity/r4/binary-shas.txt",
    "parity/r4/baseline-compare-stdout.txt",
    "parity/r4/baseline-compare-stderr.txt",
    "parity/r4/baseline-compare-rc.txt",
    "parity/r4/cli/out-dual.json", "parity/r4/cli/err-dual.txt",
    "parity/r4/cli/rc-dual.txt",
    "parity/r4/sdk/out-dual.json", "parity/r4/sdk/err-dual.txt",
    "parity/r4/sdk/rc-dual.txt", "parity/r4/sdk/main.go",
    "parity/r4/sdk/probe-sha.txt",
    "parity/r4/http/request-body-dual.json",
    "parity/r4/http/response-dual.json",
    "parity/r4/http/response-headers.txt", "parity/r4/http/curl-rc.txt",
    "parity/r4/http/server.log",
    "parity/r4/mcp/dual/structured.json", "parity/r4/mcp/sent-call.json",
    "parity/r4/mcp/recv-call.json", "parity/r4/mcp/exit.txt",
    "parity/r4/tamper/pos-findings-order/stdout.txt",
    "parity/r4/tamper/pos-findings-order/stderr.txt",
    "parity/r4/tamper/pos-findings-order/rc.txt",
    "parity/r4/tamper/neg-owner-move/stdout.txt",
    "parity/r4/tamper/neg-owner-move/stderr.txt",
    "parity/r4/tamper/neg-owner-move/rc.txt",
    "parity/r4/tamper/neg-owner-move-crash-HISTORICAL/NOTE.txt",
    "parity/r4/tamper/neg-owner-move-crash-HISTORICAL/stderr.txt",
    "parity/r4/tamper/neg-statement-index-missing/stdout.txt",
    "parity/r4/tamper/neg-statement-index-missing/stderr.txt",
    "parity/r4/tamper/neg-statement-index-missing/rc.txt",
    "parity/r4/tamper/neg-finding-rule/stdout.txt",
    "parity/r4/tamper/neg-finding-rule/stderr.txt",
    "parity/r4/tamper/neg-finding-rule/rc.txt",
    "parity/r4/tamper/neg-finding-level/stdout.txt",
    "parity/r4/tamper/neg-finding-level/stderr.txt",
    "parity/r4/tamper/neg-finding-level/rc.txt",
    "parity/r4/tamper/neg-finding-location/stdout.txt",
    "parity/r4/tamper/neg-finding-location/stderr.txt",
    "parity/r4/tamper/neg-finding-location/rc.txt",
    "parity/r4/sdk/main.go", "parity/r4/sdk/main-go-sha.txt",
    "parity/r4/sdk/build-argv.txt", "parity/r4/sdk/build-stdout.txt",
    "parity/r4/sdk/build-stderr.txt", "parity/r4/sdk/build-rc.txt",
    "parity/r4/sdk/build-attempt1-err.txt",
    "parity/r4/sdk/build-attempt1-rc.txt",
    "parity/r4/sdk/build-record.txt", "parity/r4/sdk/probe-sha.txt",
    "parity/r4/sdk/exec-argv.txt", "parity/r4/sdk/sdkprobe-r4",
    "validator/failclosed-r4/argv-normal.txt",
    "validator/failclosed-r4/rc-normal.txt",
    "validator/failclosed-r4/stdout-normal.txt",
    "validator/failclosed-r4/stderr-normal.txt",
    "packagecheck-r4/run-controls.sh",
    "source/source-contract-map.md",
]
# parity four-surface inputs for every case
for c in CASES:
    REQUIRED += [
        f"parity/r2/cli/out-{c}.json", f"parity/r2/cli/err-{c}.txt",
        f"parity/r2/sdk/out-{c}.json",
        f"parity/r2/http/response-{c}.json",
        f"parity/r2/http/request-body-{c}.json",
        f"parity/r2/http/curl-rc-{c}.txt",
        f"parity/r2/mcp/{c}/structured.json",
        f"parity/r2/mcp/{c}/sent-call.json",
        f"parity/r2/mcp/{c}/recv-call.json",
        f"parity/r2/mcp/{c}/exit.txt",
    ]
# every selftest per-test output declared in the TSV
_tsv = os.path.join(ROOT, "validator/process_selftest_r1.tsv")
if os.path.isfile(_tsv):
    for ln in open(_tsv).read().splitlines()[1:]:
        cols = ln.split("\t")
        if len(cols) >= 11:
            for rel in (cols[9], cols[10]):
                rel = rel.strip()
                if not rel:
                    continue
                p = rel if rel.startswith("validator/") \
                    else ("validator/" + rel if rel.startswith("selftest-r1/")
                          else "validator/selftest-r1/" + rel)
                if p not in REQUIRED:
                    REQUIRED.append(p)
# parity tamper outputs declared in tamper-results.tsv
_tsv = os.path.join(ROOT, "parity/r3/tamper-results.tsv")
if os.path.isfile(_tsv):
    for ln in open(_tsv).read().splitlines()[1:]:
        cols = ln.split("\t")
        if cols:
            tag = cols[0]
            for kind in ("stdout", "stderr"):
                p = f"parity/r3/{kind}-{tag}.txt"
                if p not in REQUIRED:
                    REQUIRED.append(p)


REQUIRED = list(dict.fromkeys(REQUIRED))  # unique members only


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def emit_required_inventory():
    """Write required-members.txt: sorted unique REQUIRED paths that
    exist, with sha256 — a reviewable generated artifact."""
    out = []
    for p in sorted(set(REQUIRED)):
        full = os.path.join(ROOT, p)
        if os.path.isfile(full):
            out.append(f"{sha(full)}  {os.path.getsize(full)}  {p}")
    return out


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--emit-required":
        for ln in emit_required_inventory():
            print(ln)
        return 0
    missing = [p for p in REQUIRED
               if not os.path.isfile(os.path.join(ROOT, p))]
    # manifest binding: every required member must be listed with
    # matching sha+size (manifest itself excepted — self-excluded)
    merrs = []
    mp = os.path.join(ROOT, "manifest.txt")
    if os.path.isfile(mp):
        rows = {}
        for ln in open(mp):
            parts = ln.split()
            if len(parts) >= 3:
                rows[" ".join(parts[2:])] = (parts[0], int(parts[1]))
        for p in REQUIRED:
            if p == "manifest.txt":
                continue
            full = os.path.join(ROOT, p)
            if p not in rows:
                merrs.append(f"manifest does not list required: {p}")
            elif os.path.isfile(full):
                s, z = rows[p]
                if sha(full) != s or os.path.getsize(full) != z:
                    merrs.append(f"manifest sha/size mismatch: {p}")
    else:
        merrs.append("manifest.txt absent")
    # payload-index coverage (self-excluded; manifest may be absent from it)
    ierrs = []
    ip = os.path.join(ROOT, "payload-index.txt")
    if os.path.isfile(ip):
        irows = set(ln.split()[-1] for ln in open(ip) if ln.strip())
        for p in REQUIRED:
            if p in ("payload-index.txt", "manifest.txt"):
                continue
            if p not in irows:
                ierrs.append(f"payload-index does not cover required: {p}")
    else:
        ierrs.append("payload-index.txt absent")

    errs = ([f"missing: {p}" for p in missing] + merrs + ierrs)
    for e in errs:
        print("FAIL", e)
    print(f"package consistency: {len(REQUIRED)} required members checked; "
          f"{len(errs)} failures")
    return 1 if errs else 0


if __name__ == "__main__":
    sys.exit(main())
