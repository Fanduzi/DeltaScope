#!/usr/bin/env python3
"""T17-R3 formal tamper runner — invokes compare.py as a real subprocess.

Each control builds a tampered copy of the r2 parity tree, mutates ONE
surface file, then runs `python3 compare.py <dir>` recording argv, rc,
stdout, stderr. Negatives must exit nonzero (DIFF detected); positives
must exit 0.

Usage: python3 tamper_r3.py   (run from /tmp/t17-r1/parity; tree at r2/)
"""
import json, os, shutil, subprocess, sys, copy

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "r2")
CMP = os.path.join(HERE, "compare.py")
OUT = os.path.join(HERE, "tamper-r3")
TSV = os.path.join(OUT, "results.tsv")
os.makedirs(OUT, exist_ok=True)
rows = []


def build_tree(tag, mutate):
    dst = os.path.join(OUT, tag)
    if os.path.exists(dst):
        shutil.rmtree(dst)
    shutil.copytree(SRC, dst,
                    ignore=shutil.ignore_patterns("tamper-r3", "*.pyc",
                                                  "__pycache__"))
    desc = mutate(dst)
    return dst, desc


def run(tag, mutate, expect_nonzero):
    dst, desc = build_tree(tag, mutate)
    p = subprocess.run([sys.executable, CMP, dst],
                       capture_output=True, text=True)
    open(os.path.join(OUT, f"stdout-{tag}.txt"), "w").write(p.stdout)
    open(os.path.join(OUT, f"stderr-{tag}.txt"), "w").write(p.stderr)
    ok = (p.returncode != 0) if expect_nonzero else (p.returncode == 0)
    rows.append((tag, desc, f"rc={p.returncode}", "PASS" if ok else "FAIL"))
    print(tag, "|", desc, "| rc=", p.returncode, "|", "PASS" if ok else "FAIL")
    return ok


def edit_json(path, fn):
    d = json.load(open(path))
    fn(d)
    json.dump(d, open(path, "w"))


ok = True

# --- ER2 diagnostic-field negatives (each alone must DIFF) ---
def m_diag(field, val):
    def m(dst):
        p = os.path.join(dst, "cli/out-placement.json")
        def f(d):
            old = d["diagnostics"][0][field]
            d["diagnostics"][0][field] = val(old) if callable(val) else val
            return f"diagnostics[0].{field}: {old!r} -> {d['diagnostics'][0][field]!r}"
        desc_holder = {}
        d = json.load(open(p))
        old = d["diagnostics"][0][field]
        d["diagnostics"][0][field] = val(old) if callable(val) else val
        json.dump(d, open(p, "w"))
        return f"diagnostics[0].{field}: {old!r} -> {d['diagnostics'][0][field]!r}"
    return m

ok &= run("neg-diag-classification", m_diag("classification", "tampered_class"), True)
ok &= run("neg-diag-reason", m_diag("reason", "tampered reason text"), True)
ok &= run("neg-diag-action-hint", m_diag("action_hint", "tampered hint"), True)
ok &= run("neg-diag-dialect", m_diag("dialect", "mysql"), True)

# --- ER3 finding owner-only move: keep statement_index/rule/level/location ---
def m_owner(dst):
    p = os.path.join(dst, "cli/out-reject.json")
    d = json.load(open(p))
    f = d["statements"][1]["findings"].pop(0)   # keep ALL fields intact
    d["statements"][2].setdefault("findings", []).append(f)
    json.dump(d, open(p, "w"))
    return "finding moved stmt1->stmt2, internal fields unchanged"
ok &= run("neg-finding-owner-only", m_owner, True)

# --- existing field negatives kept ---
def m_rule(dst):
    p = os.path.join(dst, "sdk/out-reject.json")
    d = json.load(open(p))
    f = d["result"]["statements"][1]["findings"][0]
    old = f["rule_id"]; f["rule_id"] = "tampered.rule"
    json.dump(d, open(p, "w"))
    return f"finding rule_id {old}->tampered.rule"
ok &= run("neg-finding-rule", m_rule, True)

def m_level(dst):
    p = os.path.join(dst, "http/response-reject.json")
    d = json.load(open(p))
    r = d.get("result") or d
    f = r["statements"][1]["findings"][0]
    old = f["level"]; f["level"] = "notice"
    json.dump(d, open(p, "w"))
    return f"finding level {old}->notice"
ok &= run("neg-finding-level", m_level, True)

def m_loc(dst):
    p = os.path.join(dst, "mcp/reject/structured.json")
    d = json.load(open(p))
    f = d["statements"][1]["findings"][0]
    old = f["location"]["column"]; f["location"]["column"] = 999
    json.dump(d, open(p, "w"))
    return f"finding location.column {old}->999"
ok &= run("neg-finding-location", m_loc, True)

# --- gap/unsupported negatives (kept from R2) ---
def m_gap_reason(dst):
    p = os.path.join(dst, "cli/out-gap.json")
    d = json.load(open(p))
    g = d["statements"][0]["evidence_gaps"][0]
    old = g["reason_code"]; g["reason_code"] = "tampered_reason"
    json.dump(d, open(p, "w"))
    return f"gap reason_code {old}->tampered_reason"
ok &= run("neg-gap-reason", m_gap_reason, True)

def m_uns_meta(dst):
    p = os.path.join(dst, "mcp/placement/structured.json")
    d = json.load(open(p))
    u = d["unsupported"][0]
    old = u["metadata"]["aspect"]; u["metadata"]["aspect"] = "tampered"
    json.dump(d, open(p, "w"))
    return f"unsupported.metadata.aspect {old}->tampered"
ok &= run("neg-uns-metadata", m_uns_meta, True)

# --- positives ---
def m_keyperm(dst):
    # real key-order permutation: rewrite every JSON object with keys reversed
    for surf_file in ["cli/out-gap.json", "sdk/out-gap.json",
                      "http/response-gap.json", "mcp/gap/structured.json"]:
        p = os.path.join(dst, surf_file)
        d = json.load(open(p))
        def rev(o):
            if isinstance(o, dict):
                return {k: rev(v) for k, v in reversed(list(o.items()))}
            if isinstance(o, list):
                return [rev(x) for x in o]
            return o
        json.dump(rev(d), open(p, "w"))
    return "key-order reversed in ALL surfaces (bytes differ, semantics same)"
ok &= run("pos-key-order", m_keyperm, False)

def m_findperm(dst):
    # same-statement finding order permutation on a statement with >=2 findings:
    # build by duplicating within the same statement? NO — pick stmt with 1 finding
    # in reject and duplicate? that changes multiplicity. Instead: permute the
    # top-level statements array order? That changes indices? statements carry
    # their own index field — comparator reads s['index'], so permuting the
    # statements array itself is a legal order permutation.
    for surf_file in ["cli/out-reject.json", "sdk/out-reject.json",
                      "http/response-reject.json", "mcp/reject/structured.json"]:
        p = os.path.join(dst, surf_file)
        d = json.load(open(p))
        r = d.get("result") or d
        r["statements"] = list(reversed(r["statements"]))
        json.dump(d, open(p, "w"))
    return "statements array reversed in ALL surfaces (order-insensitive stmt multiset)"
ok &= run("pos-stmt-order", m_findperm, False)

with open(TSV, "w") as fh:
    fh.write("test\tdescription\trc\tresult\n")
    for r in rows:
        fh.write("\t".join(r) + "\n")
neg = sum(1 for r in rows if r[0].startswith("neg") and r[3] == "PASS")
pos = sum(1 for r in rows if r[0].startswith("pos") and r[3] == "PASS")
print(f"denominators: negative {neg}/10 nonzero+DIFF; positive {pos}/2 rc=0")
sys.exit(0 if ok else 1)
