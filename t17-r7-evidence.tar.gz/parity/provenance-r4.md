# T17-R4 execution provenance — reconciliation + fresh probe

This document supersedes parity/provenance-r3.md for invocation facts.
R3's claims contained three errors corrected here:

1. CLI flags: the REAL flags are `--file` and `--config`
   (`deltascope audit -h` output, `internal/interfaces/cli` flag
   definitions), not the `--sql-file`/`--policy` written in R3.
   The R3 doc had copied a contract-map shorthand into the argv field.
2. CLI SQL inputs: `parity/cli/case-<c>.sql` does not exist in this
   package. The actual SQL strings are embedded in `mcp/<c>/sent-call.json`
   `params.arguments.sql` and `http/request-body-<c>.json`; the R1-era
   files live under `reused/r1-parity/cli/case-<c>.sql`.
3. HTTP flag: the real flag is `-listen`, not `--addr` — captured in
   `r4/http/server-attempt1-fail.log` (flag error) vs the successful
   `server.log` run.

## A. R4 fresh dual-finding probe (RERUN — not historical R2)

Purpose: the required same-statement multi-finding baseline.
SQL input: `parity/r4/case-dual.sql`
  sha256 17c5701eafff6fd8ed391af92696c4d31970ca04fa87dc434c56dc5fe9ad7f73
  content: `DROP DATABASE mysql; ALTER SCHEMA mysql CHARACTER SET utf8mb4;`
Policy input: `parity/r4/policy-r4-dual.yaml`
  sha256 65d8dd94de40b1ae703ab173052b39739796bb913657bd2d6c52f6d8b5c64d72
  derivation: golden-policy-t17-schema-lifecycle.yaml with
  `rules["ddl.database.denylist.forbid"].params = {schemas: ["mysql"]}`
  — deterministic single-key delta; sealed verbatim.
Dialect: mysql. Expected: each statement yields TWO DISTINCT findings
(ddl.database.denylist.forbid + ddl.database.system.modify.forbid).

Binaries (SHA-256, `parity/r4/binary-shas.txt`):
- deltascope (CLI):        bb8d0a875a4f802fd5cdf63c848c603298cd0c53d5e1765039d9b36e01996079
- deltascope-server:       634585e26605391e86aa301f1ba991b612c29de4917c5c852480fbc6f041ba30
- deltascope-mcp:          88bb0705b77134c57a17ca624d3df02a43d2a68a737d94a2912e06351f3c4ba7
  — all three built from frozen tree at HEAD 36e616f8 during R2;
    REUSED binaries, FRESH R4 executions.
- sdkprobe-r4 (SDK helper, SEALED in this archive):
    sha256 93603f42a4e28dca5f4c9561747af54c7b669a4ed0984efc94fd4f61c2856cf5
    size 30,314,066 bytes — AUTHORITATIVE R5/R6 identity; produced the
    sealed sdk/out-dual.json (exec argv in sdk/exec-argv.txt, rc=0).
    Three-attempt history in sdk/build-record.txt (attempt-1 rc=1
    HISTORICAL; attempt-2 binary sha 0b1d5f9d… produced a superseded
    out-dual.json — NOT the authoritative output; attempt-3 =
    authoritative). Go link output is not byte-reproducible; declared.
    The R1-built probe remains labelled REUSED-historical only.

### Per-surface invocations

CLI  — `bin/deltascope audit --file case-dual.sql --dialect mysql
        --config policy-r4-dual.yaml --format json`
       rc=1 (reject; cli/rc-dual.txt), stdout→cli/out-dual.json,
       stderr→cli/err-dual.txt.
SDK  — `./sdkprobe-r4 dual case-dual.sql mysql policy-r4-dual.yaml`
       rc=0, stdout→sdk/out-dual.json, stderr→sdk/err-dual.txt.
HTTP — `deltascope-server -listen 127.0.0.1:18401 -config policy-r4-dual.yaml`
       then `curl -H 'X-Request-Id: req-t17r4-dual' --data-binary
       @request-body-dual.json http://127.0.0.1:18401/v1/audit`
       → http_code=200 curl_rc=0 (curl-rc.txt), response-headers.txt,
       response-dual.json, server.log.
MCP  — `deltascope-mcp` stdio JSON-RPC; frames sent-init/recv-init/
       sent-initialized/sent-call/recv-call archived verbatim;
       `tools/call audit_sql` with `config_path`=<abs policy path>;
       structuredContent→mcp/dual/structured.json; exit=0 (exit.txt).

All four surfaces: verdict `reject`, 2 findings in statement 0 and
2 in statement 1 — baseline comparator run (argv, rc, stdout/stderr):
`python3 parity/compare.py parity/r4 dual dual` → rc=0, PARITY: PASS.

Comparator correction (R4 follow-up): the R3 comparator crashed
(TypeError) sorting finding tuples that mix `statement_index: null`
with integers — neg-owner-move's earlier rc=1 was an exception exit,
not a DIFF verdict. compare.py now normalises every tuple element via
`_n()` (None/bool/int/str tagged sentinels) before sorting; ALL
controls were rerun: owner-move now emits a real `== dual: DIFF`,
10/10 negatives DIFF, positives rc=0, and per-control stderrs contain
zero tracebacks.

## B. Historical R2 parity set (REUSED — label preserved)

`parity/r2/` four-surface outputs are REUSED R2 executions on the same
frozen-HEAD binaries (SHAs above). Historical invocation detail for R2
runs is reconstructed evidence, NOT captured-at-runtime argv; where
exact historical argv was not archived, this is declared a gap rather
than re-written as fact. The comparator does not depend on argv —
it compares sealed output bytes (SHAs in manifest).

## C. R4 tamper controls (formal subprocess runs)

- `tamper/pos-findings-order/` — reversed findings array inside
  statement 0 on the CLI surface ONLY (all fields/multiplicities
  unchanged) → compare.py rc=0, PARITY: PASS. This is the REQUIRED
  same-statement findings-permutation positive.
- `tamper/neg-owner-move/` — one finding moved stmt0→stmt1 on the SDK
  surface with ALL internal fields unchanged → rc=1, DIFF.
- Historical `pos-stmt-order`/`pos-key-order` (R3) retained under
  parity/r3/ labelled top-level permutations — they are NOT claimed
  as the findings-order control.

## D. R4 baseline record

- argv: `python3 parity/compare.py parity/r4 dual dual`
- rc=0; complete stdout/stderr: `parity/r4/baseline-compare-stdout.txt`,
  `parity/r4/baseline-compare-stderr.txt`.
- input member SHAs: manifest.txt covers every r4/ input file.
