import json, subprocess, sys, threading, queue, hashlib, os

BIN = "/Users/fan/GolangProjects/DeltaScope/bin/deltascope-mcp"
name, port_sql, dialect, config = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
sql = open(port_sql).read()
os.makedirs(name, exist_ok=True)

proc = subprocess.Popen([BIN], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)
q = queue.Queue()
def reader():
    for line in proc.stdout:
        q.put(line)
threading.Thread(target=reader, daemon=True).start()

def send(obj, tag):
    line = json.dumps(obj)
    proc.stdin.write(line + "\n"); proc.stdin.flush()
    open(f"{name}/sent-{tag}.json", "w").write(line + "\n")

def recv(tag, timeout=15, want_id=None):
    lines = []
    while True:
        line = q.get(timeout=timeout)
        lines.append(line)
        obj = json.loads(line)
        if want_id is None or obj.get("id") == want_id:
            break
    open(f"{name}/recv-{tag}.json", "w").write("".join(lines))
    return obj

send({"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"t17-parity","version":"1.0"}}}, "init")
init_resp = recv("init", want_id=1)
send({"jsonrpc":"2.0","method":"notifications/initialized"}, "initialized")
send({"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"audit_sql","arguments":{"sql":sql,"dialect":dialect,"config_path":config}}}, "call")
call_resp = recv("call", want_id=2)
proc.stdin.close(); proc.wait(timeout=10)
err = proc.stderr.read()
open(f"{name}/stderr.log","w").write(err)
open(f"{name}/exit.txt","w").write(f"rc={proc.returncode}")
# extract structuredContent
sc = ((call_resp.get("result") or {}).get("structuredContent")) or {}
open(f"{name}/structured.json","w").write(json.dumps(sc, indent=1, sort_keys=True))
sts = sc.get("statements", [])
fs = [(f.get("rule_id"), f.get("level"), f.get("statement_index"), (f.get("location") or {}).get("column")) for s in sts for f in s.get("findings", [])]
cov = sc.get("coverage") or {}
print(name, "| verdict:", sc.get("verdict"), "| cov:", cov.get("status") if isinstance(cov, dict) else cov, "| find:", fs, "| uns:", [(u.get("feature"), u.get("index")) for u in sc.get("unsupported", [])], "| rc:", proc.returncode)
