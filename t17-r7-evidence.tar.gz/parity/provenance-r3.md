# T17-R3 four-surface execution provenance

All r2/ outputs were produced by binaries built from the frozen tree
(HEAD 36e616f8a75246cb56e7872823720c109f20b3a6) during the R2 round;
rerun status for R3: REUSED OUTPUT, comparator R3 FRESH.

## Binaries (SHA-256)

- deltascope (CLI):        bb8d0a875a4f802fd5cdf63c848c603298cd0c53d5e1765039d9b36e01996079
- deltascope-server (HTTP): 634585e26605391e86aa301f1ba991b612c29de4917c5c852480fbc6f041ba30
- deltascope-mcp (MCP):    88bb0705b77134c57a17ca624d3df02a43d2a68a737d94a2912e06351f3c4ba7
- sdkprobe (SDK helper):   0675e8edc621951ddeb09e2a4a3a22f8ca80ded82ebb08fb068c3db1c2e0a59a
  — SDK PROBE BINARY IS R1-REUSED: compiled in R1 from
    `go run` of a probe importing pkg/deltascope at the same frozen
    tree; the R2 executions were FRESH process invocations of that
    R1-built binary. R3 makes no claim the probe was rebuilt.

## Policies (SHA-256)

- golden-policy-t17-schema-lifecycle.yaml (reject/gap/placement):
  75ad03e77dd51132854972574aa49158f297919f313917237c088dad0cb1d0e5
- golden-policy-all-off.yaml (disabled case):
  9694d65aaa0d72f885cba5a40e82068b432e5beb943c598a83ce87110e3c48fa
- both under /tmp/ddl-golden-t17/T17/ at execution time; exact paths
  recorded in MCP sent-call.json `config_path` and CLI argv logs.

## Per-surface invocation (r2/ tree)

### CLI — parity/r2/cli/
argv per case: `bin/deltascope audit --sql-file case-<c>.sql --dialect <d> --policy <policy> --format json`
request identity: case SQL files in parity/cli/case-<c>.sql (pre-commit
copies, byte-identical to r2 runs); stdout → out-<c>.json; stderr → err-<c>.txt
process rc: recorded per run in R1 log; outputs byte-verified identical
to top-level parity/cli copies (sha256 filecmp 12/12 match).

### SDK — parity/r2/sdk/
argv: `go run` probe → pkg/deltascope.Audit(ctx, Request{SQL, Dialect, Config})
request: same case SQL strings; stdout JSON result object → out-<c>.json.
Binary provenance caveat: see "sdkprobe" above (R1 binary, fresh exec).

### HTTP — parity/r2/http/
three instances: `bin/deltascope-server --addr 127.0.0.1:1830{1,2,3} --policy <p>`
request: POST /v1/audit, body archived as request-body-<c>.json;
response-body → response-<c>.json; curl exit → curl-rc-<c>.txt.
transport status: HTTP 200 for reject/gap; placement required corrected
request shape (initial 400 documented in R1 log; final run 200).

### MCP — parity/r2/mcp/<case>/
argv: `bin/deltascope-mcp` stdio JSON-RPC; frames sent-* / recv-*
archived verbatim; call params carry `config_path` =
/tmp/ddl-golden-t17/T17/golden-policy-t17-schema-lifecycle.yaml
(sha 75ad03e7…); structuredContent extracted → structured.json;
process exit → exit.txt; stderr → stderr.log.

## Request/output SHA identity

- request bodies: parity/r2/http/request-body-<c>.json sealed verbatim.
- outputs: every out-/response-/structured.json sealed; their
  sha256 appear in manifest.txt.
