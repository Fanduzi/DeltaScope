import json, os, copy, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
import compare

"""ER2 negative controls: tamper ONE surface's stored output, run the
comparator's per-surface tuples directly (subprocess-independent — the
comparator is imported and its tup() applied to the tampered data).
Each control must produce a DIFF vs the untampered surfaces."""

OUT = "tamper-results.tsv"
rows = []

def load(surf, case):
    if surf == "cli":   return json.load(open(f"cli/out-{case}.json"))
    if surf == "sdk":   return json.load(open(f"sdk/out-{case}.json"))["result"]
    if surf == "http":
        d = json.load(open(f"http/response-{case}.json")); return d.get("result") or d
    if surf == "mcp":   return json.load(open(f"mcp/{case}/structured.json"))

def others(surf, case):
    return {s: compare.tup(load(s, case)) for s in ["cli","sdk","http","mcp"] if s != surf}

def check(name, surf, case, mutate):
    d = copy.deepcopy(load(surf, case))
    desc = mutate(d)
    tampered = compare.tup(d)
    rest = others(surf, case)
    diff = all(tampered != v for v in rest.values())
    rows.append((name, surf, case, desc, "DIFF" if diff else "NO-DIFF-FAIL"))
    print(name, surf, desc, "->", "DIFF" if diff else "NO-DIFF-FAIL")
    return diff

ok = True

# 1. modify one gap's reason_code (gap case, cli)
def m1(d):
    g = d["statements"][0]["evidence_gaps"][0]
    old = g["reason_code"]; g["reason_code"] = "tampered_reason"
    return f"gaps[0].reason_code {old}->{g['reason_code']}"
ok &= check("neg-reason-code", "cli", "gap", m1)

# 2. modify required_facts (gap case, sdk)
def m2(d):
    g = d["statements"][0]["evidence_gaps"][0]
    old = list(g["required_facts"]); g["required_facts"] = ["fabricated.fact"]
    return f"gaps[0].required_facts {old}->{g['required_facts']}"
ok &= check("neg-required-facts", "sdk", "gap", m2)

# 3. move a gap to another statement (gap case, http)
def m3(d):
    g = d["statements"][0]["evidence_gaps"].pop(0)
    d["statements"][1]["evidence_gaps"].append(g)
    return "gap stmt0 -> stmt1"
ok &= check("neg-gap-owner-move", "http", "gap", m3)

# 4. modify unsupported.metadata.aspect (placement case, mcp)
def m4(d):
    u = d["unsupported"][0]
    old = u["metadata"]["aspect"]; u["metadata"]["aspect"] = "tampered"
    return f"unsupported.metadata.aspect {old}->tampered"
ok &= check("neg-uns-metadata", "mcp", "placement", m4)

# 5. move a finding to another statement + change location (reject case, cli)
def m5(d):
    f = d["statements"][1]["findings"].pop(0)
    f["statement_index"] = 2
    f["location"]["column"] = 999
    d["statements"][2].setdefault("findings", []).append(f)
    return "finding stmt1 col36 -> stmt2 col999"
ok &= check("neg-finding-move", "cli", "reject", m5)

# 6. positive control: key-order permutation of untouched data must stay IDENTICAL
d = load("cli", "gap")
perm = json.loads(json.dumps(d))  # deep copy, same content
okp = compare.tup(perm) == compare.tup(d)
rows.append(("pos-identity", "cli", "gap", "untouched re-serialization", "IDENTICAL" if okp else "FAIL"))
print("pos-identity ->", "IDENTICAL" if okp else "FAIL")

with open(OUT, "w") as fh:
    for r in rows:
        fh.write("\t".join(str(x) for x in r) + "\n")
print("tamper denominators: negative-diff", sum(1 for r in rows if r[0].startswith('neg') and r[4]=='DIFF'), "/5",
      "; positive", "1/1" if okp else "0/1")
sys.exit(0 if ok and okp else 1)
