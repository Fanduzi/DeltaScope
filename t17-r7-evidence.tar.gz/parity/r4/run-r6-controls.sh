#!/bin/bash
# T17-R6 parity control replay — deterministic mutations + compare.
# Run from the package root:  bash parity/r4/run-r6-controls.sh
# Each control copies parity/r4/{cli,sdk,http,mcp} into a fresh
# parity/r4/tamper/<name>/ tree, applies the recorded mutation, then
# invokes the sealed comparator as a subprocess. argv/rc/stdout/stderr
# land inside each control dir. Gate summary → tamper/gate-summary.txt.
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
CMP_SHA=$(shasum -a 256 parity/compare.py | cut -d' ' -f1)
echo "compare.py sha256 under test: $CMP_SHA" > parity/r4/compare-sha.txt
SRC_DIRS="cli sdk http mcp"

mk_tree() {  # $1=name
  d="parity/r4/tamper/$1"
  rm -rf "$d"; mkdir -p "$d"
  for s in $SRC_DIRS; do
    mkdir -p "$d/$s"
    # copy only comparator inputs (JSON outputs / frames), not binaries
    (cd "parity/r4/$s" && find . -type f ! -name 'sdkprobe*' ! -name '*.go' | while read f; do
       mkdir -p "$OLDPWD/$d/$s/$(dirname "$f")"; cp "$f" "$OLDPWD/$d/$s/$f"; done)
  done
}

run() {      # $1=name $2=expect(pass|fail)
  d="parity/r4/tamper/$1"
  printf 'argv: python3 parity/compare.py %s dual dual\n' "$d" > "$d/argv.txt"
  python3 parity/compare.py "$d" dual dual > "$d/stdout.txt" 2> "$d/stderr.txt"
  echo "rc=$?" > "$d/rc.txt"
  echo "expected=$2" >> "$d/rc.txt"
}

# --- baseline (no mutation) ---
mk_tree baseline
run baseline pass

# --- pos: reverse findings order inside statement 0, ONE surface ---
mk_tree pos-findings-order
python3 - <<'PY'
import json
p='parity/r4/tamper/pos-findings-order/cli/out-dual.json'
d=json.load(open(p))
d['statements'][0]['findings']=list(reversed(d['statements'][0]['findings']))
json.dump(d,open(p,'w'))
PY
printf 'mutation: statements[0].findings reversed; all fields untouched; surface=cli\n' > parity/r4/tamper/pos-findings-order/mutation.txt
run pos-findings-order pass

# --- neg: move one finding stmt0->stmt1, all fields unchanged ---
mk_tree neg-owner-move
python3 - <<'PY'
import json
p='parity/r4/tamper/neg-owner-move/sdk/out-dual.json'
d=json.load(open(p))
f=d['result']['statements'][0]['findings'].pop(0)
d['result']['statements'][1].setdefault('findings',[]).append(f)
json.dump(d,open(p,'w'))
PY
printf 'mutation: findings[0] moved stmt0->stmt1; ALL internal fields unchanged; surface=sdk\n' > parity/r4/tamper/neg-owner-move/mutation.txt
run neg-owner-move fail

# --- neg: drop statement_index from a stmt1 finding ---
mk_tree neg-statement-index-missing
python3 - <<'PY'
import json
p='parity/r4/tamper/neg-statement-index-missing/cli/out-dual.json'
d=json.load(open(p))
d['statements'][1]['findings'][0].pop('statement_index',None)
json.dump(d,open(p,'w'))
PY
printf 'mutation: statements[1].findings[0].statement_index removed; surface=cli\n' > parity/r4/tamper/neg-statement-index-missing/mutation.txt
run neg-statement-index-missing fail

# --- neg: rule_id change ---
mk_tree neg-finding-rule
python3 - <<'PY'
import json
p='parity/r4/tamper/neg-finding-rule/cli/out-dual.json'
d=json.load(open(p))
d['statements'][0]['findings'][0]['rule_id']='tampered.rule'
json.dump(d,open(p,'w'))
PY
printf 'mutation: stmt0 findings[0].rule_id -> tampered.rule; surface=cli\n' > parity/r4/tamper/neg-finding-rule/mutation.txt
run neg-finding-rule fail

# --- neg: level change ---
mk_tree neg-finding-level
python3 - <<'PY'
import json
p='parity/r4/tamper/neg-finding-level/http/response-dual.json'
d=json.load(open(p))
r=d.get('result') or d
r['statements'][0]['findings'][0]['level']='notice'
json.dump(d,open(p,'w'))
PY
printf 'mutation: stmt0 findings[0].level blocker->notice; surface=http\n' > parity/r4/tamper/neg-finding-level/mutation.txt
run neg-finding-level fail

# --- neg: location change ---
mk_tree neg-finding-location
python3 - <<'PY'
import json
p='parity/r4/tamper/neg-finding-location/mcp/dual/structured.json'
d=json.load(open(p))
d['statements'][1]['findings'][0]['location']['column']=999
json.dump(d,open(p,'w'))
PY
printf 'mutation: stmt1 findings[0].location.column ->999; surface=mcp\n' > parity/r4/tamper/neg-finding-location/mutation.txt
run neg-finding-location fail

# --- consistency gate ---
{
  echo "compare.py sha256: $CMP_SHA"
  echo
  ok=1
  for t in baseline pos-findings-order neg-owner-move neg-statement-index-missing neg-finding-rule neg-finding-level neg-finding-location; do
    d="parity/r4/tamper/$t"
    so="$d/stdout.txt"; se="$d/stderr.txt"
    tb=$(grep -c Traceback "$se" 2>/dev/null)
    if [[ "$t" == pos-* || "$t" == baseline ]]; then
      grep -q 'PARITY: PASS' "$so" && [[ "$tb" == 0 ]] && st=PASS || { st=FAIL; ok=0; }
    else
      grep -q 'DIFF' "$so" && grep -q 'PARITY: FAIL' "$so" && [[ "$tb" == 0 ]] && st=PASS || { st=FAIL; ok=0; }
    fi
    echo "$t rc=$(cat $d/rc.txt | head -1) gate=$st tracebacks=$tb"
  done
  echo
  echo "GATE: $([ $ok == 1 ] && echo ALL-CONTROLS-PASS || echo FAILURES)"
  echo "HISTORICAL crash (neg-owner-move-crash-HISTORICAL) excluded from"
  echo "current-control accounting by directory convention."
} | tee parity/r4/tamper/gate-summary.txt
