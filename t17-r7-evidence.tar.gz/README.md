# T17/#96 — R7 Evidence Package

Work order: `T17-R7-METADATA-CYCLE-BREAK-AND-FINAL-SEAL-01`.
Executor: Devin CLI / SWE-2 Max (authorised under T17).

## Frozen identity (unchanged product)

- HEAD `36e616f8a75246cb56e7872823720c109f20b3a6`
- tree `27ba38dc51266b279b5cc20c282a06d43d5e69dc`
- parent `c889fb0c82be2f67e9a3cf5c35064264ba91fe78`
- No product code, oracle, golden case set, or shipped policy changed —
  R7 is evidence-metadata-only.

## Prior rounds (immutable)

- R1 `5f5ada3c…`, R1.1 `489932b6…`, R2 `9e113a49…`, R3 `21988816…`,
  R4 `2327aab5…`, R5 `b4dfa24c…`, R6 `fc4cbe81…` all preserved; R7 is
  a NEW archive. Lineage in `reuse-ledger.txt`.

## R6 ruling → R7 corrections

R6 verdict: TECHNICAL PASS / ARCHIVE METADATA HOLD. Single defect:
`packagecheck-r4/required-members.txt` recorded sha+size rows that
disagreed with the final sealed members for `manifest.txt`,
`payload-index.txt` and `reuse-ledger.txt` — a circular verification
dependency (required-members records their hashes; they record
required-members' hash).

| R6 finding | R7 correction |
|---|---|
| required-members.txt carried stale sha+size for 3 self-referential members | File rewritten as a **pure path-only list** — 185 unique, sorted, no blanks. All member sha/size are attested solely by `manifest.txt` and `payload-index.txt`; required-members.txt itself is covered by both. Cycle removed by construction, not fixed-point iteration. |
| Path-set equality needed an independent proof | `packagecheck-r4/required-pathset-proof.txt` — REQUIRED extracted by module import/exec (source of truth) vs sealed list: `PATHSET-EQUAL` (185 = 185, zero diff both directions). |
| README/ledger stale counts and round mixing | Current unique REQUIRED denominator is **185** (supersedes earlier 156/187 figures). R6 parity controls (2 PASS + 5 DIFF) and package controls (6 isolated deletions) are reviewer-verified and retained as REUSED-R6. |
| SDK identity | Authoritative helper `parity/r4/sdk/sdkprobe-r4` sha `93603f42a4e2…`, size **30,314,066 B**; `0b1d5f9d…` is HISTORICAL attempt-2 only. |

## Verified technical proof retained from R6 (REUSED, not rerun)

- `parity/r4/` seven controls via `run-r6-controls.sh`: baseline rc=0
  `PARITY: PASS`, same-statement findings-order rc=0 `PARITY: PASS`,
  owner-move / statement_index-missing / rule / level / location each
  rc=1 real `DIFF` + `PARITY: FAIL`, zero tracebacks; crash preserved
  only under `tamper/neg-owner-move-crash-HISTORICAL/`. Comparator sha
  recorded in `parity/r4/compare-sha.txt`; gate summary
  `ALL-CONTROLS-PASS`.
- `packagecheck-r4/` six isolated deletion controls: identical checker
  sha (`c170f59d…`), 185-member clean baselines rc=0 → single deletion
  rc=1, failures exclusively deletion-attributed.
- `validator/` fail-closed validator + 5 failclosed controls + selftest
  19/19 negatives + 1/1 positive; sealed-tree rerun rc=0,
  `verify: 0 mismatches`.
- SDK: `parity/r4/sdk/sdkprobe-r4` sha `93603f42…` 30,314,066 B; build rc=0 in
  module context; execution rc=0; four-surface semantic parity.
- Golden 52/52 · 852 assertions @36e616f8; six gates +
  decision-record-gate rc=0; four-version native records; T08–T16
  regressions — all REUSED, not rerun.

## Contents

- `golden/` artifact + matrix + oracle (both names) + run log.
- `validator/` fail-closed validator + selftest suite + failclosed-r4/.
- `parity/` compare.py, r2/ four-surface outputs (REUSED), r3/ records,
  r4/ dual-finding probe + seven replayed controls, provenance docs.
- `packagecheck-r4/` checker controls + **path-only**
  `required-members.txt` (185) + `required-pathset-proof.txt` +
  `checker-sha.txt` + final `baseline-stdout.txt`.
- `gates/`, `regress/`, `reused/`, `source/` (contract map).
- `manifest.txt` (sha+size, self-excluded), `payload-index.txt`
  (payload rows, self-excluded), `privacy-scan.txt` (pre-seal),
  `package-consistency-check.py`, `reuse-ledger.txt`, `README.md`.

## Archive integrity

ustar format; no AppleDouble/pyc/xattr/unsafe/duplicate members.
Final SHA-256/size/counts are in the delivery receipt; the post-seal
privacy transcript ships beside the archive.
