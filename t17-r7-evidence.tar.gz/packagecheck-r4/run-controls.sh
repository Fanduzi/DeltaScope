#!/bin/bash
# T17-R4 packagecheck deletion controls.
# Each control: disposable copy -> REGENERATE manifest+payload-index
# (clean baseline, matching sealed layout) -> delete ONE member ->
# run checker. Failure attribution is then exclusively the deletion.
set -u
cd "$(dirname "$0")/.."
CK_SHA=$(shasum -a 256 package-consistency-check.py | cut -d' ' -f1)
echo "package-consistency-check.py sha256: $CK_SHA" > packagecheck-r4/checker-sha.txt
python3 package-consistency-check.py --emit-required > packagecheck-r4/required-members.txt
FIRST_ST=$(awk -F'\t' 'NR==2{print $10}' validator/process_selftest_r1.tsv)
FIRST_TT=$(awk -F'\t' 'NR==2{print $1}' parity/r3/tamper-results.tsv)
DELS=("golden/matrix-t17.json" "validator/process_selftest_r1.jsonl" "validator/selftest-r1/$FIRST_ST" "parity/r3/stdout-$FIRST_TT.txt" "payload-index.txt" "manifest.txt")
NAMES=("matrix" "jsonl" "selftest-stdout" "tamper-stdout" "payload-index" "manifest")
for i in 0 1 2 3 4 5; do
  td=$(mktemp -d /tmp/t17pc-XXXX); cp -R . "$td/tree"
  (cd "$td/tree" && rm -f payload-index.txt manifest.txt \
   && find . -type f ! -name payload-index.txt ! -name manifest.txt | sed 's|^\./||' | sort | while read f; do printf '%s  %s  %s\n' "$(shasum -a 256 "$f"|cut -d' ' -f1)" "$(stat -f%z "$f")" "$f"; done > payload-index.txt \
   && find . -type f ! -name manifest.txt | sed 's|^\./||' | sort | while read f; do printf '%s  %s  %s\n' "$(shasum -a 256 "$f"|cut -d' ' -f1)" "$(stat -f%z "$f")" "$f"; done > manifest.txt)
  # baseline sanity: clean copy must pass
  (cd "$td/tree" && python3 package-consistency-check.py) > "packagecheck-r4/stdout-base-${NAMES[$i]}.txt" 2>&1
  base_rc=$?
  { echo "checker_sha=$CK_SHA"; tail -1 "packagecheck-r4/stdout-base-${NAMES[$i]}.txt"; } > "packagecheck-r4/baseline-meta-${NAMES[$i]}.txt"
  rm -f "$td/tree/${DELS[$i]}"
  printf 'argv: python3 package-consistency-check.py  (cwd=copy-of-sealed-tree)\ndeleted: %s\n' "${DELS[$i]}" > "packagecheck-r4/argv-del-${NAMES[$i]}.txt"
  (cd "$td/tree" && python3 package-consistency-check.py) > "packagecheck-r4/stdout-del-${NAMES[$i]}.txt" 2> "packagecheck-r4/stderr-del-${NAMES[$i]}.txt"
  echo "baseline_rc=$base_rc deleted_rc=$?" > "packagecheck-r4/rc-del-${NAMES[$i]}.txt"
  rm -rf "$td"
done
