# ER8 — Regression scope (literal commands executed at HEAD 9d2c439c)

Golden not rerun (per work order §10: "No need to rerun the 126 Golden cases"; R1 artifact golden/artifact.json preserved).

| gate | literal command | result |
|---|---|---|
| T10 contract | python3 scripts/test_t10_contract.py | 33/33 constructed-control checks passed |
| validator | make ddl-golden-validator-test | PASS (log: t10-gate-validator.log) |
| inventory | make ddl-inventory-gate | PASS (t10-gate-inventory.log) |
| vet | go vet ./... | PASS (t10-gate-vet.log) |
| PostgreSQL | make pg-unit-test-gates | PASS (t10-gate-pg.log) |
| corpus | make sql-corpus-gates | PASS (t10-gate-corpus.log) |
| full tests | make test | PASS (t10-gate-test.log) |
| focused | go test ./internal/application/audit/ -run 'TestT10\|TestBatchState.*Index\|Index'; go test ./internal/domain/rule/... | ok (focused-tests.log) |

No claim beyond these commands. Logs carry CMD/HEAD/EXIT lines.
