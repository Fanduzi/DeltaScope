# ER7 — Make target expansion and regression scope correction

## Erratum / clarification on R2 regression description
The R2 gate logs were captured with `| tail -4`, so each log shows only the last ~4 package lines. This does NOT mean `make test` ran four packages. Actual expansions (captured verbatim in make-expansion.txt):

- `make test` → `go test ./...` — the full repository test suite (all packages). Result: PASS (log t10-gate-test.log).
- `make pg-unit-test-gates` → `CGO_ENABLED=1 go test -tags postgresql -count=1 ./internal/infrastructure/parser/postgresql ./internal/application/audit ./internal/application/auditmeta ./internal/interfaces/cli ./internal/interfaces/http ./internal/interfaces/mcp ./pkg/deltascope` — a deliberately scoped 7-package PostgreSQL gate, reported here honestly as scoped, not full-repo.
- Cache note: `go test` may reuse cached results for unchanged packages; `-count=1` on the pg gate disables caching there.
- Golden not rerun per work order.

## Full gate list actually executed at HEAD
test_t10_contract.py 33/33; ddl-golden-validator-test; ddl-inventory-gate; go vet ./...; pg-unit-test-gates; sql-corpus-gates; make test (go test ./...); focused index tests — logs in gates/.
