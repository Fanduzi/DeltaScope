# ER3 — R5 README accounting erratum

R5 archive/README.md described expected accounting (71 rows / NEW=25 / REUSED=46, "expected if no additional payload"). Actual R5 accounting: 83 manifest rows / NEW=14 / REUSED=69 — deviation caused entirely by the 12 ER1 fixture-generator payload files. Manifest itself was correct (all members covered, zero defects); only the README narrative carried the expected-figures framing. Corrected in this R6 README and here for auditability.
