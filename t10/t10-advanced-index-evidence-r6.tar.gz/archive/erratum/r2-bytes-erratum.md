# ER1 — R2 archive accounting erratum

Archive: t10-advanced-index-evidence-r2.tar.gz
Actual SHA-256 (independently measured): c6c25997bcb4b3a2fb4005363cbb8a5e38d6e85f002b9c3ce0f9d44830ee43e1
Actual bytes (independently measured): 126229
Embedded value in archive/receipt/receipt.md: 123629

Root cause: the byte count was recorded after a pre-final pack; the definitive pack (with receipt external-SHA fix) produced 126229 bytes. The archive payload itself is correct — every manifest row verifies against the physical member (R2 post-pack verification reported sha_mismatch=0, size_mismatch=0). Only the embedded accounting figure is stale.

No R2 payload member is modified; R2 is preserved byte-for-byte.
