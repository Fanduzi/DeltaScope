# ER5 — FULLTEXT/SPATIAL classification chronology clarification

Source of truth: inventory.yaml T10 rows (extracted losslessly in t10-rows.yaml).

## Chronology (as recorded in status_evidence)

1. 2026-09-22 baseline: FULLTEXT/SPATIAL/INVISIBLE parsed to the same generic `create_index.notice`; functional/prefix/descending parts recorded bounded unaudited evidence; unmodeled IndexOption members recorded `<op>.index.option.<name>` evidence.
2. 2026-10-24 T10: declared INVISIBLE emits `ddl.index.invisible.forbid`; expression/descending/multi-valued members feed `ddl.index.advanced.compatibility.require` per-feature version findings (8.0.13/8.0.17 minimums; 5.7 blocker; missing/out-of-range version = bounded gap); CAST(...AS ... ARRAY) counts MultiValuedParts; INDEX_TYPE classifies SPATIAL/FULLTEXT kinds; declared visibility lands `spec.Index.Visibility/VisibilityExplicit`. At this point MySQL FULLTEXT/SPATIAL members carried NO feature-specific check beyond kind classification — row stayed `generic_notice` for valid variants.
3. 2026-10-25 T10-R1: member-level KeyParts facts (ordinal/prefix/direction/expression identity/column deps) feed member-legality checks — prefix_required (1170), json_column_index (3152), fulltext_column_type (1283), spatial_column_type (1687), spatial_nullable (1252), expression_column_missing (1054) become natively-pinned blocker findings under the compatibility rule when member features enabled; unknown column/type facts degrade to bounded gaps.

## Distinctions preserved
- valid form with no policy finding ≠ full semantic audit (valid MySQL FULLTEXT/SPATIAL forms remain generic_notice);
- invalid member = blocker findings (1283/1687/1252/1170/3152/1054);
- vendor unsupported (TiDB FULLTEXT/SPATIAL refusal) = native-observed refusal, not parser error;
- generic notice ≠ audited semantics claim.

No inventory status or ownership changed this round; no correction required — the two dated entries are complementary (kind classification, then member legality), not contradictory.
