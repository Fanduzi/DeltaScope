# T10 / #89 advanced index semantics — R6 final evidence closeout

Frozen HEAD 9d2c439c46f6faed434e91c8b54ebc82abbf0787. Evidence-only; zero changes anywhere.

R1 c17db131... / R2 c6c25997... / R3 01e46c7b... / R4 e1c5b3e7... / R5 2903f92c... preserved byte-for-byte.

R6 corrections:
- mixed-ddl-batch-6 generator.py now executable (verified: output == fixture.sql byte-identical).
- Provenance corrected: R4 historical samples (preserved) vs R5 reconstructed fixtures vs R6 supplemental measurements (new, labeled) are three distinct records — see fixture provenance.txt files + performance/supplemental-r6.md.
- R5 README accounting erratum: actual R5 accounting was 83 manifest rows / NEW=14 / REUSED=69 (12 fixture files caused deviation from the order's expected-if-no-additional-payload 71/25/46); corrected here.
