# ER1 — T10 implementation commit ancestry

Frozen HEAD: `9d2c439c46f6faed434e91c8b54ebc82abbf0787` (tree `bcec2a29997276ca8d3a173da15ce7cb4c66ab4c`, parent `d6af124165ff05ba1ca18948a7aa20c8f03df58f`).

All commits below verified via `git merge-base --is-ancestor <commit> 9d2c439c...` → exit 0.

## Commit series

| commit | subject | role |
|---|---|---|
| 57e8b1f9a75c27413de83df146be3272033e48cc | docs(t10): freeze advanced-index and visibility contract for issue #89 | contract freeze |
| 7bb6658fc3db992ff1fa4f38e0436c052d070145 | feat(ddl): govern index visibility and advanced index forms (T10) | base implementation |
| 94deda7f8698a1d89cd562710618bd36864068da | test(ddl-golden): T10 frozen advanced-index contract oracle | frozen oracle |
| 5445a4815c360fed0be6850c85deff281d243d59 | test(spec): T10 advanced-index assessment decision table | spec tests |
| e70881d0e62cb49a0338448475aa02758346fe11 | feat(ddl): member-level index facts and primary-role identity (T10-R1) | member facts |
| 5292517197c6b291e8b19d19248ab94a2305e0eb | test(ddl-golden): T10-R1 frozen contract — 123 cases and member-legality | oracle |
| 4c725708db00b01d7fd014709f285178b4f12d2f | test(ddl-golden): pin MySQL/TiDB expression-unique role split — 126 cases | oracle |
| 5a918ac2cb5b638bf031f7c1db222f03aea8a9f8 | fix(ddl): T10-R2 four-state primary role, kind-aware member legality | correctness |
| d4d6d5a8e5e35b3a21efc39b6d535cabd1255afe | style(ddl): drop dead params and lint nits from T10 member work | style |
| 8cba6c1c6de4d9228a3b3e147c584e118bbbdef9 | test(ddl-golden): T10-R2 oracle graduation — contract, docs, ADR sync | oracle |
| 1135e3f5dbeec08de204631e21ef038a1a8be30e | test(ddl-golden): T03-T05 oracle sync — graduate expr/prefix/desc/TiDB GLOBAL | oracle sync |
| ffa7d2b2b1d3f54902c462eb68356e34c8e05865 | fix(ddl): T10-R3 consumer correctness — declared-pair gaps, PK identity, member fidelity | correctness |
| 16915291fcccba54108e29ce3f66f92eb452c075 | fix(ddl): T10-R4 per-member name provability, primary binding, post-state truth | correctness |
| 2f37fbd484c7804691f278ad617ac4ed42a880c2 | fix(ddl): T10-R5 actual PK object names, provider error propagation, MySQL suffix bounds | correctness |
| 6cec4e6c98f9258ddda168494d7bca7f95bfcad3 | fix(t10): T10-R6 attribution ordering, ambiguous-consumer and batch-state closure (#89) | correctness |
| f2ea7b4387702e6a9470db363e1218efde1193d3 | feat(ddl): unify standalone and nested index governance with ordered index state (T09) | prerequisite (T09) |
| d2bbbfa6fdc7ca9def6bb76163d1a5efbc652ef4 | feat(ddl): T07 advanced-column generated/default/visibility semantics | prerequisite (T07) |

Verification-archive doc commits (not product code): 8d75e6b2212f4696e06a9acb2c039414ec147a2b, c72242419d5f74a84cc61c8cb3cf5809d10a228c, ff5a759b46a7f72d1525cde7a0a0fd7c585a2ec6, daad03bbb0a482b2b99ac90b5c2b3af89c417039, 1d60d57849978050b519b8cdc856142606f9b045, b24655fa798336576816665740f118c0247562ee, 248f8c055fa332f59d2720de2e63cb3f60190b17, 8b6f30984d1c610ff44d133e30178fd3a1c165ce.

## Feature → implementation unit map

| feature | source path | functions/types | commits | ancestry rc |
|---|---|---|---|---|
| ALTER INDEX VISIBLE/INVISIBLE parsing | infrastructure/parser/tidb (TiDB parser AST `AlterIndexVisibility`) → spec extractor | `spec.Alter` action `alter_index` | 7bb6658fc3db992ff1fa4f38e0436c052d070145 | 0 |
| CREATE INDEX visibility attributes | spec extractor + `spec.Index.Visibility`/`VisibilityExplicit` | `spec.Index` fields | 7bb6658fc3db992ff1fa4f38e0436c052d070145 | 0 |
| spec.Index.Visibility / VisibilityExplicit | internal/domain/spec (index model) | `Index.Visibility`, `Index.VisibilityExplicit` | 7bb6658fc3db992ff1fa4f38e0436c052d070145 | 0 |
| Visibility provider / IS_VISIBLE fidelity | internal/infrastructure/metadata/mysql (STATISTICS IS_VISIBLE read; tests provider_t10r2/r4) | provider index reads | 2f37fbd484c7804691f278ad617ac4ed42a880c2, 16915291fcccba54108e29ce3f66f92eb452c075 | 0 |
| ddl.index.invisible.forbid | internal/domain/rule/ddl/index_visibility_rules.go | `indexInvisibleForbidRule`, `invisibilitySubjects` | 7bb6658fc3db992ff1fa4f38e0436c052d070145 | 0 |
| ddl.alter.alter_index.exists.require | index_visibility_rules.go | `indexExistenceRule`, `newAlterIndexExistsRule`, `alterIndexTargetExists` | 7bb6658fc3db992ff1fa4f38e0436c052d070145 + ffa7d2b2b1d3f54902c462eb68356e34c8e05865 | 0 |
| ddl.index.advanced.compatibility.require | index_visibility_rules.go | `indexAdvancedCompatibilityRule` | 7bb6658fc3db992ff1fa4f38e0436c052d070145 | 0 |
| Expression/functional-index member extraction | internal/domain/spec/advanced_indexes.go | `advancedIndexFact`, `statementIndexFacts`, KeyParts | 7bb6658fc3db992ff1fa4f38e0436c052d070145, e70881d0e62cb49a0338448475aa02758346fe11 | 0 |
| Expression dependency identity | advanced_indexes.go + batch_state_index.go | `factMemberColumn`, `markIndexMemberNameUnknown` | e70881d0e62cb49a0338448475aa02758346fe11, 16915291fcccba54108e29ce3f66f92eb452c075 | 0 |
| Prefix length extraction | advanced_indexes.go | member KeyParts prefix facts, `prefixRequiredFamilyType` (1170), `prefixCapableFamilyType` | e70881d0e62cb49a0338448475aa02758346fe11, 5a918ac2cb5b638bf031f7c1db222f03aea8a9f8 | 0 |
| ASC/DESC member direction | advanced_indexes.go | member direction facts in `assessIndexMembers` | e70881d0e62cb49a0338448475aa02758346fe11 | 0 |
| FULLTEXT/SPATIAL IndexKind classification | advanced_indexes.go | `IndexKind`, `fulltextMemberFamilyType` (1283), `spatialMemberFamilyType` (1687/1252) | 7bb6658fc3db992ff1fa4f38e0436c052d070145, 5a918ac2cb5b638bf031f7c1db222f03aea8a9f8 | 0 |
| FULLTEXT column-type validation | advanced_indexes.go `assessIndexMembers` | fulltext member family check → blocker | 5a918ac2cb5b638bf031f7c1db222f03aea8a9f8 | 0 |
| SPATIAL type + nullable validation | advanced_indexes.go `assessIndexMembers` | spatial family + NOT NULL member check | 5a918ac2cb5b638bf031f7c1db222f03aea8a9f8 | 0 |
| MultiValuedParts extraction | advanced_indexes.go | CAST(...AS ... ARRAY) → MultiValued feature | e70881d0e62cb49a0338448475aa02758346fe11, 5a918ac2cb5b638bf031f7c1db222f03aea8a9f8 | 0 |
| Per-feature version gates | advanced_indexes.go | `AdvancedIndexMinimum*` (8.0.0 visibility / 8.0.13 expression / 8.0.17 multi-valued) | 7bb6658fc3db992ff1fa4f38e0436c052d070145 | 0 |
| T05 prospective visibility/index transitions | internal/application/audit/batch_state_index.go | `applyAlterIndexVisibility`, `markIndexesUnknown`, `markIndexNamesUnknown`, `markPrimaryUnknown` | f2ea7b4387702e6a9470db363e1218efde1193d3 (T09) + 7bb6658fc3db992ff1fa4f38e0436c052d070145 + 6cec4e6c98f9258ddda168494d7bca7f95bfcad3 | 0 |
| T09 index identity compatibility | index_rules.go + batch_state_index.go | `provenIndexMatch`, ordered index signatures | f2ea7b4387702e6a9470db363e1218efde1193d3 | 0 |
| T07 generated-column dependency compatibility | advanced_column_rules.go + batch_state | expression dep → generated column refs | d2bbbfa6fdc7ca9def6bb76163d1a5efbc652ef4 (T07) | 0 |

## Golden case IDs
Primary: `make ddl-golden TASK=T10` artifact — 126 cases pass at HEAD (golden/artifact.json). Focused tests: `internal/domain/rule/ddl/index_*_test.go` (t09/t10r3/r4/r5/r6 suffixed files), `internal/application/audit/batch_state_t09*_test.go`, `internal/infrastructure/metadata/mysql/provider_t10r*_test.go`, spec decision table `advanced_indexes_test.go`.

## Method note
Multiple features were delivered in shared commits; the mapping above assigns each feature to the commit that introduced its governing semantics plus later correctness rounds. No commit-per-feature claim is made.


## R3 supplement — complete raw ancestry evidence
Per-commit subject/parents/tree/author+committer dates/complete changed-file inventory/literal `git merge-base --is-ancestor` commands with actual exit codes: see `source-audit/ancestry-raw.txt` (26 commits, all rc=0 against HEAD 9d2c439c46f6faed434e91c8b54ebc82abbf0787 — a frozen local milestone identity; no remote comparison claimed).

Additional implementation commits surfaced by full-chain review: 64e750dc (MySQL functional-unique primary-role correctness), plus documentation-verification commits 8d75e6b2, c7224241, ff5a759b, daad03bb, 1d60d578, b24655fa, 248f8c05, 8b6f3098 (evidence archives only, not product code).
