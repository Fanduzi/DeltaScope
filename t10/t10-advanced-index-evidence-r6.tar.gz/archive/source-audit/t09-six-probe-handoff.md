# ER2 — Six-probe T09→T10 handoff

Original stable probe set: docs/research/2026-09-21-mysql-tidb-ddl-probes.json (153 probes).

| probe ID | original SQL | dialect | original observation | T09-R3 bounded result | T10 oracle | T10 current result | native case IDs | remaining boundary |
|---|---|---|---|---|---|---|---|---|
| mysql.index_invisible | ALTER TABLE t ALTER INDEX idx_c INVISIBLE | mysql | exit 0, verdict pass, parsed but unaudited | parse-recognized, index-governance gap (bounded) | visibility semantics audited | PASS — visibility feature assessed, exists.require/applicability | t10-cli-visible, t10-mysql80/84-visible | query-side invisibility effect unaudited (declaration only) |
| mysql.index_visible | ALTER TABLE t ALTER INDEX idx_c VISIBLE | mysql | exit 0, verdict pass | same bounded gap | restoration semantics | PASS | t10-cli-visible, meta visible | same |
| tidb.index_invisible | ALTER TABLE t ALTER INDEX idx_c INVISIBLE | tidb | exit 0, verdict pass | bounded gap | TiDB visibility semantics | PASS | t10-tidb85-visible | same; TiDB native verified independently |
| tidb.index_visible | ALTER TABLE t ALTER INDEX idx_c VISIBLE | tidb | exit 0, verdict pass | bounded gap | restoration | PASS | t10-tidb85-visible | same |
| mysql.create_expression_index | CREATE INDEX idx_expr ON t ((lower(c))) | mysql | exit 0, pass + 1 notice | bounded expression-member gap | expression index semantics | PASS — member extraction + version gate 8.0.13 + member legality | t10-cli-expr-ver57, t10-mysql80/84-expr, *-expr-missing, *-implicit-pk-expr-* | expression equivalence / query matching unaudited |
| tidb.create_expression_index | CREATE INDEX idx_expr ON t ((lower(c))) | tidb | exit 0, pass + 1 notice | bounded gap | TiDB expression index semantics | PASS | t10-tidb85-expr, tidb85-implicit-pk-expr-allowed | same; TiDB documented capability confirmed natively |

Implementation commits: 7bb6658f (base), e70881d0 + 5a918ac2 (member facts/legality), 6cec4e6c (R6 closure). Focused tests: index_visibility/index_exists/index_names `*_t10r*_test.go`, batch_state index tests.

Historical reconciliation preserved: T09 records only bounded index-governance reporting for these probes; T10 owns the semantic promotion. Query semantics (optimizer use of invisible/expression indexes) remain outside declaration-level audit and are not claimed.
