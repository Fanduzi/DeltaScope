# ER3 — TiDB multi-valued-index applicability reconciliation

## Erratum in R2
R2 source-audit/t10-feature-reconciliation.md stated "multi-valued index — MySQL 8.0.17+ only". That phrasing erased the TiDB side. Corrected here.

## Actual Golden artifact evidence (preserved, golden/artifact.json)
- T10.meta.t10-tidb85-mv: `CREATE INDEX i ON t10v((CAST(j AS UNSIGNED ARRAY)))` — native rc=0; information_schema.statistics index i exists count=1; product coverage=complete verdict=pass findings=0 unsupported=0.
- T10.meta.t10-tidb85-mv-supported: `CREATE INDEX mv ON t10t((CAST(j->'$.a' AS UNSIGNED ARRAY)))` — native rc=0; index mv exists count=1; coverage=complete.
- MySQL anchors: mysql57-mv (5.7 boundary), mysql80/84-mv + *-mv-supported all pass.

## Product applicability model (internal/domain/spec/advanced_indexes.go:356-358)
The multi-valued version gate `!versionAtLeast(version, [8,0,17])` applies only when `dialect == DialectMySQL`. For TiDB the feature is accepted without a MySQL-version gate; member-legality (cast-type) checks still apply (L591-619).

## Applicability table (final)
| anchor | multi-valued CREATE INDEX | basis |
|---|---|---|
| MySQL 5.7 | not applicable (version blocker) | official docs: feature introduced 8.0.17 |
| MySQL 8.0 | applicable when version ≥ 8.0.17 | official minimum + native verify |
| MySQL 8.4 | applicable | official + native |
| TiDB 8.5 | applicable — natively observed (rc=0, index created, product complete/pass) | native execution evidence; NOT inferred from MySQL |

## Official documentation status for TiDB multi-valued
PingCAP TiDB documentation (sql-statement-create-index / tidb-stable) does not present multi-valued CAST(...AS ... ARRAY) indexing as a documented feature in the pages reviewed; it is labeled here **native-observed, undocumented** — TiDB accepts the syntax natively (observed on 8.5), but no official doc claim is made. This does not contradict the Golden artifact: product acceptance is justified by native evidence, not documentation.

## Boundaries
- Multi-valued member query semantics (which queries the index can serve) remain outside the audited contract — bounded unaudited aspect.
- No product or policy change made.
