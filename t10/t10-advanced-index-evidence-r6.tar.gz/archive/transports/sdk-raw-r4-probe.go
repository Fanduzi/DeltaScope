package main
import("context";"encoding/json";"fmt";"os"
 ds "github.com/Fanduzi/DeltaScope/pkg/deltascope")
func main(){
 req:=ds.Request{ConfigPath:"/Users/fan/GolangProjects/DeltaScope/configs/deltascope.example.yaml",Dialect:"mysql",TargetVersion:"8.0.46",SQL:"CREATE INDEX i ON t(a) INVISIBLE"}
 r,err:=ds.Audit(context.Background(),req)
 out:=map[string]any{"request":map[string]any{"config_path":req.ConfigPath,"dialect":req.Dialect,"target_version":req.TargetVersion,"sql":req.SQL},"result":r}
 if err!=nil{out["error"]=err.Error()}
 b,_:=json.MarshalIndent(out,"","  ")
 fmt.Println(string(b))
 if err!=nil{os.Exit(1)}}
