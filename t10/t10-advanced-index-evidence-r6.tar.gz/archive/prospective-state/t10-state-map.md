# ER4 — T10 prospective-state map (batch_state_index.go unless noted)

| transition | source function | semantics | test case |
|---|---|---|---|
| visibility transition (VISIBLE→INVISIBLE) | applyAlterIndexVisibility (~L670) | bounded visibility change vouched per-index on proven shape; MySQL ALTER INDEX `PRIMARY` refused (3522) | batch_state_t09/t10 index tests; meta *-visible |
| VISIBLE restoration | applyAlterIndexVisibility (same path, VISIBLE arm) | restores visible fact, preserves identity | same |
| DROP INDEX then visibility op | dropIndexTargetExists + markIndexesUnknown on missing target | existence premise unproven → bounded gap, not fabricated finding | index_exists_t10r4/r5/r6 tests |
| advanced index declaration (expr/ft/spatial/mv) | ordered index state from f2ea7b43 + KeyParts member facts (e70881d0) | member facts (ordinal/prefix/direction/expr/column deps) carried in PSS | index_facts_t09r1, index_create_table_t10r3 |
| ordered member facts | withClonedShape + markIndexMemberNameUnknown | per-member provability; ambiguous consumer → bounded unknown | index_names_t10r4/r5 tests |
| expression dependencies | factMemberColumn + column-dep tracking | expression member column deps tracked; dropped dep column invalidates index fact | batch_state index tests |
| T07 generated-column interaction | advanced_column_rules dep refs + PSS | generated column referenced by expression index keeps dependency identity | T07+T10 combined cases in manifest |
| T09 index identity preservation | provenIndexMatch, ordered signatures | exact ordered member identity preserved across transitions | T09 regression + T10 cases |
| unknown-effect invalidation | markIndexesUnknown / markIndexNamesUnknown / markPrimaryUnknown | unsupported or unverifiable mutations → bounded unknown, never fabricated facts | unsupported-mutation tests |

No second state engine exists; all transitions share the T05 ordered batch-state engine.
