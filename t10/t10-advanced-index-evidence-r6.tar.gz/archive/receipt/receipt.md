(receipt: delivered in message; external SHA registration)
