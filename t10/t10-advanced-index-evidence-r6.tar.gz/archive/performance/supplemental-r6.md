# R6 supplemental measurements — reconstructed fixtures, NEW measurements (not R4 historical outputs)
HEAD: 9d2c439c46f6faed434e91c8b54ebc82abbf0787
binary_sha256: 3c6c82c6bbc7969dec2ccfd83c620ccf34caccc6b15f8d2950888129af3ef0b7
method: same as R4 (subprocess wall-clock, n=5, warm, darwin arm64)

table-60-indexes: raw=[65.2, 17.9, 18.1, 18.7, 16.8] median=18.1 p95=65.2 min=16.8 max=65.2
expr-8-members: raw=[18.0, 15.5, 15.2, 16.7, 16.8] median=16.7 p95=18.0 min=15.2 max=18.0
prefix-8-members: raw=[15.8, 15.4, 15.6, 14.5, 16.2] median=15.6 p95=16.2 min=14.5 max=16.2
mixed-ddl-batch-6: raw=[17.6, 15.4, 15.2, 14.8, 15.6] median=15.4 p95=17.6 min=14.8 max=17.6
