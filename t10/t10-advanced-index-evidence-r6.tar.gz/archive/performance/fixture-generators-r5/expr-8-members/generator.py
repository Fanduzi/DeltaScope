sql = "CREATE INDEX i ON t(" + ",".join("(a+%d)" % i for i in range(1,9)) + ")"
print(sql)
