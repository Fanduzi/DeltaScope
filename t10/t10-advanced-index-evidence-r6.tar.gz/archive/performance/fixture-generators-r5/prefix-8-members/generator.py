sql = "CREATE INDEX i ON t(" + ",".join("c%d(16)" % i for i in range(1,9)) + ")"
print(sql)
