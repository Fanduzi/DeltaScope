CREATE INDEX i ON t(c1(16),c2(16),c3(16),c4(16),c5(16),c6(16),c7(16),c8(16))
