many = ", ".join("KEY k%d(a)" % i for i in range(60))
sql = "CREATE TABLE t (a INT, " + many + ")"
print(sql)
