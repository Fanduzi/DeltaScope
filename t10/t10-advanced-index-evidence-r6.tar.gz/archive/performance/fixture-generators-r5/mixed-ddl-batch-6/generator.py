stmts = [
    "CREATE TABLE t (a INT)",
    "ALTER TABLE t ADD INDEX i(a)",
    "ALTER TABLE t ALTER INDEX i INVISIBLE",
    "CREATE INDEX e ON t((a+1))",
    "ALTER TABLE t ALTER INDEX i VISIBLE",
    "DROP INDEX i ON t",
]
sql = "; ".join(stmts)
print(sql)
