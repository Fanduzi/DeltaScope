# ER1-R4 raw performance samples
HEAD: 9d2c439c46f6faed434e91c8b54ebc82abbf0787
binary_sha256: 3c6c82c6bbc7969dec2ccfd83c620ccf34caccc6b15f8d2950888129af3ef0b7
method: subprocess wall-clock (time.perf_counter), n=5 sequential, warm, darwin arm64, offline CLI audit; memory not independently instrumented
invocation: ./bin/deltascope --config configs/deltascope.example.yaml audit --dialect mysql --target-version 8.0.46 --sql "<fixture>" --format json

single-alter-invisible: raw=[15.5, 15.5, 15.8, 15.0, 15.2] median=15.5 p95=15.8 min=15.0 max=15.8
single-visible-restore: raw=[16.8, 15.8, 15.4, 15.2, 15.2] median=15.4 p95=16.8 min=15.2 max=16.8
table-60-indexes: raw=[16.3, 16.8, 16.8, 16.7, 16.4] median=16.7 p95=16.8 min=16.3 max=16.8
expr-8-members: raw=[15.4, 15.3, 16.3, 16.5, 15.6] median=15.6 p95=16.5 min=15.3 max=16.5
prefix-8-members: raw=[15.4, 14.7, 15.0, 15.3, 17.2] median=15.3 p95=17.2 min=14.7 max=17.2
mixed-asc-desc: raw=[15.8, 15.8, 15.3, 15.4, 15.6] median=15.6 p95=15.8 min=15.3 max=15.8
fulltext-spatial: raw=[14.4, 14.9, 15.2, 15.7, 15.4] median=15.2 p95=15.7 min=14.4 max=15.7
multi-valued: raw=[15.3, 16.0, 16.3, 15.4, 16.1] median=16.0 p95=16.3 min=15.3 max=16.3
mixed-ddl-batch-6: raw=[19.5, 16.0, 16.2, 15.9, 17.0] median=16.2 p95=19.5 min=15.9 max=19.5
batch-1018-alter-add-index: raw=[70.4, 72.2, 72.7, 71.1, 70.9] median=71.1 p95=72.7 min=70.4 max=72.7
