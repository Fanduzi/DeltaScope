# ER6 — Performance evidence reproducibility (R3 supplement)

## Method
- Invocation: `./bin/deltascope --config configs/deltascope.example.yaml audit --dialect mysql --target-version 8.0.46 --sql "<fixture>" --format json` — one subprocess per sample, wall-clock `time.perf_counter()` around subprocess.run.
- HEAD: 9d2c439c46f6faed434e91c8b54ebc82abbf0787; binary SHA-256: 3c6c82c6bbc7969dec2ccfd83c620ccf34caccc6b15f8d2950888129af3ef0b7
- Environment: darwin arm64, warm binary/filesystem (each case run 5 sequential samples); offline CLI audit only — no database execution; timings are end-to-end process time including parse+audit+serialization.
- Memory/resource: not separately instrumented (process-level RSS not captured); stated honestly.

## Original R2 numbers (retained verbatim)
single-alter-invisible median 16.1ms | single-visible-restore 15.9 | table-60-indexes 16.9 | expr-8-members 16.3 | prefix-8-members 15.7 | mixed-asc-desc 16.0 | fulltext-spatial 15.5 | multi-valued 16.1 | mixed-ddl-batch-6 16.9 | batch-1018 73.1 (these were medians of 5; see R2 file).

## Exact SQL fixtures (R2 cases)
- single-alter-invisible: `ALTER TABLE t ALTER INDEX i INVISIBLE`
- single-visible-restore: `ALTER TABLE t ALTER INDEX i VISIBLE`
- table-60-indexes: `CREATE TABLE t (a INT, KEY k0(a)...KEY k59(a))` (60 KEY clauses)
- expr-8-members: `CREATE INDEX i ON t((a+1),...,(a+8))`
- prefix-8-members: `CREATE INDEX i ON t(c1(16),...,c8(16))`
- mixed-asc-desc: `CREATE INDEX i ON t(a ASC, b DESC, c ASC, d DESC)`
- fulltext-spatial: `CREATE TABLE t (b TEXT, g GEOMETRY NOT NULL, FULLTEXT KEY ft(b), SPATIAL KEY sp(g))`
- multi-valued: `CREATE INDEX i ON t((CAST(a AS UNSIGNED ARRAY)))`
- mixed-ddl-batch-6: 6-statement create/add/alter/create/alter/drop batch
- batch-N: `ALTER TABLE t ADD INDEX i0(c)` repeated N times

## Mandatory 1024 boundary (isolated, exact)
- Fixture: exactly 1024 `ALTER TABLE t ADD INDEX iN(c)` statements.
- Raw samples (ms): 135.2, 71.7, 72.9, 72.1, 73.6 — median 72.9, p95 135.2, min 71.7, max 135.2. (First sample includes Go runtime warm-up; steady-state ~72ms.)
- Immediately-beyond negative control (1025 statements): exit rc=1, coverage=incomplete; statement 1025 carries a bounded `audit.resource_limit` unsupported entry ("ordered-state statement budget exhausted", consumed=1024, limit=1024) — fail-closed, no crash, no silent drop.
- Source of the boundary: internal/application/audit/service.go:73 `defaultOrderedStatementLimit = 1024`. 1018 in R2 was a fixture choice, not the boundary; the true maximum is 1024 as now measured.

No database execution time is inferred; no optimizer/query-speed claim is made.
