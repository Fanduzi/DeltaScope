# ER4 — Official source provenance (retrieval dates added R3)

Retrieval dates: MySQL dev.mysql.com pages retrieved 2026-10-24/25 during T10 implementation rounds and re-verified against golden manifest case families; PingCAP docs.pingcap.com TiDB pages retrieved 2026-10-24. Where a capability is accepted natively but not found in official docs, it is labeled native-observed, not officially documented.

| feature | URL | title | publisher | product/version | semantic statement used | native case IDs | inventory row |
|---|---|---|---|---|---|---|---|
| index visibility | https://dev.mysql.com/doc/refman/8.0/en/invisible-indexes.html | Invisible Indexes | Oracle MySQL docs | MySQL 8.0.x | ALTER TABLE t ALTER INDEX i {INVISIBLE\|VISIBLE}; PRIMARY cannot be invisible (3522); optimizer ignores invisible | t10-mysql80/84-visible, provider-invisible | T10 visibility row |
| index visibility | https://dev.mysql.com/doc/refman/8.4/en/invisible-indexes.html | Invisible Indexes | Oracle MySQL docs | MySQL 8.4.x | same semantics on 8.4 | t10-mysql84-* | same |
| index visibility (absence) | https://dev.mysql.com/doc/refman/5.7/en/alter-table.html | ALTER TABLE | Oracle MySQL docs | MySQL 5.7 | no ALTER INDEX clause → version boundary; parser acceptance ≠ native support | t10-mysql57-create-invisible | same |
| expression/functional index | https://dev.mysql.com/doc/refman/8.0/en/create-index.html | CREATE INDEX (functional key parts) | Oracle MySQL docs | MySQL 8.0.13+ | functional key parts `(expr)`; requires 8.0.13 | t10-mysql80/84-expr, cli-expr-ver57 | T10 expr row |
| multi-valued index | https://dev.mysql.com/doc/refman/8.0/en/create-index.html#create-index-multi-valued | Multi-Valued Indexes | Oracle MySQL docs | MySQL 8.0.17+ | CAST(x AS ... ARRAY) secondary indexes on JSON arrays | multivalued cases | T10 members row |
| descending index | https://dev.mysql.com/doc/refman/8.0/en/descending-indexes.html | Descending Indexes | Oracle MySQL docs | MySQL 8.0+ | DESC members honored 8.0+; 5.7 parsed-but-ignored | direction cases | T10 members row |
| prefix index | https://dev.mysql.com/doc/refman/8.0/en/create-index.html (col_name(length)) | CREATE INDEX | Oracle MySQL docs | MySQL all | prefix length facts; BLOB/TEXT require prefix (1170); JSON cannot be indexed directly (3152) | prefix cases | T10 members row |
| FULLTEXT | https://dev.mysql.com/doc/refman/8.0/en/fulltext-search.html + create-index | Full-Text Search / CREATE INDEX | Oracle MySQL docs | MySQL all | FULLTEXT kind; member column family CHAR/VARCHAR/TEXT (1283) | fulltext cases | T10 kinds row |
| FULLTEXT | https://dev.mysql.com/doc/refman/5.7/en/fulltext-search.html | Full-Text Search | Oracle MySQL docs | MySQL 5.7 | FULLTEXT supported on 5.7 (InnoDB 5.6.4+) | fulltext-57 cases | same |
| SPATIAL | https://dev.mysql.com/doc/refman/8.0/en/creating-spatial-indexes.html | Creating Spatial Indexes | Oracle MySQL docs | MySQL all | SPATIAL member must be geometry type (1687) and NOT NULL (1252) | spatial cases | same |
| TiDB index visibility | https://docs.pingcap.com/tidb/stable/sql-statement-alter-table/ + index docs | ALTER TABLE / index visibility | PingCAP docs | TiDB 8.5 | ALTER INDEX INVISIBLE/VISIBLE supported natively | t10-tidb85-visible | T10 TiDB cells |
| TiDB expression index | https://docs.pingcap.com/tidb/stable/sql-statement-create-index/ | CREATE INDEX (expression indexes) | PingCAP docs | TiDB 8.5 | expression index supported (experimental-gated historically, GA path documented) | t10-tidb85-expr | same |
| TiDB FULLTEXT/SPATIAL | https://docs.pingcap.com/tidb/stable/sql-statement-create-index/ | CREATE INDEX | PingCAP docs (retrieved 2026-10-24) | TiDB 8.5 | FULLTEXT/SPATIAL kinds not supported → native refusal observed | tidb fulltext/spatial native cases | same |
| TiDB multi-valued | https://docs.pingcap.com/tidb/stable/sql-statement-create-index/ | CREATE INDEX | PingCAP docs (retrieved 2026-10-24) | TiDB 8.5 | CAST(...AS ... ARRAY) multi-valued NOT presented as documented feature → **native-observed, undocumented** | t10-tidb85-mv, t10-tidb85-mv-supported | T10 members row |

## Method notes
- Documented behavior vs native-observed behavior are distinguished: every claim above also carries native evidence in database/per-case-evidence.txt (literal SQL, rc, SHOW INDEX).
- MySQL documentation is never used as evidence of TiDB behavior; TiDB rows cite docs.pingcap.com only.
- Historical version applicability preserved: 5.7 rows cite 5.7 docs; no 8.0+ doc was used to backfill 5.7 capability.
